define([
    'jquery',
    'mage/utils/wrapper'
], function ($, wrapper) {
	'use strict';
 
    return function(targetModule){
 
        var reloadPrice = targetModule.prototype._reloadPrice;
        var reloadPriceWrapper = wrapper.wrap(reloadPrice, function(original){
        var result = original();
        var simpleSku = this.options.spConfig.sku[this.simpleProduct];
        var simpleName = this.options.spConfig.name[this.simpleProduct];
        var simpleDescription = this.options.spConfig.description[this.simpleProduct];
        var simpleSpecification = this.options.spConfig.specification[this.simpleProduct];
        
            if(simpleSku != '') {
                $('div.product-info-main .sku .value').html(simpleSku);
            }
            if(simpleName != '') {
                $('div.product-info-main .page-title-wrapper .page-title').html(simpleName);
            }
            if(simpleDescription != '') {
                $('div.detailed #description').html(simpleDescription);
            }
            if(simpleSpecification != '') {
                $('div.detailed #specification.tab').html(simpleSpecification);
            }
            return result;

        });
        targetModule.prototype._reloadPrice = reloadPriceWrapper;
        return targetModule;
	};
});