define([
    'jquery',
    'mage/utils/wrapper'
], function ($, wrapper) {
	'use strict';
 
    return function(targetModule){
        var updatePrice = targetModule.prototype._UpdatePrice;
        targetModule.prototype.configurableSku = $('div.product-info-main .sku .value').html();
        targetModule.prototype.configurableName = $('div.product-info-main .page-title-wrapper .page-title').html();
        targetModule.prototype.configurableDescription = $('div.detailed #description').html();
        targetModule.prototype.configurableSpecification = $('div.detailed #specification.tab').html();
        var updatePriceWrapper = wrapper.wrap(updatePrice, function(original){
            var allSelected = true;
            for(var i = 0; i<this.options.jsonConfig.attributes.length;i++){
                if (!$('div.product-info-main .product-options-wrapper .swatch-attribute.' + this.options.jsonConfig.attributes[i].code).attr('option-selected')){
                	allSelected = false;
                }
            }
            var simpleSku = this.configurableSku;
            var simpleName = this.configurableName;
            var simpleDescription = this.configurableDescription;
            var simpleSpecification = this.configurableSpecification;

            if (allSelected){
                var products = this._CalcProducts();
                simpleSku = this.options.jsonConfig.sku[products.slice().shift()];
                simpleName = this.options.jsonConfig.name[products.slice().shift()];
                simpleDescription = this.options.jsonConfig.description[products.slice().shift()];
                simpleSpecification = this.options.jsonConfig.specification[products.slice().shift()];
            }
            
            $('div.detailed #description').html(simpleDescription);
            $('div.detailed #specification.tab').html(simpleSpecification);
              return original();
        });
 
        targetModule.prototype._UpdatePrice = updatePriceWrapper;
        return targetModule;
	};
});
