var config = {
    config: {
        mixins: {
            'Magento_ConfigurableProduct/js/configurable': {
                'Digital_ChangeTab/js/model/skuswitch': true
             },
            'Magento_Swatches/js/swatch-renderer': {
                'Digital_ChangeTab/js/model/swatch-skuswitch': false
            }
        }
	}
 

};