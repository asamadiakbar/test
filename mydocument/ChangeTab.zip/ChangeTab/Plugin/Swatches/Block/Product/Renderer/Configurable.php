<?php
namespace  Digital\ChangeTab\Plugin\Swatches\Block\Product\Renderer;
 
class Configurable
{
    public function __construct(
        \Magento\Catalog\Model\ProductRepository $productRepository,
    )
    {
        $this->_productRepository = $productRepository;
    }
    public function afterGetJsonConfig(\Magento\Swatches\Block\Product\Renderer\Configurable $subject, $result) {
 
        $jsonResult = json_decode($result, true);
        $jsonResult['sku'] = [];
        $jsonResult['name'] = [];
        $jsonResult['description'] = [];
        $jsonResult['specification'] = [];
        foreach ($subject->getAllowProducts() as $simpleProduct) {
           $jsonResult['sku'][$simpleProduct->getId()] = $simpleProduct->getSku();
           $jsonResult['name'][$simpleProduct->getId()] = $simpleProduct->getName();
           $jsonResult['description'][$simpleProduct->getId()] = $this->description($simpleProduct->getId());
            $jsonResult['specification'][$simpleProduct->getId()] = $this->specification($simpleProduct->getId());
        }

        $result = json_encode($jsonResult);
        
        return $result;
    }
    public function specification($id)
    {
         $data = $this->_productRepository->getById($id);
         $specification = $data->getSpecification();
         
         return $specification;
    }
    public function description($id)
    {
         $data = $this->_productRepository->getById($id);
         $description = $data->getDescription();
         return $description;
    }
}