<?php
/**
 * Copyright © 2015 AionNext Ltd. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Dcs\HowTo\Helper;

/**
 * Aion Test helper
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * Path to store config if extension is enabled
     *
     * @var string
     */
    const XML_PATH_ENABLED = 'howto_section/general_group/frontend_enable';

    const XML_PATH_FOR_FILE_TYPE = 'howto_section/general_group/file_type';

    const XML_PATH_FOR_IMAGE_TYPE = 'howto_section/general_group/image_type';

    /**
     * Check if extension enabled
     *
     * @return string|null
     */
    public function isEnabled()
    {
        return $this->scopeConfig->isSetFlag(
            self::XML_PATH_ENABLED,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getAllowedFileTypeData()
    {
        $allowedType =  $this->scopeConfig->getValue(
            self::XML_PATH_FOR_FILE_TYPE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
         
        return $allowedType;
    }

    public function getAllowedFIleType()
    {
        $allowedType = $this->getAllowedFileTypeData();
        $typeArray = explode(",", $allowedType);
        return $typeArray;
    }

    public function getAllowedImageTypeData()
    {
        $allowedType =  $this->scopeConfig->getValue(
            self::XML_PATH_FOR_IMAGE_TYPE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
         
        return $allowedType;
    }

    public function getAllowedImageType()
    {
        $allowedType = $this->getAllowedImageTypeData();
        $typeArray = explode(",", $allowedType);
        return $typeArray;
    }
}
