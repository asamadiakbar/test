<?php
  
namespace Dcs\HowTo\Model\Grid;

use \Magento\Store\Model\StoreRepository;
  
class Store extends \Magento\Framework\DataObject implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @var Rate
     */
    protected $_storeRepository;
      
    /**
     * @param StoreRepository      $storeRepository
     */
    public function __construct(
        StoreRepository $storeRepository
    ) {
        $this->_storeRepository = $storeRepository;
    }
   
    public function toOptionArray()
    {
        $stores = $this->_storeRepository->getList();
        $websiteIds = [];
        $storeList = [];
        foreach ($stores as $store) {
            $websiteId = $store["website_id"];
            $storeId = $store["store_id"];
            $storeName = $store["name"];
            $storeList[$storeId] = $storeName;
            array_push($websiteIds, $websiteId);
        }
        return $storeList;
    }
}
