<?php
/**
 * Copyright © 2015 Dcs. All rights reserved.
 */
namespace Dcs\HowTo\Model;

class HowTo extends \Magento\Framework\Model\AbstractModel
{
    
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->_init('Dcs\HowTo\Model\Resource\HowTo');
    }
}
