<?php
namespace Dcs\HowTo\Model;
 
use Dcs\HowTo\Model\Resource\HowTo\CollectionFactory;
use Magento\Store\Model\StoreManagerInterface;
 
class DataProviderHowTo extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * @var array
     */
    protected $loadedData;
    // @codingStandardsIgnoreStart
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $howtoCollectionFactory,
        StoreManagerInterface $storeManager,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $howtoCollectionFactory->create();
        $this->storeManager = $storeManager;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }
    // @codingStandardsIgnoreEnd
    public function getData()
    {   
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        $imageUrl = $this->storeManager->getStore()->getBaseUrl(
                        \Magento\Framework\UrlInterface::URL_TYPE_MEDIA
                    );
        foreach ($items as $howto) {  
          
          $this->loadedData[$howto->getHowtoId()] = $howto->getData();
            if(isset($howto['category_id']) && $howto->getCategoryId()){
                $this->loadedData[$howto->getHowtoId()]['data']['parent'] = $howto->getCategoryId();
                $this->loadedData[$howto->getHowtoId()]['data']['category_id'] = $howto->getCategoryId();   
            }
            if($howto->getFile()) {
                $file['file'][0]['name'] = $howto->getFile();
                $file['file'][0]['url'] = $imageUrl.'howto/pdf/'.$howto->getFile();
                $fullData = $this->loadedData;
                $this->loadedData[$howto->getHowtoId()] = array_merge($fullData[$howto->getHowtoId()],$file);
            }
             if($howto->getPreviewImage()) {
                $image['preview_image'][0]['name'] = $howto->getPreviewImage();
                $image['preview_image'][0]['url'] = $imageUrl.$howto->getPreviewImage();
                $fullData = $this->loadedData;
                $this->loadedData[$howto->getHowtoId()]['howto_guidens'] = array_merge($fullData[$howto->getHowtoId()],$image);
            }  
        }
       
        return $this->loadedData;
    }
}