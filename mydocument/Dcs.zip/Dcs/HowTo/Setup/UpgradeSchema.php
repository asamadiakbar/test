<?php
namespace Dcs\HowTo\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
        if (version_compare($context->getVersion(), '1.1.1', '<')) {
             $installer->getConnection()->addColumn(
                 $installer->getTable('howto_howto'),
                 'url_key',
                 \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                 null
             );
            $installer->getConnection()->addColumn(
                $installer->getTable('howto_category'),
                'url_key',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null
            );
            $installer->getConnection()->addColumn(
                $installer->getTable('howto_howto'),
                'metatitle',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null
            );
            $installer->getConnection()->addColumn(
                $installer->getTable('howto_howto'),
                'metacontent',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null
            );
            $installer->getConnection()->addColumn(
                $installer->getTable('howto_howto'),
                'metakeyword',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null
            );
        }
        $installer->endSetup();
    }
}
