<?php
namespace Dcs\HowTo\Block\Adminhtml\Howto;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

class SaveAndContinueButton implements ButtonProviderInterface
{
    public function getButtonData()
    {
        return [
                'label' => __('Save and Continue'),
                'class' => 'save',
                'on_click' => '',
                'sort_order' => 50,
                'data_attribute' => [
                    'mage-init' => [
                        'Magento_Ui/js/form/button-adapter' => [
                            'actions' => [
                                [
                                    'targetName' => 'howto_index_form.howto_index_form',
                                    'actionName' => 'save',
                                    'params' => [
                                        true,
                                        [
                                            'save_and_continue' => 1,
                                        ],
                                    ],
                                ],
                            ],
                        ],
                    ],

                ],
            ];
    }
}