<?php
namespace Dcs\HowTo\Block;

use Magento\Framework\View\Element\Template;

class HowTo extends Template
{
    public function _prepareLayout()
    {
        $this->_addBreadcrumbs();
        return parent::_prepareLayout();
    }

    protected $_howtos;

    protected $_resource;

    protected $_filterProvider;

    protected $_howtoCollection = null;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Maxime\Jobs\Model\Job $job
     * @param \Maxime\Jobs\Model\Department $department
     * @param \Magento\Framework\App\ResourceConnection $resource
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Dcs\HowTo\Model\HowTo $howtos,
        \Magento\Framework\App\ResourceConnection $resource,
        \Dcs\HowTo\Model\Category $category,
        \Dcs\HowTo\Helper\Data $howtoHelper,
        \Magento\Cms\Model\Template\FilterProvider $filterProvider,
        \Magento\Framework\Image\AdapterFactory $imageFactory,
        array $data = []
    ) {
        $this->_howtos = $howtos;
        $this->_resource = $resource;
        $this->_category = $category;
        $this->_howtoHelper = $howtoHelper;
        $this->_filterProvider = $filterProvider;
        $this->_imageFactory = $imageFactory;

        parent::__construct(
            $context,
            $data
        );
    }

    protected function _getHowToCollection()
    {
        if ($this->_howtoCollection === null) {
            $howtoCollection = $this->_howtos->getCollection()
                ->addFieldToSelect('*')
                ->addFieldToFilter('status', 1);
                // ->setOrder('rank', 'asc');
            ;

            $this->_howtoCollection = $howtoCollection;
        }

        return $this->_howtoCollection;
    }

    public function getLoadedHowToCollection()
    {
        if ($id = $this->getRequest()->getParam('id')) {
            return  $this->getHowToCollectionByCategory($id);
        }

        return $this->_getHowToCollection();
    }

    public function getHowToCollectionByCategory($category_id)
    {
        if (!$category_id) {
            return $this;
        }

        $category = $this->_category->load((int)$category_id);

        if ($category && $category->getId()) {
            $howtoCollection = $this->_howtos->getCollection()
                ->addFieldToSelect('*')
                ->addFieldToFilter('category_id', $category->getId())
                ->addFieldToFilter('status', 1);
                // ->setOrder('rank', 'asc');

            return $howtoCollection;
        }

        return $this;
    }

    public function getHowToById($id = null)
    {
        if ($id) {
            $model = $this->_howtos->load($id);
            if ($model && $model->getId()) {
                return $model;
            }
        }

        return false;
    }

    public function _getCategoryCollection()
    {
        $categoriesCollection = $this->_category->getCollection()
            ->addFieldToSelect('*')
            ->addFieldToFilter('status', 1);
            // ->setOrder('rank', 'asc');

        $this->_categoriesCollection = $categoriesCollection;

        return $this->_categoriesCollection;
    }

    public function getLoadedHowToCategoryCollection()
    {
        return $this->_getCategoryCollection();
    }

    public function isEnabled()
    {
        return $this->_howtoHelper->isEnabled();
    }

    public function getCmsFilterContent($value = '')
    {
        $html = $this->_filterProvider->getPageFilter()->filter($value);
        return $html;
    }

    public function getViewUrl($id = null)
    {
        if ($id) {
            return $this->getUrl('howto/index/view', ['id' => $id]);
        }

        return false;
    }

    public function getFileUrl($image = '')
    {
        $media_dir = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

        return $media_dir.$image;
    }
    protected function _addBreadcrumbs()
    {
        $breadcrumbsBlock = $this->getLayout()->getBlock('breadcrumbs');
        $baseUrl = $this->_storeManager->getStore()->getBaseUrl();
        $id = $this->getRequest()->getParam('id');
        $model = $this->_category->load($id);
        if ($model) {
            $this->pageConfig->getTitle()->set($model->getTitle());
        }
        if ($breadcrumbsBlock) {
            $breadcrumbsBlock->addCrumb(
                'home',
                [
                'label' => __('Home'),
                'title' => __('Go to Home Page'),
                'link' => $baseUrl
                ]
            );
              $breadcrumbsBlock->addCrumb(
                  'howto',
                  [
                  'label' => "How To Guides",
                  'title' => "How To Guides",
                  'link' => ($model && $model->getId())?$baseUrl."howto" : ""
                  ]
              );
            if ($model && $model->getId()) {
                $breadcrumbsBlock->addCrumb(
                    'howtocategory',
                    [
                    'label' => $model->getTitle(),
                    'title' => $model->getTitle(),
                    'link' => ''
                    ]
                );
            }
        }
    }

    public function getResizedUrl($image, $width = null, $height = null)
    {
        $absolutePath = $this->_filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)->getAbsolutePath().$image;

        $imageResized = $this->_filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)->getAbsolutePath('howto/resizedX'.$width.'/').$image;
        //create image factory...
        $imageResize = $this->_imageFactory->create();
        $imageResize->open($absolutePath);
        $imageResize->constrainOnly(true);
        $imageResize->keepTransparency(true);
        $imageResize->keepFrame(false);
        $imageResize->keepAspectRatio(false);
        $imageResize->resize($width, $height);
        //destination folder
        $destination = $imageResized ;
        //save image
        $imageResize->save($destination);

        $resizedURL = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'howto/resizedX'.$width.'/'.$image;

        return $resizedURL;
    }
    public function getSeourl($id = null)
    {
        if ($id) {
            return $this->getUrl($id);
        }
        return false;
    }
}
