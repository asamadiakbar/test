<?php

namespace Dcs\HowTo\Block;
 
use Magento\Framework\View\Element\Template;

class Category extends Template
{
    public function _prepareLayout()
    {
        return parent::_prepareLayout();
    }

    protected $_resource;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Maxime\Jobs\Model\Job $job
     * @param \Maxime\Jobs\Model\Department $department
     * @param \Magento\Framework\App\ResourceConnection $resource
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Dcs\HowTo\Model\Category $category,
        \Magento\Framework\App\ResourceConnection $resource,
        array $data = []
    ) {
        $this->_category = $category;
        $this->_resource = $resource;

        parent::__construct(
            $context,
            $data
        );
    }

    public function _getCategoryCollection()
    {
        $categoriesArray = $this->_category->getCollection()
            ->addFieldToSelect('*')
            ->addFieldToFilter('status', 1)
            // ->setOrder('rank', 'asc')
            ->load()
            ->toArray();

        return $categoriesArray;
    }
    public function getcatagorylist()
    {
        $categories = $this->_category->getCollection()
            ->addFieldToSelect('*')
            ->addFieldToFilter('status', 1)
            // ->setOrder('rank', 'asc')
            ->load();
        return $categories;
    }
    public function getLoadedHowToCategoryCollection()
    {
        $categories = ["" => "---Select Category---"];

        $categoriesArray = $this->_getCategoryCollection();
        if (count($categoriesArray) > 0) {
            foreach ($categoriesArray["items"] as $category) {
                $categories[$category['category_id']] = $category['title'];
            }
        }

        return $categories;
    }

    public function getCategoryUrl($id = null)
    {
        if ($id) {
            return $this->getUrl('howto', ['id' => $id]);
        }
        
        return false;
    }
    public function getSeourl($id = null)
    {
        if ($id) {
            return $this->getUrl($id);
        }
        return false;
    }
}
