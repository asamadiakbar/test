<?php

namespace Dcs\HowTo\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\Page;
 
class Search extends Action
{
    protected $resultPageFactory;
    protected $_howto;    

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        \Dcs\HowTo\Model\HowTo $howto,
        array $data = []
    )
    {
        $this->_howto = $howto;
        parent::__construct($context , $data);
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute()
    {
        ob_start();
        $keyword = $this->getRequest()->getParam('keyword');

        $howtoCollection = $this->_howto->getCollection()
            ->addFieldToSelect('*')
            ->addFieldToFilter(array('question','answer'),array(
                array('question' , array('like' => '%'.$keyword.'%')),
                array('answer' , array('like' => '%'.$keyword.'%')),
            ))
            ->addFieldToFilter('status' , 1);                  
            // ->setOrder('rank' , 'asc');

        $filter = \Magento\Framework\App\ObjectManager::getInstance();
        $html = "<div class=\"category-howtos\" data-mage-init='{\"accordion\":{\"openedState\": \"active\", \"collapsible\": true,  \"active\": false,\"multipleCollapsible\": false,\"animate\": true}}'>";

        $html .= "<span class=\"no-record\">".__("Search for ")."\"".$keyword."\".</span>";
        if(count($howtoCollection) > 0)
        {
            foreach ($howtoCollection as $howto){
                $howtoAnswer = $howto->getAnswer();					
                $filterAnswer = $filter->get('Magento\Cms\Model\Template\FilterProvider')->getPageFilter()->filter($howtoAnswer);
                $html .= "<div data-role=\"collapsible\"><div data-role=\"trigger\"><span>".$howto->getQuestion()."</span></div></div>";
                $html .= "<div data-role=\"content\">".$filterAnswer."</div>";
            }  
        }else{
            $html .= "<br/><span class='no-record'>". __("No records found.")."</span>";
        }
        $html .= "</div>";        
        echo $html;   	  
    }        
}