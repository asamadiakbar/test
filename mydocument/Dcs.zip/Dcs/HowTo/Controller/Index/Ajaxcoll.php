<?php

namespace Dcs\HowTo\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\Page;
 
class Ajaxcoll extends Action
{
    protected $resultPageFactory;
    protected $_howto;    

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        \Dcs\HowTo\Model\HowTo $howto,
        array $data = []
    )
    {
        $this->_howto = $howto;
        parent::__construct($context , $data);
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute()
    {
        ob_start();
        $id = $this->getRequest()->getParam('id');
        //var_dump($id, $this->getRequest()->getPostValue());
        $howtoCollection = $this->_howto->getCollection()
            ->addFieldToSelect('*')
            ->addFieldToFilter('status' , 1);
            ->setOrder('rank' , 'asc');
        if($id !=0 ){
            $howtoCollection->addFieldToFilter('category_id' , $id);
        }
        else{
            $howtoCollection->addFieldToFilter('category_id' , null);
        }

        $filter = \Magento\Framework\App\ObjectManager::getInstance(); 
        $html = "<div class=\"category-howtos\" data-mage-init='{\"accordion\":{\"openedState\": \"active\", \"collapsible\": true,  \"active\": false,\"multipleCollapsible\": false,\"animate\": true}}'>";
        $countCollection = $howtoCollection->count();
        if($countCollection > 0){
            foreach ($howtoCollection as $howto)
            {
                $howtoAnswer = $howto->getAnswer();
                $filterAnswer = $filter->get('Magento\Cms\Model\Template\FilterProvider')->getPageFilter()->filter($howtoAnswer);						
                $html .= "<div data-role=\"collapsible\"><div data-role=\"trigger\"><span>".$howto->getQuestion()."</span></div></div>";
                $html .= "<div data-role=\"content\">".$filterAnswer."</div>";
            }  
        } else {
            $html .= "<span class='no-record'>". __("Coming soon")."</span>";
        }
        $html .= "</div>";    	  
        echo $html;
    }
}
