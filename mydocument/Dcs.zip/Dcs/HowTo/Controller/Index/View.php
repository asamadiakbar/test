<?php

namespace Dcs\HowTo\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\Page;
use Dcs\HowTo\Helper\Data;
 
class View extends Action
{
    protected $resultPageFactory;
    protected $howtoHelper;

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        Data $howtoHelper,
        \Dcs\HowTo\Model\HowTo $howto
    ){
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->howtoHelper = $howtoHelper;
        $this->howto = $howto;
    }

    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
        if(!$this->howtoHelper->isEnabled()){
            $this->_redirect('noRoute');
        }

        if($id = $this->getRequest()->getParam('id')){
            $this->howto = $this->howto->load($id);
        }

        $resultPage->getConfig()->getTitle()->set(__($this->howto->getQuestion()));
        return $resultPage;
    }   
}
