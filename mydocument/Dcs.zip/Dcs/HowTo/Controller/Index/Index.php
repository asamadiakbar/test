<?php

namespace Dcs\HowTo\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\Page;
use Dcs\HowTo\Helper\Data;
 
class Index extends Action
{
    protected $resultPageFactory;
    protected $howtoHelper;

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        Data $howtoHelper
    ){
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->howtoHelper = $howtoHelper;
    }

    public function execute()
    {
        //return $this->resultPageFactory->create();
        $resultPage = $this->resultPageFactory->create();
        if(!$this->howtoHelper->isEnabled()){
            $this->_redirect('noRoute');
        }

        $resultPage->getConfig()->getTitle()->set(__("How To Guides"));
        return $resultPage;
    }   
}
