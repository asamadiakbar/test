<?php
namespace Dcs\HowTo\Controller;

use Magento\Framework\DataObject;

class Router implements \Magento\Framework\App\RouterInterface
{
    protected $actionFactory;
    protected $_response;
    protected $_Collection;
    protected $_eventManager;
    protected $__category;
    
    public function __construct(
        \Magento\Framework\App\ActionFactory $actionFactory,
        \Dcs\HowTo\Model\HowTo $Collection,
        \Dcs\HowTo\Model\Category $category,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Framework\App\ResponseInterface $response
    ) {
        
        $this->actionFactory = $actionFactory;
        $this->_category = $category;
        $this->_eventManager = $eventManager;
        $this->_Collection = $Collection;
        $this->_response = $response;
    }
    public function match(\Magento\Framework\App\RequestInterface $request)
    {
        $url_key = '';
        
        $url_key = trim($request->getPathInfo(), '/');
        $origUrlKey = $url_key;
        if ($request->getModuleName() === 'howto') {
                return;
        }
        $condition = new DataObject(['url_key' => $url_key, 'continue' => true]);
        $this->_eventManager->dispatch(
            'featured_controller_router_match_before',
            ['router' => $this, 'condition' => $condition]
        );
        $url_key = $condition->getUrlKey();
        if ($condition->getRedirectUrl()) {
            $this->_response->setRedirect($condition->getRedirectUrl());
            $request->setDispatched(true);
            return $this->actionFactory->create(
                'Magento\Framework\App\Action\Redirect',
                ['request' => $request]
            );
        }
        if (!$condition->getContinue()) {
            return null;
        }
        
        $collection = $this->_Collection->getCollection();
        $collection->addFieldToFilter('status', ['eq' => 1])->addFieldToFilter('url_key', ['eq' => $url_key])->getFirstItem();
        $storeid=null;
        $storename=null;
        foreach ($collection as $col) {
            $storeid=$col->getId();
            $storename=$col->getTitle();
            break;
        }
        if ($storeid!=null) {
            $request->setModuleName('howto')->setControllerName('index')->setActionName('view')->setParam('id', $storeid)->setParam('storename', $storename);
              $request->setAlias(\Magento\Framework\Url::REWRITE_REQUEST_PATH_ALIAS, $origUrlKey);
              return $this->actionFactory->create(
                  'Magento\Framework\App\Action\Forward',
                  ['request' => $request]
              );
        
        } else {
            $categories = $this->_category->getCollection()
            ->addFieldToFilter('status', 1)
            ->addFieldToFilter('url_key', ['eq' => $url_key]);
            $storeid1=null;
            $storename1=null;
            foreach ($categories as $col) {
                $storeid=$col->getId();
                break;
            }
            if ($storeid!=null) {
                $request->setModuleName('howto')->setControllerName('index')->setActionName('index')->setParam('id', $storeid)->setParam('storename', $storename);
                $request->setAlias(\Magento\Framework\Url::REWRITE_REQUEST_PATH_ALIAS, $origUrlKey);
                    return $this->actionFactory->create(
                        'Magento\Framework\App\Action\Forward',
                        ['request' => $request]
                    );
            } else {
                return;
            }
            
        }
    }
}
