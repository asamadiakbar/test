<?php
namespace Dcs\HowTo\Controller\Adminhtml\Category;
    
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\View\Result\PageFactory;
use Magento\Ui\Component\MassAction\Filter;
use Dcs\HowTo\Model\CategoryFactory;
use Dcs\HowTo\Model\Resource\Category\CollectionFactory;
 

 
class MassStatus extends Action
{
    protected $filter;
    protected $resultPageFactory;
    protected $collectionFactory;
    protected $categoryFactory;
    private $scopeConfig;
 
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        Filter $filter,
        CategoryFactory $categoryFactory,
        CollectionFactory $collectionFactory
    )
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->filter = $filter;
        $this->categoryFactory = $categoryFactory;
        $this->collectionFactory = $collectionFactory;
    }
 
    public function execute()
    {

        try {
            $collection = $this->filter->getCollection($this->collectionFactory->create());
            $updated = 0;
            foreach ($collection as $item) {
                $model = $this->categoryFactory->create()->load($item['category_id']);
                $model->setData('status', $this->getRequest()->getParam('status'));
                $model->save();
                $updated++;
            }
            if ($updated) {
                $this->messageManager->addSuccess(__('A total of %1 record(s) were updated.', $updated));
            }
 
        } catch (\Exception $e) {
            \Magento\Framework\App\ObjectManager::getInstance()->get('Psr\Log\LoggerInterface')->info($e->getMessage());
        }
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;
    }
 
    protected function _isAllowed()
    {
        return true;
    }
}