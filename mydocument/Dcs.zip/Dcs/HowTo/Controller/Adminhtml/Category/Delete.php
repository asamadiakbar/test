<?php
namespace Dcs\HowTo\Controller\Adminhtml\Category;

use Magento\Backend\App\Action;

class Delete extends \Magento\Backend\App\Action
{
    public function execute()
    {
        $id = $this->getRequest()->getParam('category_id');
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            try {
                // init model and delete
                $model = $this->_objectManager->create('Dcs\HowTo\Model\Category');
                $model->load($id);
                $model->delete();
                // display success message
                $this->messageManager->addSuccess(__('Your record has been deleted !'));
                return $resultRedirect->setPath('howto/category/index');
            } catch (Exception $e) {
                // display error message
                $this->messageManager->addError($e->getMessage());
                // go back to edit form
                return $resultRedirect->setPath('howto/category/edit', ['category_id' => $id]);
            }
        }
        // display error message
        $this->messageManager->addError(__('We can\'t find a epp to delete.'));
        return $resultRedirect->setPath('howto/category/index');
    }
}