<?php
/**
 * Copyright © 2015 Dcs. All rights reserved.
 */

namespace Dcs\HowTo\Controller\Adminhtml\Category;

class NewAction extends \Dcs\HowTo\Controller\Adminhtml\Category
{

    public function execute()
    {
        $this->_forward('edit');
    }
}
