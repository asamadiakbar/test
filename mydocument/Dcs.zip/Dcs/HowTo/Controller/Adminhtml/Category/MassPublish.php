<?php
namespace Dcs\HowTo\Controller\Adminhtml\Category;

//use Zdcs\Faq\Controller\Adminhtml\Items;
use Dcs\HowTo\Model\Category;
use Magento\Framework\Controller\ResultFactory;
use Magento\Backend\App\Action\Context;
use Magento\Ui\Component\MassAction\Filter;

class MassPublish extends \Magento\Backend\App\Action
{
    protected $filter;

    /**
     * @var CollectionFactory
     */
    protected $category;
    /**
     * @return void
     */
    public function __construct(Context $context, Filter $filter, Category $category)
    {
        $this->filter = $filter;
        $this->category = $category;
        parent::__construct($context);
    }

    public function execute()
    {
        $categoryIds = $this->getRequest()->getParam('category');
        if (!is_array($categoryIds) || empty($categoryIds)) {
            $this->messageManager->addError(__('Please select How To Category(s).'));
        } else {
            $categoryCollection = $this->category->getCollection()->addFieldToFilter('category_id', ['in' => $categoryIds]);
            try {
                foreach ($categoryIds as $categoryId) {
                    $model = $this->_objectManager->create('Dcs\HowTo\Model\Category')->load($categoryId);

                    if ($model->getId()) {
                        $model->setStatus('1');
                        $model->save();
                    }
                }
                
                $this->messageManager->addSuccess(
                    __('A total of %1 record(s) have been published.', count($categoryIds))
                );
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            }
        }

        $resultRedirect = $this->resultRedirectFactory->create();

        return $resultRedirect->setPath('*/*/');
    }
}
