<?php
/**
 * Copyright © 2015 Dcs. All rights reserved.
 */

namespace Dcs\HowTo\Controller\Adminhtml\Category;

class Index extends \Dcs\HowTo\Controller\Adminhtml\Category
{
    /**
     * Items list.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Dcs_HowTo::category');
        $resultPage->getConfig()->getTitle()->prepend(__('How To Guides Category Manager'));
        $resultPage->addBreadcrumb(__('Home'), __('Home'));
        $resultPage->addBreadcrumb(__('How To Category'), __('How To Guides Category'));
        return $resultPage;
    }
}
