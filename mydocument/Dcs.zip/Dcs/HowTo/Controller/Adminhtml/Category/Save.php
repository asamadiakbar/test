<?php
/**
 * Copyright © 2015 Dcs. All rights reserved.
 */

namespace Dcs\HowTo\Controller\Adminhtml\Category;

class Save extends \Dcs\HowTo\Controller\Adminhtml\Category
{
    public function execute()
    {
        
        if ($this->getRequest()->getPostValue()) {
            try {
                $model = $this->_objectManager->create('Dcs\HowTo\Model\Category');
                $data = $this->getRequest()->getPostValue();

                $inputFilter = new \Zend_Filter_Input(
                    [],
                    [],
                    $data
                );
                $data = $inputFilter->getUnescaped();
                $id = $this->getRequest()->getParam('category_id');
             
                if ($id) {
                    $model->load($id);
                    if ($id != $model->getId()) {
                        throw new \Magento\Framework\Exception\LocalizedException(__('The wrong item is specified.'));
                    }

                }

                $data['created_time'] = $this->datetime->gmtDate();
                $data['updated_time'] = $this->datetime->gmtDate();
                if ($model->getCreatedTime() == null && $model->getUpdatedTime() == null) {
                    $data['created_time'] = $this->datetime->gmtDate();
                    $data['updated_time'] = $this->datetime->gmtDate();
                } else {
                    $data['updated_time'] = $this->datetime->gmtDate();
                }
                if ($data['url_key']=='') {
                        $data['url_key'] = $data['title'];
                }
                        $url_key = $this->_objectManager->create('Magento\Catalog\Model\Product\Url')->formatUrlKey($data['url_key']);
                $data['url_key'] = $url_key;


                $model->setTitle($data['title']);
                $model->setUrlKey($data['url_key']);
                $model->setstatus($data['status']);
                $model->setCreatedTime($data['created_time']);
                $model->setUpdatedTime($data['updated_time']);
                $model->setRank($data['rank']);

                $session = $this->_objectManager->get('Magento\Backend\Model\Session');
                $session->setPageData($model->getData());

                $model->save();
                $this->messageManager->addSuccess(__('You saved the item.'));
                $session->setPageData(false);
                if ($this->getRequest()->getParam('save_and_continue')) {
                    $this->_redirect('howto/*/edit', ['category_id' => $model->getId()]);
                    return;
                }
                $this->_redirect('howto/*/');
                return;
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
                $id = (int)$this->getRequest()->getParam('id');
                if (!empty($id)) {
                    $this->_redirect('howto/*/edit', ['id' => $id]);
                } else {
                    $this->_redirect('howto/*/new');
                }
                return;
            } catch (\Exception $e) {
                $this->messageManager->addError(
                    __('Something went wrong while saving the item data. Please review the error log.')
                );
                $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
                $this->_objectManager->get('Magento\Backend\Model\Session')->setPageData($data);
                $this->_redirect('howto/*/edit', ['id' => $this->getRequest()->getParam('id')]);
                return;
            }
        }
        $this->_redirect('howto/*/');
    }
}
