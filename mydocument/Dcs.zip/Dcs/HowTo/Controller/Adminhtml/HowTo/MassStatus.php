<?php
namespace Dcs\HowTo\Controller\Adminhtml\HowTo;
    
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\View\Result\PageFactory;
use Magento\Ui\Component\MassAction\Filter;
use Dcs\HowTo\Model\HowToFactory;
use Dcs\HowTo\Model\Resource\HowTo\CollectionFactory;
 

 
class MassStatus extends Action
{
    protected $filter;
    protected $resultPageFactory;
    protected $collectionFactory;
    protected $howtoFactory;
    private $scopeConfig;
 
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        Filter $filter,
        HowToFactory $howtoFactory,
        CollectionFactory $collectionFactory
    )
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->filter = $filter;
        $this->howtoFactory = $howtoFactory;
        $this->collectionFactory = $collectionFactory;
    }
 
    public function execute()
    {

        try {
            $collection = $this->filter->getCollection($this->collectionFactory->create());
            $updated = 0;
            foreach ($collection as $item) {
                $model = $this->howtoFactory->create()->load($item['howto_id']);
                $model->setData('status', $this->getRequest()->getParam('status'));
                $model->save();
                $updated++;
            }
            if ($updated) {
                $this->messageManager->addSuccess(__('A total of %1 record(s) were updated.', $updated));
            }
 
        } catch (\Exception $e) {
            \Magento\Framework\App\ObjectManager::getInstance()->get('Psr\Log\LoggerInterface')->info($e->getMessage());
        }
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;
    }
 
    protected function _isAllowed()
    {
        return true;
    }
}