<?php
/**
 * Copyright © 2015 Dcs. All rights reserved.
 */

namespace Dcs\HowTo\Controller\Adminhtml\HowTo;

class NewAction extends \Dcs\HowTo\Controller\Adminhtml\HowTo
{
    public function execute()
    {
        $this->_forward('edit');
    }
}
