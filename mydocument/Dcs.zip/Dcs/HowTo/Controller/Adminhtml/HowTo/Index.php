<?php
/**
 * Copyright © 2015 Dcs. All rights reserved.
 */

namespace Dcs\HowTo\Controller\Adminhtml\HowTo;

class Index extends \Dcs\HowTo\Controller\Adminhtml\HowTo
{
    /**
     * Items list.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        /*if ($this->getRequest()->getQuery('ajax')) {
            $this->_forward('grid');
            return;
        }*/
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Dcs_HowTo::howto');
        $resultPage->getConfig()->getTitle()->prepend(__('How To Manager'));
        $resultPage->addBreadcrumb(__('Dcs'), __('Dcs'));
        $resultPage->addBreadcrumb(__('How To'), __('How To'));
        return $resultPage;
    }
}
