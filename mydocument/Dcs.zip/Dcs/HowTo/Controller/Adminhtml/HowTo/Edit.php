<?php
/**
 * Copyright © 2015 Dcs. All rights reserved.
 */

namespace Dcs\HowTo\Controller\Adminhtml\HowTo;

class Edit extends \Dcs\HowTo\Controller\Adminhtml\HowTo
{

    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        $model = $this->_objectManager->create('Dcs\HowTo\Model\HowTo');

        if ($id) {
            $model->load($id);
            if (!$model->getId()) {
                $this->messageManager->addError(__('This item no longer exists.'));
                $this->_redirect('howto/*');
                return;
            }
        }
        // set entered data if was error when we do save
        $data = $this->_objectManager->get('Magento\Backend\Model\Session')->getPageData(true);
        if (!empty($data)) {
            $model->addData($data);
        }
        $this->_coreRegistry->register('current_dcs_howto_howto', $model);
        $this->_initAction();
        $this->_view->getLayout()->getBlock('howto_howto_edit');
        $this->_view->renderLayout();
    }
}
