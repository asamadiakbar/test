<?php
/**
 * Copyright © 2015 Dcs. All rights reserved.
 */
namespace Dcs\HowTo\Controller\Adminhtml\HowTo;

use Magento\Framework\App\Filesystem\DirectoryList;

class Save extends \Magento\Framework\App\Action\Action
{
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Dcs\HowTo\Model\ImageUploader $imageUploader,
        \Dcs\HowTo\Model\FileUploader $fileUploader,
        \Magento\Framework\Stdlib\DateTime\DateTime $datetime

    ) {
        parent::__construct($context);
        $this->imageUploader = $imageUploader;
        $this->fileUploader = $fileUploader;
        $this->datetime = $datetime;
      }

    public function execute()
    {   
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($this->getRequest()->getPostValue()) {
            try {
                $model = $this->_objectManager->create('Dcs\HowTo\Model\HowTo');
                $data = $this->getRequest()->getPostValue();
    // echo "<pre>";
    //            print_r($data['howto_guidens_information']['preview_image']);
    //            exit();
                $inputFilter = new \Zend_Filter_Input(
                    [],
                    [],
                    $data
                );
                $data = $inputFilter->getUnescaped();
                $id = $this->getRequest()->getParam('howto_id');
                if ($id) {
                    $model->load($id);
                    if ($id != $model->getId()) {
                        throw new \Magento\Framework\Exception\LocalizedException(__('The wrong item is specified.'));
                    }
                }
                

                if (isset($data['howto_guidens']['category_id']) && empty($data['howto_guidens']['category_id'])) {
                    throw new \Magento\Framework\Exception\LocalizedException(__('How To Category not selected.'));
                }

               
                if ($model->getCreatedTime() == null && $model->getUpdatedTime() == null) {
                    $data['howto_guidens']['created_time'] = $this->datetime->gmtDate();
                    $data['howto_guidens']['updated_time'] = $this->datetime->gmtDate();
                } else {
                    $data['howto_guidens']['updated_time'] = $this->datetime->gmtDate();
                }

                if ($data['howto_guidens']['url_key']=='') {
                    $data['url_key'] = $data['howto_guidens']['question'];
                }
           
            
                $url_key = $this->_objectManager->create('Magento\Catalog\Model\Product\Url')->formatUrlKey($data['howto_guidens']['url_key']);
                $data['url_key'] = $url_key;

                if (isset($data['howto_guidens']['preview_image'])) {
               
                    if (isset($data['howto_guidens']['preview_image'][0]['name']) && isset($data['howto_guidens']['preview_image'][0]['tmp_name'])) {
                        $data['preview_image'] = $data['howto_guidens']['preview_image'][0]['name'];
                        $this->imageUploader->moveFileFromTmp($data['preview_image']);
                        $data['preview_image']=$data['preview_image'];

                    } elseif (isset($data['howto_guidens']['preview_image'][0]['name']) && !isset($data['howto_guidens']['preview_image'][0]['tmp_name'])) {
                        $data['preview_image'] = $data['howto_guidens']['preview_image'][0]['name'];
                        $data['preview_image'] =$data['preview_image'];
            
                    } else {
                        
                        $data['preview_image'] = '';
                    }
                       
                
                }else {
                  $data['preview_image'] = '';
                }

                if($model->getPreviewImage() == '' && $data['preview_image']) {
                     $data['preview_image'] = 'howto/image/'.$data['preview_image'];
                }
                
                if(isset($data['howto_guidens']['file']))
                {
                    if (isset($data['howto_guidens']['file'][0]['name']) && isset($data['howto_guidens']['file'][0]['tmp_name'])) {
                        $data['file'] = $data['howto_guidens']['file'][0]['name'];
                        $this->fileUploader->moveFileFromTmp($data['file']);
                        $data['file']=$data['file'];
                    } elseif (isset($data['howto_guidens']['file'][0]['name']) && !isset($data['howto_guidens']['file'][0]['tmp_name'])) {
                        $data['file'] = $data['howto_guidens']['file'][0]['name'];
                        $data['file'] = $data['file'];
            
                    } else {
                        
                        $data['file'] = '';
                    }
                }else {
                  $data['file'] = '';
                }  
                 //   echo "<pre>";
                 // print_r($data['howto_guidens']['data']['category_id']);
                 // exit(); 

                $model->setCategoryId($data['howto_guidens']['data']['category_id']);

                 //   echo "<pre>";
                 // print_r($data['howto_guidens']['data']['category_id']);
                 // exit(); 
                $model->setQuestion($data['howto_guidens']['question']);
                $model->setShortDescription($data['howto_guidens']['short_description']);
                $model->setAnswer($data['howto_guidens']['answer']);
                $model->setUrlKey($data['url_key']);
                $model->setVideoLink($data['howto_guidens']['video_link']);
                $model->setRank($data['howto_guidens']['rank']);
                $model->setStatus($data['howto_guidens']['status']);
                $model->setPreviewImage($data['preview_image']);
                $model->setFile($data['file']);
                $model->setCreatedTime($data['howto_guidens']['created_time']);
                $model->setUpdatedTime($data['howto_guidens']['updated_time']);
                
                $session = $this->_objectManager->get('Magento\Backend\Model\Session');
                $session->setPageData($model->getData());
                $model->save();
                $this->messageManager->addSuccess(__('You saved the item.'));
                $session->setPageData(false);

                if ($this->getRequest()->getParam('save_and_continue')) {
                    $this->_redirect('howto/*/edit', ['howto_id' => $model->getId()]);
                    return;
                }
                $this->_redirect('howto/*/');
                return;
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
                $this->_objectManager->get('Magento\Backend\Model\Session')->setPageData($data);
                $id = (int)$this->getRequest()->getParam('id');
                if (!empty($id)) {
                    $this->_redirect('howto/*/edit', ['id' => $id]);
                } else {
                    $this->_redirect('howto/*/new');
                }
                return;
            } catch (\Exception $e) {
                $this->messageManager->addError(
                    __('Something went wrong while saving the item data. Please review the error log.')
                );
                $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
                $this->_objectManager->get('Magento\Backend\Model\Session')->setPageData($data);
                $this->_redirect('howto/*/edit', ['id' => $this->getRequest()->getParam('id')]);
                return;
            }
        }
        $this->_redirect('howto/*/');
    }
}
