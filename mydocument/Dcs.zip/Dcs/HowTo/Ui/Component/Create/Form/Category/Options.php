<?php
namespace Dcs\HowTo\Ui\Component\Create\Form\Category;

use Magento\Framework\Data\OptionSourceInterface;
use Dcs\HowTo\Model\Resource\Category\CollectionFactory as CategoryCollectionFactory;
use Magento\Framework\App\RequestInterface;

/**
 * Options tree for "Categories" field
 */
class Options implements OptionSourceInterface
{
    /**
     * @var \Magento\Customer\Model\ResourceModel\Customer\CollectionFactory
     */
    protected $CategoryCollectionFactory;

    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * @var array
     */
    protected $categoryTree;

    /**
     * @param CustomerCollectionFactory $customerCollectionFactory
     * @param RequestInterface $request
     */
    public function __construct(
        CategoryCollectionFactory $categoryCollectionFactory,
        RequestInterface $request
    ) {
        $this->categoryCollectionFactory = $categoryCollectionFactory;
        $this->request = $request;
    }

    /**
     * {@inheritdoc}
     */
    public function toOptionArray()
    {
        return $this->getCategoryTree();
    }

    /**
     * Retrieve categories tree
     *
     * @return array
     */
    protected function getCategoryTree()
    {
        if ($this->categoryTree === null) {
            $collection = $this->categoryCollectionFactory->create();

            //$collection->addTitleToSelect();

            foreach ($collection as $category) {
                $categoryId = $category->getCategoryId();

                if (!isset($categoryById[$categoryId])) {
                    $categoryById[$categoryId] = [
                        'value' => $categoryId
                    ];
                }

                $categoryById[$categoryId]['label'] = $category->getTitle();
            }
            $this->categoryTree = $categoryById;
           
        }
        return $this->categoryTree;
    }
}