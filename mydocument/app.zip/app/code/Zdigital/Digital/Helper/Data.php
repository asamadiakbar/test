<?php

namespace Zdigital\Digital\Helper;

use Magento\Store\Model\ScopeInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper

{	

	

	protected  $customerSession;

	protected $storeManager;

	protected $_regionFactory;

	protected $_filesystem ;

    protected $_imageFactory;
     protected $serializer;
 



	public function __construct(

	\Magento\Framework\App\Helper\Context $context, 		

	\Magento\Customer\Model\Session $customerSession,	

	\Magento\Store\Model\StoreManagerInterface $storeManager,

	\Magento\Directory\Model\RegionFactory $regionFactory,

	\Magento\Framework\Filesystem $filesystem,         

    \Magento\Framework\Image\AdapterFactory $imageFactory,
    \Magento\Framework\Serialize\SerializerInterface $serializer

	) {

		$this->customerSession = $customerSession;

		$this->storeManager  = $storeManager;

		$this->_regionFactory = $regionFactory;

		$this->_filesystem = $filesystem;               

        $this->_imageFactory = $imageFactory; 

		parent::__construct($context);
		$this->serializer = $serializer;

	}

	public function isLoggedIn()  {

        return $this->customerSession->isLoggedIn();

    }

	public function getStoreno($store=null)	{

			return $this->getConfig("general/store_information/phone", $store);

	}

	public function getRegionIdByCode(){

		$code=$this->getRegionid();

		$region = $this->_regionFactory->create()->load($code);

		return $region->getName();

	}

	public function getStoreemail($store=null)	{

			return $this->getConfig("trans_email/ident_general/email", $store);

	}

	public function getRegionid($store=null)	{

			return $this->getConfig("general/store_information/region_id", $store);

	}

	public function getgooglecaptchaKey($store=null)	{

			return $this->getConfig("general/store_information/google_captcha", $store);

	}

	public function getConfig($type, $store = null) {

	

        return $this->scopeConfig->getValue($type, ScopeInterface::SCOPE_STORE, $store);

    }

	public function getCheckdevice()

	{

		$iphone = strpos($_SERVER['HTTP_USER_AGENT'],"iPhone");

		$android = strpos($_SERVER['HTTP_USER_AGENT'],"Android");

		$mobile = strpos($_SERVER['HTTP_USER_AGENT'],"Mobile");

		$palmpre = strpos($_SERVER['HTTP_USER_AGENT'],"webOS");

		$berry = strpos($_SERVER['HTTP_USER_AGENT'],"BlackBerry");

		$ipod = strpos($_SERVER['HTTP_USER_AGENT'],"iPod");

		$device="1";

		if ($iphone || ($android && $mobile) || $palmpre || $ipod || $berry == true)

		{

			$device= "2";

		}

		return $device;		

	}

	public function resize($image, $width = null, $height = null)

    {

        $absolutePath = $this->_filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)->getAbsolutePath('catalog/category/').$image;

        if (!file_exists($absolutePath)) return false;

        $imageResized = $this->_filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)->getAbsolutePath('catalog/product/cache/resized/'.$width.'/').$image;

        if (!file_exists($imageResized)) { // Only resize image if not already exists.

            //create image factory...

            $imageResize = $this->_imageFactory->create();         

            $imageResize->open($absolutePath);

            $imageResize->constrainOnly(TRUE);         

            $imageResize->keepTransparency(TRUE);         

            $imageResize->keepFrame(TRUE);         

            $imageResize->keepAspectRatio(TRUE);         

            $imageResize->quality(100);         

			$imageResize->backgroundColor([255, 255, 255]);

            $imageResize->resize($width,$height); 

            //destination folder                

            $destination = $imageResized ;    

            //save image      

            $imageResize->save($destination);         

        } 

        $resizedURL = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'catalog/product/cache/resized/'.$width.'/'.$image;

        return $resizedURL;

  }



  public function catBlogResize($image, $width = null, $height = null)

    {

       $absolutePath = $this->_filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)->getAbsolutePath('').$image; 

        if (!file_exists($absolutePath)) return false;

        $imageResized = $this->_filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)->getAbsolutePath('catalog/product/cache/resized/'.$width.'/').$image;

        if (!file_exists($imageResized)) { // Only resize image if not already exists.

            //create image factory...

            $imageResize = $this->_imageFactory->create();         

            $imageResize->open($absolutePath);

            $imageResize->constrainOnly(TRUE);         

            $imageResize->keepTransparency(TRUE);         

            $imageResize->keepFrame(TRUE);         

            $imageResize->keepAspectRatio(TRUE);         

            $imageResize->quality(100);         

			$imageResize->backgroundColor([255, 255, 255]);

            $imageResize->resize($width,$height); 

            //destination folder                

            $destination = $imageResized ;    

            //save image      

            $imageResize->save($destination);         

        } 

        $resizedURL = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'catalog/product/cache/resized/'.$width.'/'.$image;

        return $resizedURL;

  }

	public function getMediaurl()

	{

		return $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

	}

	public function CheckBadcharacter($email){

		$store = null;

		$sys_email= $this->getConfig("general/store_information/disallowed_email", $store);	

		$flag=false;

		$sys_email=explode(',', $sys_email);

		for($x = 0; $x < count($sys_email); $x++){

		 	if(strpos($email, $sys_email[$x]) !== false){

              return $flag = true;

            }

		}		

		return $flag;

	} 

	public function has_special_chars($string) {

    	return preg_match('/[^a-zA-Z0-9\d]/', $string);

	}

	public function getHeaderBanner()

	{

		$store = null;

		$Defalutbanner= $this->getConfig("digital_general/general/defaultbanner", $store);

		if($Defalutbanner){

			return $this->getMediaurl()."banner/".$Defalutbanner;

		}

		return null;

	}



	public function getPlaceholderimage()

	{

		$mediaUrl=$this->getMediaurl();

		$store=null;

		return $mediaUrl.'catalog/product/placeholder/'.$this->getConfig('catalog/placeholder/small_image_placeholder',$store);

	}
	public function getColourlist(){
		$loginbanner=$this->getConfig("camouser/view/color", null);
		if($loginbanner){
			return $decodedValue = $this->serializer->unserialize($loginbanner);
		}
	}
	public function getInterestedlist(){
		$loginbanner=$this->getConfig("camouser/view/interestedin", null);
		if($loginbanner){
			return $decodedValue = $this->serializer->unserialize($loginbanner);
		}
	}

	public function getEnquiryTypeList(){
		$enquiryTypes=$this->getConfig("contact/email/enquiry_type", null);
		if($enquiryTypes){
			return $this->serializer->unserialize($enquiryTypes);
		}
	}

}

