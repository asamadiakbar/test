<?php

namespace Zdigital\Digital\Plugin;
class afterSourceSelectionDataProvider
{
	public function afterGetData(\Magento\InventoryShippingAdminUi\Ui\DataProvider\SourceSelectionDataProvider $subject, $result )
	{  
    	$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $request = $objectManager->get('\Magento\Framework\App\RequestInterface');
        $orderId = (int)$request->getParam('order_id');
        $sourceList = $objectManager->get('\Magento\Inventory\Model\ResourceModel\Source\Collection');
        $sourceListArr = $sourceList->load();
        $result[$orderId]['sourceCodes'] = [];
        foreach ($sourceListArr as $sourceItemName) {
            $sourceCode = $sourceItemName->getSourceCode();
            $sourceName = $sourceItemName->getName();
            $result[$orderId]['sourceCodes'][] = [
                'value' => $sourceCode,
                'label' => $sourceName
            ];
        }
		return $result;
	}
}