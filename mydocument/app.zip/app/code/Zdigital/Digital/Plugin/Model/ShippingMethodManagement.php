<?php
namespace Zdigital\Digital\Plugin\Model;

class ShippingMethodManagement {

    public function afterEstimateByAddress($shippingMethodManagement, $output)
    {
        return $this->filterOutput($output);
    }

    public function afterEstimateByExtendedAddress($shippingMethodManagement, $output)
    {
        return $this->filterOutput($output);
    }

    public function afterEstimateByAddressId($shippingMethodManagement, $output)
    {
        return $this->filterOutput($output);
    }


    private function filterOutput($output)
    {
        $free = [];
        $freeshipping = false;

        foreach ($output as $shippingMethod) {
            if ($shippingMethod->getCarrierCode() == 'freeshipping' && $shippingMethod->getMethodCode() == 'freeshipping') {
                $free[] = $shippingMethod;
                $freeshipping = true;
            }
        }
        foreach ($output as $shippingMethod) {
            /*pickup is always visible - freeshipping not metter*/
            if ($freeshipping == true && $shippingMethod->getCarrierCode() == 'mpcustomshipping') {
                $free[] = $shippingMethod;
            }
            /*render is always visible - freeshipping not metter*/
            if ($freeshipping == true && $shippingMethod->getCarrierCode() == 'digitalrendr'){
                $free[] = $shippingMethod;
            }
        }
        if ($free) {
            return $free;
        }
        return $output;
    }
}