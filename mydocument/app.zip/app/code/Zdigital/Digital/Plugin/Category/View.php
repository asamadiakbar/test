<?php
namespace Zdigital\Digital\Plugin\Category;
class View extends \Magento\Catalog\Controller\Category\View
{
    public function afterExecute(\Magento\Catalog\Controller\Category\View $subject, $result)
    {
	 
      $category = $this->_coreRegistry->registry('current_category');
      if(!$category) { return $result; }
	  $SubCategories = $category->getChildrenCategories();

	  $active=false;	
	  if($SubCategories){
		  foreach($SubCategories as $cat){
			  if($cat->getIsActive()){
				$active=true;	  
				 break; 
			  }
		  }
		  if($active)
		  {
			  $result->getConfig()->setPageLayout('1column');
			  $result->getLayout()->unsetChild('columns','div.sidebar.main');
              $result->getLayout()->unsetChild('columns','div.sidebar.additional');
		  }
	  }	
      return $result;
    }
}