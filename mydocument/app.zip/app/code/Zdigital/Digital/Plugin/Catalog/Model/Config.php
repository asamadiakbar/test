<?php

namespace Zdigital\Digital\Plugin\Catalog\Model;

class Config
{
    public function afterGetAttributeUsedForSortByArray(
    \Magento\Catalog\Model\Config $catalogConfig,
    $options
    ) {
    	//unset($options['position']);
    	unset($options['price']);
    	unset($options['name']);
    	//$options['position'] = __( 'Relevance' );
    	$options['asc_name'] = __('A – Z');
        $options['desc_name'] = __('Z – A');
        $options['low_to_high'] = __('Price low to high');
        $options['high_to_low'] = __('Price high to low');
        
        return $options;

    }

}