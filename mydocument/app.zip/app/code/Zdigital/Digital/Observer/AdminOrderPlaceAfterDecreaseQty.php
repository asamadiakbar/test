<?php
namespace Zdigital\Digital\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Sales\Api\OrderRepositoryInterface;

class AdminOrderPlaceAfterDecreaseQty implements ObserverInterface { 
  
    private $sourceItemsSaveInterface;
    private $sourceItemInterfaceFactory;
    private $sourceItemsBySku;
    private $ZdigitalHelper;
    protected $_coreSession;
    private $serializerBase;
    protected $_checkoutSession;


    public function __construct(
       \Magento\InventoryApi\Api\SourceItemsSaveInterface $sourceItemsSaveInterface,
       \Magento\InventoryApi\Api\Data\SourceItemInterfaceFactory $sourceItemInterfaceFactory,
       \Magento\InventoryApi\Api\GetSourceItemsBySkuInterface $sourceItemsBySku,
       \Zdigital\Digital\Helper\Data $ZdigitalHelper,
       \Magento\Catalog\Model\ProductRepository $productRepository,
       \Magento\Framework\Session\SessionManagerInterface $coreSession,
       \Amasty\Base\Model\Serializer $serializerBase,
       \Magento\Checkout\Model\Session $checkoutSession


    ) {
	     $this->sourceItemsSaveInterface = $sourceItemsSaveInterface;
       $this->sourceItemInterfaceFactory = $sourceItemInterfaceFactory;
       $this->sourceItemsBySku = $sourceItemsBySku;
       $this->_ZdigitalHelper = $ZdigitalHelper;
       $this->_productRepository = $productRepository;
       $this->_coreSession = $coreSession;
       $this->serializerBase = $serializerBase;
       $this->_checkoutSession = $checkoutSession;


 
    }


  
    public function execute(\Magento\Framework\Event\Observer $observer) {    
      try{  
            $this->_coreSession->start();
            $this->_coreSession->unsShippingSelectionFlag();
            $threshold_min_qty  = $this->_ZdigitalHelper->getConfig('cataloginventory/item_options/min_qty',1);  
            $order = $observer->getEvent()->getOrder();
            $shippingMethodName = $order->getShippingMethod();
            $deliveryType=strtolower($shippingMethodName);
            if($shippingMethodName == 'mpcustomshipping_mpcustomshipping' || strpos($deliveryType, 'digitalrendr') !== false){
                  if(strpos($deliveryType, 'digitalrendr') !== false){
                    $selectedStoreCode = $this->_checkoutSession->getSelectedMsiStoreCode();
                        if(!$selectedStoreCode){
                            $selectedStoreCode = '217';
                        }
                  } 
              if($shippingMethodName == 'mpcustomshipping_mpcustomshipping'){
                    $selectedStoreCode = $order->getPickupStoreCode();  
              } 
              foreach ($order->getAllItems() as $item)
              { 
                if($item->getProductType() == 'configurable')
                {
                    continue;
                }

                /*if manage stock no then prevent to decrease qty */
                $productId = $item->getProductId();
                $_product = $this->_productRepository->getById($productId);

                /*111 gift card qty should not minus */
                $options = $item->getProductOptions('info_buyRequest'); 
                if ($options) {   
                    if(isset($options['am_giftcard_type'])){
                       if($options['am_giftcard_type'] == 1){
                           continue;
                       }
                    }
                }
                if($_product->getTypeId() === 'amgiftcard' && (int)$_product->getAmGiftcardType() === 1){
                 continue;
                }
                /*-/ 111 gift card qty should not minus */


                $backorderStatus = $_product->getExtensionAttributes()->getStockItem()->getBackorders();
                $manageStockStatus = $_product->getExtensionAttributes()->getStockItem()->getManageStock();
                if($manageStockStatus == 0){ continue; }

                /*decrease qty source wise code */
                $product_sku = $item->getSku();
                $ordered_qty = $item->getQtyOrdered(); 
                $storeWiseQtyArray = $this->getSourceItemBySku($product_sku);
                foreach ($storeWiseQtyArray as $storeQty) {
                  if($storeQty->getSourceCode() == $selectedStoreCode){ 
                        $productAvailableQty = $storeQty->getQuantity();
                        $productAvailableQtyAfterOrder =  $productAvailableQty-$ordered_qty;
                        $sourceItem = $this->sourceItemInterfaceFactory->create();
                        $sourceItem->setSourceCode($selectedStoreCode);
                        $sourceItem->setSku($product_sku);
                        $sourceItem->setQuantity($productAvailableQtyAfterOrder);
                        /*backorder always disabled for pickup*/
                        /*$sourceItem->setStatus(1);*/
                        /*if($backorderStatus != 0){
                                $sourceItem->setStatus(1);
                        }else{*/
                        $sourceItem->setStatus(($productAvailableQtyAfterOrder <= $threshold_min_qty)?0:1);
                        /*}*/
                        $this->sourceItemsSaveInterface->execute([$sourceItem]);
                  }
                }
              }  
            }else{
              $selectedStoreCode = 'online_store';
              foreach ($order->getAllItems() as $item)
              { 
                if($item->getProductType() == 'configurable')
                {
                    continue;
                }
                $productId = $item->getProductId();
                $_product = $this->_productRepository->getById($productId);

                /*111 gift card qty should not minus */
                $options = $item->getProductOptions('info_buyRequest'); 
                if ($options) {   
                    if(isset($options['am_giftcard_type'])){
                       if($options['am_giftcard_type'] == 1){
                           continue;
                       }
                    }
                }
                if($_product->getTypeId() === 'amgiftcard' && (int)$_product->getAmGiftcardType() === 1){
                 continue;
                }
                /*-/ 111 gift card qty should not minus */

                $backorderStatus = $_product->getExtensionAttributes()->getStockItem()->getBackorders();
                $manageStockStatus = $_product->getExtensionAttributes()->getStockItem()->getManageStock();
                if($manageStockStatus == 0){ continue; }
       
                $product_sku = $item->getSku();
                $ordered_qty = $item->getQtyOrdered(); 
                $storeWiseQtyArray = $this->getSourceItemBySku($product_sku);
                foreach ($storeWiseQtyArray as $storeQty) {
                  if($storeQty->getSourceCode() == $selectedStoreCode){ 
                        $productAvailableQty = $storeQty->getQuantity();
                        $productAvailableQtyAfterOrder =  $productAvailableQty-$ordered_qty;
                        $sourceItem = $this->sourceItemInterfaceFactory->create();
                        $sourceItem->setSourceCode($selectedStoreCode);
                        $sourceItem->setSku($product_sku);
                        $sourceItem->setQuantity($productAvailableQtyAfterOrder);
                        if($backorderStatus != 0){
                                $sourceItem->setStatus(1);
                        }else{
                        $sourceItem->setStatus(($productAvailableQtyAfterOrder <= $threshold_min_qty)?0:1);
                        }
                        $this->sourceItemsSaveInterface->execute([$sourceItem]);
                  }
                }
              }  
            }
        } catch (Exception $e){
          $writer_try = new \Zend\Log\Writer\Stream(BP.'/var/log/orderPlaceAfterQtyDecreaseObserver.log');
          $logger_try = new \Zend\Log\Logger();
          $logger_try->addWriter($writer_try);
          $logger_try->info(">>>TRY CATCH ERROR===>".$e->getMessage()."<<<");
      } 
  }

  public function getSourceItemBySku($sku)
  {
       return $this->sourceItemsBySku->execute($sku);
  }
}