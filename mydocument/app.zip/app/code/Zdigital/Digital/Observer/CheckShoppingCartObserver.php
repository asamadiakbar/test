<?php
namespace Zdigital\Digital\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Checkout\Model\Cart as CustomerCart;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\App\Response\RedirectInterface;
use Magento\Framework\Event\Observer;

class CheckShoppingCartObserver implements ObserverInterface
{
    /**
     * @var ManagerInterface
     */
    protected $messageManager;

    /**
     * @var RedirectInterface
     */
    protected $redirect;

    /**
     * @var Cart
     */
    protected $cart;


    protected $_coreSession;

    /**
     * @param ManagerInterface $messageManager
     * @param RedirectInterface $redirect
     * @param CustomerCart $cart
     */
    public function __construct(
        ManagerInterface $messageManager,
        RedirectInterface $redirect,
        CustomerCart $cart,
        \Magento\Framework\Session\SessionManagerInterface $coreSession

    ) {
        $this->messageManager = $messageManager;
        $this->redirect = $redirect;
        $this->cart = $cart;
        $this->_coreSession = $coreSession;        
    }

    /**
     * Validate Cart Before going to checkout
     * - event: controller_action_predispatch_checkout_index_index
     *
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        $quote = $this->cart->getQuote();
        $controller = $observer->getControllerAction();    
    
        //If shipping not selected then redirect to cart page forcefully
        if ($this->_coreSession->getShippingSelectionFlag() != 'true' && !$quote->isVirtual()) {
            /*$this->messageManager->addErrorMessage(
                __('Please select delivery method!')
            );*/
            $this->redirect->redirect($controller->getResponse(), 'checkout/cart');
        }
    }
}