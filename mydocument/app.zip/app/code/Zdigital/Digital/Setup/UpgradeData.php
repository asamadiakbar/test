<?php

namespace Zdigital\Digital\Setup;



use Magento\Eav\Model\Entity\Attribute\SetFactory as AttributeSetFactory;

use Magento\Framework\Setup\UpgradeDataInterface;

use Magento\Framework\Setup\ModuleDataSetupInterface;

use Magento\Framework\Setup\ModuleContextInterface;

use Magento\Eav\Setup\EavSetup;

use Magento\Eav\Setup\EavSetupFactory;

class UpgradeData implements UpgradeDataInterface

{

 	 private $eavSetupFactory;



    public function __construct(EavSetupFactory $eavSetupFactory) {

        $this->eavSetupFactory = $eavSetupFactory;

    }



 	public function upgrade( ModuleDataSetupInterface $setup, ModuleContextInterface $context ) {

		

		if( version_compare($context->getVersion(), '1.1.1', '<' )) {

			$setup->startSetup();

        	

 

         $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

         $eavSetup->addAttribute(\Magento\Catalog\Model\Category::ENTITY, 'is_homepage', [

            'type'     => 'int',

            'label'    => 'Is HomePage',

            'input'    => 'boolean',

            'source'   => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',

            'visible'  => true,

            'default'  => '0',

            'required' => false,

            'global'   => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,

            'group'    => 'Display Settings',

         ]);

         $setup->endSetup();		

		}	

        if( version_compare($context->getVersion(), '1.1.2', '<' )) {

            $setup->startSetup();
 

         $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

            $eavSetup->addAttribute(
                        \Magento\Catalog\Model\Category::ENTITY,
                        'category_short_description',
                        [
                            'group' => 'Display Settings',
                            'label' => 'Category Short Description',
                            'type'  => 'text',
                            'input' => 'textarea',
                            'required' => false,
                            'sort_order' => 1,
                            'global' => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_STORE,
                            'used_in_product_listing' => true,
                            'visible_on_front' => true
                        ]
                    );

         $setup->endSetup();        

        }

        if( version_compare($context->getVersion(), '1.1.4', '<' )) {

            $setup->startSetup();
 

         $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

            $eavSetup->addAttribute(
                        \Magento\Catalog\Model\Category::ENTITY,
                        'megamenu_description',
                        [
                            'type' => 'text',
                            'label' => 'Mega Menu Description',
                            'input' => 'textarea',
                            'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                            'wysiwyg_enabled' => true,
                            'is_html_allowed_on_front' => true,
                            'required' => false,
                            'sort_order' => 10,
                            'global' => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_STORE,
                            'used_in_product_listing' => true,
                            'visible_on_front' => true
                        ]
                    );

         $setup->endSetup();        

        }

 	}

}