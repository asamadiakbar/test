<?php
namespace Zdigital\Digital\Ui\Component\Listing\Column;

use \Magento\Sales\Api\OrderRepositoryInterface;
use \Magento\Framework\View\Element\UiComponent\ContextInterface;
use \Magento\Framework\View\Element\UiComponentFactory;
use \Magento\Ui\Component\Listing\Columns\Column;
use \Magento\Framework\Api\SearchCriteriaBuilder;

class ProductInfo extends Column
{
    protected $_orderRepository;
    protected $_searchCriteria;

    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        OrderRepositoryInterface $orderRepository,
        SearchCriteriaBuilder $criteria,
        array $components = [],
        array $data = [])
    {
        $this->_orderRepository = $orderRepository;
        $this->_searchCriteria  = $criteria;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$items) {
                $productArr = [];
                $order  = $this->_orderRepository->get($items["entity_id"]);

                foreach ($order->getAllVisibleItems() as $item) {
                    $proPrice = '$'.number_format((float)$item->getPriceInclTax(), 2, '.', '');
                    $producName[] = $item->getName();
                    $productSku[] = $item->getSku();
                    $productPrice[] = $item->getPrice();
                    $productQty[] = $item->getQtyOrdered();
                    $ProductInformation[] = $item->getName().",".$item->getSku().",".$proPrice.",".(int)$item->getQtyOrdered();
                    /*$productQty = $item->getQtyOrdered();*/
                }

                /*$itemName = implode("", $producName);
                $itemSku = implode("", $productSku);
                $itemPrice = implode("", $productPrice);*/
                /*$itemQty = implode("", $productQty);*/

                /*$itemInfo = $itemName.",".$itemSku.",".$itemPrice.";";*/
                $items['productinfo'] = implode(";",$ProductInformation);
                unset($ProductInformation);
            }
        }
        return $dataSource;
    }
}