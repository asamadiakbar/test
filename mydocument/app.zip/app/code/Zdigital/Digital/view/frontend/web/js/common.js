require(['jquery','jscrollpane','owlcarouselmin','mousewheel'],function($){

var globalWidthVar,globalHeightVar;

	jQuery(document).ready(function(){

		var globalWidthVar = jQuery(window).width(), globalHeightVar = jQuery(window).height();
		
		var ajaxReqStatus = 'NotInProgress';
		$('.checkout-index-index').on('click touchend', '.setstorepickup_btn', function (){
			$(this).attr('checked','checked');
			$(this).siblings().attr('checked','checked');
			var selected_store = $("input[name='storepickup_selection']:checked").attr("data-store-name");
			var store_region = $("input[name='storepickup_selection']:checked").attr("data-store-region");
			var store_street = $("input[name='storepickup_selection']:checked").attr("data-store-street");
			var store_city = $("input[name='storepickup_selection']:checked").attr("data-store-city");
			var store_postcode = $("input[name='storepickup_selection']:checked").attr("data-store-postcode");
			var store_phone = $("input[name='storepickup_selection']:checked").attr("data-store-phone");
			var store_email = $("input[name='storepickup_selection']:checked").attr("data-store-email");
			var store_code = $("input[name='storepickup_selection']:checked").attr("data-store-code");
	        var dataUrl = BASE_URL+'storepickup/index/setselectedpickupstore';
	        if(selected_store != '')
	        {   
	        	
	            ajaxReqStatus = $.ajax(
	            {
	                url:dataUrl,
	                type: 'post',
	                dataType : 'json',
	                async: true,
	                showLoader:true,
	                data: { selected_store : selected_store, 
	                	store_region : store_region, 
	                	store_street : store_street, 
	                	store_city : store_city, 
	                	store_postcode : store_postcode,
	                	store_phone : store_phone,
	                	store_email : store_email,
	                	store_code : store_code },
	                beforeSend : function() {
		                if(ajaxReqStatus != 'NotInProgress') {
		                    ajaxReqStatus.abort();
		                }
               		}
	            }).done(function(transport) {}
	            ).always(
	            function () {
	            }
	            );
	        }
        });



        $('body').on('click touchend', '.hide-store-link', function (){
						$('#checkout_pickup_options').hide();
						$('.show-stores').show();

        });

        $('body').on('click touchend', '.show-store-link', function (){
						$('.show-stores').hide();
						$('#checkout_pickup_options').show();

        });

        $('body').on('click touchend', '.show-allstore-link', function (){
						$('.toogle-store').show();
						$('.show-all-stores').hide();
						$('.hide-all-stores').show();

        });
        $('body').on('click touchend', '.hide-allstore-link', function (){
						$('.toogle-store').hide();
						$('.show-all-stores').show();
						$('.hide-all-stores').hide();

        });

        $('body').on('click touchend', '.chnage-postcode-link', function (){
			$('.storepickup_container').detach();
			$('#estimate_postcode').val('');
			$('#estimate_postcode').focus();
			$('.check_store, #estimate_postcode').show();
            $('.pickup-selected-address').html('');
            $('.pickup-selected-address-wrap').hide();
        });

	/* Start product Hover image */

	//Selector to select the products li items
   var productItem = $('.product-item-info');
   //Function to replace the picture of the product when the product item is hovered with mouse
   productItem.hover(function (event) {
     //Hover on product li Item
     var productImage = $(event.target).parents('.product-item-info').find('.photo.image'),
      productImageHover = $(event.target).parents('.product-item-info').find('.photo-image-hover');
     productImage.removeClass('photo-currently-hovered');
     productImage.addClass('photo-currently-not-hovered');
     productImageHover.removeClass('photo-currently-not-hovered');
     productImageHover.addClass('photo-currently-hovered');
    },
    //Hover out
    function (event) {
     var productImage,
      productImageHover,
     myTarget = $(event.target);
 
     if ($(event.target).hasClass('product-item-info')) {
      productImage = myTarget.find('.photo.image');
      productImageHover = myTarget.find('.photo-image-hover');
     } else {
      productImage = myTarget.parents('.product-item-info').find('.photo.image');
      productImageHover = myTarget.parents('.product-item-info').find('.photo-image-hover');
     }
     productImageHover.removeClass('photo-currently-hovered');
     productImageHover.addClass('photo-currently-not-hovered');
     productImage.removeClass('photo-currently-not-hovered');
     productImage.addClass('photo-currently-hovered');
    });
	/* End product Hover image*/

	/* Add Touch And No Touch Class Start */
		var isTouchDevice = 'ontouchstart' in document.documentElement;
		if( isTouchDevice ) {
			jQuery('html').addClass('touch').removeClass('no-touch');
		} else {
			jQuery('html').addClass('no-touch').removeClass('touch');
		}
	/* Add Touch And No Touch Class End */
	
          $(document).ready(function () {
            $('.home-vertical-banner-slider').owlCarousel({
			    loop:true,
			    margin:10,
			    autoplay:true,
		    	autoplayTimeout:2500,
		    	autoplayHoverPause:true,
			    responsiveClass:true,
			    responsive:{
			        0:{
			            items:2,
			            nav:false
			        },
			        375:{
			            items:2,
			            nav:false,
			            margin:15
			        },		        
			        570:{
			            items:2,
			            nav:false,
			            margin:20
			        },
			        768:{
			            items:4,
			            nav:false,
			            margin:20
			        },
			        1000:{
			            items:4,
			            nav:false,
			            loop:false,
			            margin:30
			        }
			    }
		    })
            $('.homepage_cat').owlCarousel({
			    loop:true,
			    margin:10,
			    responsiveClass:true,
			    autoplay:true,
			    autoplayTimeout:2500,
			    autoplayHoverPause:true,
			    responsive:{
			        0:{
			            items:1,
			            nav:false
			        },
			        375:{
			            items:2,
			            nav:false,
			            margin:15
			        },		        
			        570:{
			            items:2,
			            nav:false,
			            margin:20
			        },
			        768:{
			            items:4,
			            nav:false,
			            margin:20
			        },
			        1000:{
			            items:4,
			            nav:false,
			            loop:false,
			            margin:30
			        }
			    }
			})
        });

	/* Custom Scroll Strat */
	if($("body").hasClass("cms-home")) {
		jQuery('.read-more-btn').click(function(){
				jQuery('.read-more-content').toggle();
				jQuery('.read-more-btn').toggleClass('less');
				jQuery('.read-more-btn').text('Read More');
				jQuery('.read-more-btn.less').text('Read Less');

			});
		/*$('.about-content').jScrollPane({autoReinitialise:1,showArrows:true});
		$( window ).resize(function() {
			$('.about-content').jScrollPane({autoReinitialise:1,showArrows:true});
		});*/
	}
	    if (globalWidthVar > 991) {
			$('.submenu-scroll').jScrollPane({autoReinitialise:1});
			$( window ).resize(function() {
				$('.submenu-scroll').jScrollPane({autoReinitialise:1});
			});
		}
		
		/*Disabled Scroll as per SEO team Request on 27Jan2022 */
		/*$('.description-content-main').jScrollPane();
		$( window ).resize(function() {
			$('.description-content-main').jScrollPane();
		});*/

		/* Custom Scroll End */

		jQuery('.sidebar-cms .trigger').click(function(){
			if($(this).hasClass("open"))
			{
				$(this).removeClass('open');
				$(this).addClass('close');
				$(this).closest(".title").siblings('ul').hide();
			}
			else {
				$(this).removeClass('close');
				$(this).addClass('open');
				$(this).closest(".title").siblings('ul').show();
			//jQuery('li .groups ul').slideToggle();
			}
		});

		jQuery('.footer-accordian-title').click(function(){
			if(jQuery(window).width()<992) {
				
				jQuery(this).closest('.links').siblings('.links').find('.footer-accordian-title').removeClass('active');
				jQuery(this).closest('.links').siblings('.links').find('.footer-accordian-content').slideUp(500,"swing");
				jQuery(this).toggleClass('active');
				jQuery(this).closest('.links').find('.footer-accordian-content').slideToggle();
			}
		});

	     /*max length*/		

		jQuery('input[type="text"]').attr('maxlength', 50);							

		jQuery("textarea , #message").attr("maxlength",1000);		

		jQuery('#email,#email_address,#confirm_email,#login-email,#newsletter').attr({ maxLength : 75});

		jQuery('#password,#confirmation').attr({ maxLength : 22});

		jQuery('#postcode,#zipcode, [id="billing:postcode"]').attr({ maxLength : 6});

		jQuery('[id="billing:email"]').attr({ maxLength : 75});		

		jQuery('[id="billing:telephone"], #fax,#telephone,#telephone,input[type="tel"]').attr({ maxLength : 18});

		jQuery('[id="billing:street1"]').attr({ maxLength : 250});		

		jQuery('#ccsave_cc_number').attr({ maxLength : 16});

		jQuery('#ccsave_cc_cid').attr({ maxLength : 4});

		jQuery('.wishlist-index-share #email_address').attr({ maxLength : 100});

		jQuery('#qty,.qty').attr('maxlength', 3);		

		jQuery('input[data-maxlength="data-maxlength"]').attr('maxlength', 1000);

		/*end max length*/

		/*Add Sticky Class*/
		jQuery(window).scroll(function (event) {
			var headerheight = parseInt(jQuery('header').height());			
			if(jQuery(window).scrollTop() > headerheight) {		
				jQuery('header').addClass('header-sticky');						
			}else{	
				jQuery('header').removeClass('header-sticky');		 				 	
			}			
	    });	

       /* Menu sction */
        jQuery('.navigation > ul > li.level0').each(function(){
        	 if(jQuery(this).children('.submenu-outer').length > 0) {
				jQuery(this).hover(
				  function () {					
					jQuery('body').addClass("menu_active");			
				  },
				  function () {
					jQuery('body').removeClass("menu_active");
				  }
				);
			}
			});
 				

		/*footer */
		/*Active class*/
	  jQuery(function() {
	  	setTimeout(function() {
			jQuery('.brand-menu-main').removeClass('ui-menu-item');		 				 	
		}, 5000);

        var url = window.location.href,
            urlRegExp = new RegExp(url.replace(/\/$/, '') + "$");

          jQuery('nav.navigation ul li a, .sidebar_category_list li a').each(function() {
			if (urlRegExp.test(this.href.replace(/\/$/, ''))) {
				jQuery(this).parents('li').addClass('active-menu active');
			}
		  });
		  jQuery('footer li a, .links li a, .footer-col2 li a').each(function() {
            if (urlRegExp.test(this.href.replace(/\/$/, ''))) {
                jQuery(this).parent().addClass('active');
            }
        });  
jQuery('.sidebar-cms li a').each(function() {
            if (urlRegExp.test(this.href.replace(/\/$/, ''))) {
                jQuery(this).parent().addClass('active');
            }
        });  		
       });

	  jQuery(".scroll_top").click(function(){
		jQuery('html, body').animate({
			scrollTop:0
		}, 2000);
	});
	  jQuery(window).scroll(function() {
	  	if(jQuery(window).scrollTop() > 100) {
		jQuery('.scroll_top').addClass('visible');
	}
	else {
		jQuery('.scroll_top').removeClass('visible');
	}
	  });

		/*orientationchange change after reload*/

		window.onload=function(e){		

			if (globalWidthVar >= 768 && globalWidthVar <= 1024) {

				window.addEventListener('orientationchange', function() {

					 window.location.reload();

				});

			}

		}

		$('.block-search .block-title').click(function(){
                $('body').toggleClass('show-search');
                setTimeout(function(){
                	if ($("body").hasClass("show-search")) {
						jQuery('input#search').focus();
						jQuery('input#search').trigger('click');    
					}            	
				},100);
        });
		jQuery('body').click(function(e){
			var container = $(".block-search");
			if (!container.is(e.target) && container.has(e.target).length === 0) 
   	 		{
       			jQuery("body").removeClass("show-search");	
    		}	   
		});

		/*********************Mobile Menu ************************/
		
		if(jQuery(window).width() < 1024){
			jQuery(".close-icon").on('click touchend', function (e) {
				jQuery('html').removeClass('nav-open');
				setTimeout(function() {
					jQuery('html').removeClass('nav-before-open');
				}, 100);
			});
			jQuery(".navigation > ul > li.level0.parent > a").after('<span class="level0-ico-corner level0-ico-close"></span>');
            jQuery("ul.level0 > li.level1.parent > a").after('<span class="level1-ico-corner level0-ico-close" ></span>');
            jQuery("ul.level1 >  li.level2.parent > a").after('<span class="level2-ico-corner level0-ico-close"></span>');
            jQuery("ul.level2 >  li.level3.parent > a").after('<span class="level3-ico-corner level0-ico-close"></span>');
            jQuery("ul.level3 >  li.level4.parent > a").after('<span class="level4-ico-corner level0-ico-close"></span>');
			
			jQuery.each(jQuery(".navigation > ul > li > a"), function(index, value){							
				jQuery(this).parent().find(".level0-ico-corner").bind('click touchend', function(e) {
					e.stopImmediatePropagation();
					e.stopPropagation();
					//console.log(jQuery(this));
					jQuery(this).parents('li.level0').siblings('li').find('ul.level0').slideUp();					
					jQuery(this).parents("li").siblings("li").find("a").removeClass("ui-state-active");
					jQuery(this).parents("li").siblings("li").find("span.level0-ico-corner").removeClass("ui-state-active");
					jQuery(this).parents("li").siblings("li").removeClass("ui-state-active");
					jQuery(this).toggleClass("ui-state-active");					
					jQuery(this).parent("li").find(".level0").slideToggle();
					e.stopPropagation();
					return false;
				}); 					 		 
				/*jQuery(this).bind('click touchend', function(e) {
					e.preventDefault();
					 jQuery(this).parent("li").siblings().find("ul.level1").slideUp(500,"swing"); 
					 window.location.href = jQuery(this).attr('href');						 
					return false;
				});*/
			});
			
            jQuery.each(jQuery(".navigation li.level1 > a"), function(index, value){
				jQuery(this).parent().find(".level1-ico-corner").bind('click touchend', function(e) {
					e.stopImmediatePropagation();
					e.stopPropagation();
					jQuery(this).parent("li.level1.parent").find("ul.level1 > li").removeClass("active");
					jQuery(this).closest('li').siblings('li').find('ul.level1').slideUp();					
					jQuery(this).parent("li").siblings("li").find("a").removeClass("ui-state-active");
					jQuery(this).parent("li").siblings("li").find("span.level1-ico-corner").removeClass("ui-state-active");
					jQuery(this).parent("li").siblings("li").removeClass("ui-state-active");
					jQuery(this).toggleClass("ui-state-active");
					jQuery(this).parent("li").find(".level1").slideToggle();
					e.stopPropagation();
					return false;
				}); 					 		 
				/*jQuery(this).bind('click touchend', function(e) {
					e.preventDefault();
					 jQuery(this).parent("li").siblings().find("ul.level1").slideUp(500,"swing"); 
					 window.location.href = jQuery(this).attr('href');						 
					return false;
				});*/
			});
			jQuery.each(jQuery(".navigation li.level2 > a"), function(index, value){				
				jQuery(this).parent().find(".level2-ico-corner").bind('click touchend', function(e) {
					e.stopImmediatePropagation();
					e.stopPropagation();
					jQuery(this).parent("li.level1.parent").find("ul.level2 > li").removeClass("active");
					jQuery(this).closest('li').siblings('li').find('ul.level2').slideUp();					
					jQuery(this).parent("li").siblings("li").find("a").removeClass("ui-state-active");
					jQuery(this).parent("li").siblings("li").find("span.level1-ico-corner").removeClass("ui-state-active");
					jQuery(this).parent("li").siblings("li").removeClass("ui-state-active");
					jQuery(this).toggleClass("ui-state-active");
					jQuery(this).parent("li").find(".level2").slideToggle();
					e.stopPropagation();
					return false;
				}); 					 		 
				/*jQuery(this).bind('click touchend', function(e) {
					e.preventDefault();
					 jQuery(this).parent("li").siblings().find("ul.level2").slideUp(500,"swing"); 
					 window.location.href = jQuery(this).attr('href');						 
					return false;
				});*/
			});
			jQuery.each(jQuery(".navigation li.level3 > a"), function(index, value){				
				jQuery(this).parent().find(".level3-ico-corner").bind('click touchend', function(e) {
					e.stopImmediatePropagation();
					e.stopPropagation();
					jQuery(this).parent("li.level1.parent").find("ul.level3 > li").removeClass("active");
					jQuery(this).closest('li').siblings('li').find('ul.level3').slideUp();					
					jQuery(this).parent("li").siblings("li").find("a").removeClass("ui-state-active");
					jQuery(this).parent("li").siblings("li").find("span.level1-ico-corner").removeClass("ui-state-active");
					jQuery(this).parent("li").siblings("li").removeClass("ui-state-active");
					jQuery(this).toggleClass("ui-state-active");
					jQuery(this).parent("li").find(".level3").slideToggle();
					e.stopPropagation();
					return false;
				}); 					 		 
					/*jQuery(this).bind('click touchend', function(e) {
					e.preventDefault();
					 jQuery(this).parent("li").siblings().find("ul.level3").slideUp(500,"swing"); 
					 window.location.href = jQuery(this).attr('href');						 
					return false;
				});*/
			});
			jQuery(".navigation li > a").click(function (e) {
                if (jQuery(this).attr("href") != "") {
                    e.preventDefault();
                    window.location.href = jQuery(this).attr("href");
                    e.stopImmediatePropagation();
                    return false;
                }
            });
			jQuery('.close-icon').click(function(){
				 jQuery('html').removeClass("nav-before-open nav-open");
				 jQuery('.level0-ico-corner').removeClass('ui-state-active');
			 });
			jQuery('.nav-sections-items .section-item-title').click(function(){
				 jQuery('.level0-ico-corner').removeClass('ui-state-active');
			});
			 
		}

		if(jQuery(window).width() < 1024){
			$('.description-content-main').jScrollPane({autoReinitialise:1,showArrows:true});
			$( window ).resize(function() {
				$('.description-content-main').jScrollPane({autoReinitialise:1,showArrows:true});
			});
		}
		


});

});