var config = {	
	paths: {		
		
		'jscrollpane': 'Zdigital_Digital/js/jquery.jscrollpane.min',
		'selectdrop': 'Zdigital_Digital/js/select2.min',
		'mousewheel': 'Zdigital_Digital/js/jquery.mousewheel'		
	},
	shim: {		
		
		'jscrollpane': {deps: ['jquery']},
		'selectdrop': {deps: ['jquery']},
		'mousewheel': {deps: ['jquery']}
	}
};