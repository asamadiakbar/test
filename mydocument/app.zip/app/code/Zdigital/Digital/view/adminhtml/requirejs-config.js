var config = {
    "map": {
        "*": {
            productGallery: "Zdigital_Digital/js/product-gallery",
            "Magento_Catalog/js/product-gallery": "Zdigital_Digital/js/product-gallery"
        }
    }
}