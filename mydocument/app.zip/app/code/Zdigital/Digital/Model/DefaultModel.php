<?php
namespace Zdigital\Digital\Model; 
class DefaultModel extends \Magento\Captcha\Model\DefaultModel
{
   protected $dotNoiseLevel = 0;	
   protected $lineNoiseLevel = 0;	
   protected function _generateImage($id, $word){
	    $w     = 100;	   
        $h     = 200;
        $fsize = $this->getFontSize();
   }
}
