<?php
namespace Zdigital\Digital\Model\Plugin;

class EmailNotification
{
    public function aroundNewAccount(\Magento\Customer\Model\EmailNotification $subject, \Closure $proceed)
    {
        return $subject;
    }
}