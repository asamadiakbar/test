<?php

namespace Zdigital\Digital\Model\Export;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Filesystem;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Ui\Model\Export\MetadataProvider;

class ConvertToCsv extends \Magento\Ui\Model\Export\ConvertToCsv
{
    /**
     * @var DirectoryList
     */
    protected $directory;

    /**
     * @var MetadataProvider
     */
    protected $metadataProvider;

    /**
     * @var int|null
     */
    protected $pageSize = null;

    /**
     * @var Filter
     */
    protected $filter;

    /**
     * @param Filesystem $filesystem
     * @param Filter $filter
     * @param MetadataProvider $metadataProvider
     * @param int $pageSize
     * @throws FileSystemException
     */
    public function __construct(
        Filesystem $filesystem,
        Filter $filter,
        MetadataProvider $metadataProvider,
        $pageSize = 200
    ) {
        $this->filter = $filter;
        $this->directory = $filesystem->getDirectoryWrite(DirectoryList::VAR_DIR);
        $this->metadataProvider = $metadataProvider;
        $this->pageSize = $pageSize;
    }

    /**
     * Returns CSV file
     *
     * @return array
     * @throws LocalizedException
     */
    public function getCsvFile()
    {
        $component = $this->filter->getComponent();


        $name = md5(microtime());
        $file = 'export/'. $component->getName() . $name . '.csv';

        $this->filter->prepareComponent($component);
        $this->filter->applySelectionOnTargetProvider();
        $dataProvider = $component->getContext()->getDataProvider();
    //exit(get_class($dataProvider));
        $fields = $this->metadataProvider->getFields($component);

        $options = $this->metadataProvider->getOptions();

        $this->directory->create('export');
        $stream = $this->directory->openFile($file, 'w+');
        $stream->lock();
        $stream->writeCsv($this->metadataProvider->getHeaders($component));
        $i = 1;
        $searchCriteria = $dataProvider->getSearchCriteria()
        ->setCurrentPage($i)
        ->setPageSize($this->pageSize);
        $totalCount = (int) $dataProvider->getSearchResult()->getTotalCount();
		
        while ($totalCount > 0) {
            $items = $dataProvider->getSearchResult()->getItems();
        //  echo '<pre>'; print_r(get_class($dataProvider)); exit;
            foreach ($items as $item) {
                if($component->getName()=='sales_order_grid') {
                    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                    $order = $objectManager->create('Magento\Sales\Model\Order')->load($item->getEntityId());
                    $orderItems = $order->getAllItems();
                    $orderProductSku = [];
                    $orderProductName = [];
                    $ProductInformation = [];
                    foreach ($orderItems as $sales_order)
                    {   

                        if($sales_order->getProductType() == 'configurable'){
                            $proPrice = $sales_order->getPriceInclTax();
                            continue;
                        }else{
                            if (!$sales_order->getParentItem()){
                                $proPrice = $sales_order->getPriceInclTax();
                            }
                        }
                            $proPriceFormatted = number_format((float)$proPrice, 2, '.', '');
							$orderProductSku[] = $sales_order->getSku();
                            $orderProductName[] = $sales_order->getName();
                            $ProductInformation[] = $sales_order->getName().",".$sales_order->getSku().","."$".$proPriceFormatted.",".(int)$sales_order->getQtyOrdered();
                    }					

					$export_sku = implode(", ", $orderProductSku);
					$export_name = implode(", ", $orderProductName);
                    $exportProductInfo = implode(";", $ProductInformation);
					$item->setSku($export_sku);
					$item->setProducts($export_name);
                    $item->setProductinfo($exportProductInfo);

                }
				
                
                $this->metadataProvider->convertDate($item, $component->getName());
                $stream->writeCsv($this->metadataProvider->getRowData($item, $fields, $options));
            }
            $searchCriteria->setCurrentPage(++$i);
            $totalCount = $totalCount - $this->pageSize;
        }
        $stream->unlock();
        $stream->close();

        return [
            'type' => 'filename',
            'value' => $file,
        'rm' => true  // can delete file after use
    ];
}
}
