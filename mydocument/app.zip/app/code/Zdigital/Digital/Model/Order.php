<?php
namespace Zdigital\Digital\Model;
class Order extends \Magento\Sales\Model\Order
{
	/*public function getorderComment()
	{
		return $this->getData('onestepcheckout_order_comment');
	}
	public function getHeaderLogoUrl(){
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$helperFactory = $objectManager->get('\Digital\Camouser\Helper\Data');
		if($helperFactory->getEmaillogo($this->getCustomerGroupId())){
            return $url= $helperFactory->getEmaillogo($this->getCustomerGroupId());
        }        
	}
	public function getASCustomerGroupid(){
		$groupid=$this->getCustomerGroupId();
		if($groupid=="4" || $groupid=="5"){
			return $this->getHeaderLogoUrl();
		}
	}*/
	public function getCustomerinfo(){
		if(!$this->getCustomerIsGuest()){			
			$customerid=$this->getCustomerId();			
			$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$customer = $objectManager->create('Magento\Customer\Model\Customer')->load($customerid);
			$groupid=$this->getCustomerGroupId();
			if($groupid=="4" || $groupid=="5"){
				    $html="<table class='message-details' border='1' cellspacing='0' cellpadding='10' width='100%'> ";
					$html .="<tr>";
					$html .="<td><strong>Email ID</strong></td>";
					$html .='<td>'.$this->getCustomerEmail().'</td>';					
					$html .="</tr>";
					$html .="<tr>";
					$html .="<td><strong>Customer Name</strong></td>";
					$html .='<td>'.$this->getCustomerFirstname().' '.$this->getCustomerLastname().'</td>';					
					$html .="</tr>";
					$html .="<tr>";
					if($groupid=="4"){
						$html .="<td><strong>School Name</strong></td>";
						$html .='<td>'.$customer->getSchoolname().'</td>';					
						$html .="</tr>";
						$html .="<tr>";
						$html .="<td><strong>School code</strong></td>";
						$html .='<td>'.$customer->getSchoolcode().'</td>';
					}elseif($groupid=="5"){
						$html .="<td><strong>Explorer  Name</strong></td>";
						$html .='<td>'.$customer->getScoutname().'</td>';					
						$html .="</tr>";
						$html .="<tr>";
						$html .="<td><strong>Explorer  code</strong></td>";
						$html .='<td>'.$customer->getScoutcode().'</td>';
					}
					$html .="</tr>";
					$html .="</table>";
			return $html;
			}
		}
	}
}