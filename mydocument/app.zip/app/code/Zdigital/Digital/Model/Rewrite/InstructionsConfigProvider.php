<?php 
namespace Zdigital\Digital\Model\Rewrite;
 
class InstructionsConfigProvider extends \Magento\OfflinePayments\Model\InstructionsConfigProvider

{
    public function getInstructions($code)
    {
        if($code == 'banktransfer'){
            return nl2br($this->methods[$code]->getInstructions());
        }else{
            return nl2br($this->escaper->escapeHtml($this->methods[$code]->getInstructions()));
        }
    }

}