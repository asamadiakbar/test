<?php
namespace Zdigital\Digital\Cron;

use \Psr\Log\LoggerInterface;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Framework\FileSystem;
use Magento\Framework\Mail\Template\TransportBuilder;


class CustomerReportMailWeekly {

    protected $logger;
    private $fileFactory;
    private $directory;
    private $FileSystem;
    private $transportBuilder;
    protected $scopeConfig;
    protected $_timezoneInterface;
	protected $_customerFactory;

    public function __construct(
        Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        FileSystem $FileSystem,
        LoggerInterface $logger,
        FileFactory $fileFactory,
        TransportBuilder $transportBuilder,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezoneInterface,
		\Magento\Customer\Model\CustomerFactory $customerFactory


        ) {
            $this->FileSystem = $FileSystem;
            $this->fileFactory = $fileFactory;
            $this->logger = $logger;
            $this->transportBuilder = $transportBuilder;
            $this->_scopeConfig = $scopeConfig;
            $this->_timezoneInterface = $timezoneInterface;
			$this->_customerFactory = $customerFactory;

         }

	/**
    * cleanup the logs tables.
    *
    * @return void
    */

    public function execute() {
       /**********/   
        //Get Object Manager Instance
        $objectManager  = \Magento\Framework\App\ObjectManager::getInstance();
        $objDate = $objectManager->create('Magento\Framework\Stdlib\DateTime\DateTime');
        $currentDateTime = $objDate->gmtDate('Y-m-d');
		
        $this->logger->info('Order Weekly Report cron started..!');
        /*create csv code */
            $directory = $this->FileSystem->getDirectoryWrite(DirectoryList::VAR_DIR);
            $filePathCUS = 'cron_export/customerWeeklyReport.csv';
            $directory->create('cron_export');
            $streamc = $directory->openFile($filePathCUS, 'w+');
            $streamc->unlock();
            $columns = ['ID','Name', 'Email', 'Phone', 'ZIP','Country','State/Province','Billing Address','Shipping Address','Date of Birth','Gender','Street Address','City','Company','Billing Firstname','Billing Lastname','Colour Camo Club Card'];
 
            foreach ($columns as $column) {
                $header[] = $column;
            }
			$_dcshelper = $objectManager->get('Zdigital\Digital\Helper\Data');
			$getlist=$_dcshelper->getInterestedlist();
			$list=array();
			foreach($getlist as $value){
				$interestin=trim($value['flagno']); 				
				$list[$interestin]=$value['interested_in'];		
				$header[]=trim($value['flagno']);
			}
            $streamc->writeCsv($header);
        $currentfullDateTime = $objDate->gmtDate('Y-m-d H:i').':00';
        $currentfullDateTime1 = $objDate->gmtDate('Y-m-d H:i').':59';
        $startDate = date("Y-m-d H:i:s", strtotime($currentfullDateTime .' -7 day'));
        $endDate = date("Y-m-d H:i:s",strtotime($currentfullDateTime1.'-1 minute'));

        /*$startDate = date("Y-m-d H:i:s", strtotime($currentDateTime .' 17:00:00 -7 day'));

        $endDate = date("Y-m-d H:i:s",strtotime($currentDateTime.' 17:00:00'));*/
		
		$customerFactory = $objectManager->create('Magento\Customer\Model\CustomerFactory')->create();
		$customerCollection = $customerFactory->getCollection()->addAttributeToSelect("*")->addAttributeToFilter('group_id','1')
		->addAttributeToFilter('created_at', array('from'=>$startDate, 'to'=>$endDate))->load();				
        
			
        if(count($customerCollection) > 0){
             foreach ($customerCollection as $customer) {
				 $csvArr = [];   
                $csvArr[]=$customer->getId();
			$csvArr[]=$customer->getName();
			$csvArr[]=$customer->getEmail();			
			$csvArr[]="\t".$customer->getPrimaryBillingAddress()->getTelephone();;
			$csvArr[]=$customer->getPrimaryBillingAddress()->getPostcode();;
			$csvArr[]=$customer->getPrimaryBillingAddress()->getCountryId();;
			$csvArr[]=$customer->getPrimaryBillingAddress()->getRegion();;
			//$csvArr[]=$customer->getCreatedAt();
			
			$street=$customer->getPrimaryBillingAddress()->getStreet();
			$billingstreetaddress= is_array($street) ? implode("\n", $street) : $street;
			$csvArr[]=$billingstreetaddress." ".$customer->getPrimaryBillingAddress()->getCity()." ".$customer->getPrimaryBillingAddress()->getPostcode();
			
			$shippingstreet=$customer->getPrimaryShippingAddress()->getStreet();
			$shippingstreetaddress= is_array($street) ? implode("\n", $street) : $street;
			
			$csvArr[]= $shippingstreetaddress." ".$customer->getPrimaryShippingAddress()->getCity()." ".$customer->getPrimaryShippingAddress()->getPostcode();
			$csvArr[]=$customer->getDob();			
			$Gender="";
			
			if($customer->getGender() == "1"){
				$Gender="M";
			}elseif($customer->getGender() == "2"){
					$Gender="F";
			}
			$csvArr[]=$Gender;			
			$streetaddress= is_array($street) ? implode("\n", $street) : $street;
			$csvArr[]=$streetaddress;
			$csvArr[]=$customer->getPrimaryBillingAddress()->getCity();
			$csvArr[]=$customer->getPrimaryBillingAddress()->getCompany();
			$csvArr[]=$customer->getPrimaryBillingAddress()->getFirstname();
			$csvArr[]=$customer->getPrimaryBillingAddress()->getLastname();
			$csvArr[]=$customer->getCamocolor();
			$InterestedIn=explode(',',$customer->getInterestedIn());						
			foreach ($list as $key => $value) {								
				if(in_array($value, $InterestedIn)){
					$csvArr[]="1";
				}else{
					$csvArr[]="";
				}
			}
                $streamc->writeCsv($csvArr);
             }
        }

    try {
		
		$csvContentCus=null;
        $directory = $objectManager->get('\Magento\Framework\Filesystem\DirectoryList');
        $csvfilePathcustomer = $directory->getPath('var').'/'.$filePathCUS;
        $csvContentCus = file_get_contents($csvfilePathcustomer);

       $adminEmail = $this->getSalesEmail();
	   $senderEmail = $this->getSenderEmail();
       $adminName  = $this->getSalesName();
	   
	   
	   
	   //$add_bcc=array("mail1@gmail.com","mail2@outlook.com");
       $templateVars = [];
       if(count($customerCollection) > 0){
            $transport = $this->transportBuilder->setTemplateIdentifier('customer_report_weekly_email_template')
            ->setTemplateOptions( [ 'area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => 1 ] )
            ->setTemplateVars( $templateVars )
            ->setFrom( [ "name" => $adminName, "email" => $senderEmail ] )
            ->addTo($adminEmail)
			->addBCC("test31.23digital@gmail.com")
            ->setReplyTo($adminEmail)
            ->addAttachment($csvContentCus,'Customer_Weekly_Report_'.$currentDateTime.'.csv', 'application/csv')
            ->getTransport();
            $transport->sendMessage();
            $this->logger->info('mail sent');
        }else{
            $transport = $this->transportBuilder->setTemplateIdentifier('order_report_weekly_no_customer_email_template')
            ->setTemplateOptions( [ 'area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => 1 ] )
            ->setTemplateVars( $templateVars )
            ->setFrom( [ "name" => $adminName, "email" => $senderEmail ] )
            ->addTo($adminEmail)
            ->setReplyTo($adminEmail)
            ->getTransport();
            $transport->sendMessage();
            $this->logger->info('mail sent');

        }
        return $this;
        } catch (Exception $e) {
            $this->logger->error($e);
        }

        $this->logger->info('Customer Report Mail Weekly cron ended..! '.$currentDateTime);

        return $this;
    }

    public function getSalesEmail()
    {
        return $this->_scopeConfig->getValue(
            'camouser/view/report_admin_email',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getSalesName()
    {
        return $this->_scopeConfig->getValue(
            'trans_email/ident_sales/name',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
	public function getSenderEmail()
    {
        return $this->_scopeConfig->getValue(
            'trans_email/ident_sales/email',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

}