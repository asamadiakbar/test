<?php
namespace Zdigital\Digital\Cron;

use \Psr\Log\LoggerInterface;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Framework\FileSystem;
use Magento\Framework\Mail\Template\TransportBuilder;


class OrderReportMailMonthly {

    protected $logger;
    private $fileFactory;
    private $directory;
    private $FileSystem;
    private $transportBuilder;
    protected $scopeConfig;
    protected $_timezoneInterface;

    public function __construct(
        Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        FileSystem $FileSystem,
        LoggerInterface $logger,
        FileFactory $fileFactory,
        TransportBuilder $transportBuilder,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezoneInterface


        ) {
            $this->FileSystem = $FileSystem;
            $this->fileFactory = $fileFactory;
            $this->logger = $logger;
            $this->transportBuilder = $transportBuilder;
            $this->_scopeConfig = $scopeConfig;
            $this->_timezoneInterface = $timezoneInterface;
         }

	/**
    * cleanup the logs tables.
    *
    * @return void
    */

    public function execute() {
       
        $this->logger->info('Monthly Order Report cron started..!');

        /*create csv code */
            $directory = $this->FileSystem->getDirectoryWrite(DirectoryList::VAR_DIR);
            $filePath = 'cron_export/orderMonthlyReport.csv';
            $directory->create('cron_export');
            $stream = $directory->openFile($filePath, 'w+');
            $stream->unlock();
            $columns = ['Order Date','Order ID', 'Email', 'Amount', 'Payment Method','Order Status'];
 
            foreach ($columns as $column) {
                $header[] = $column;
            }
            $stream->writeCsv($header);

         /**********/   
        //Get Object Manager Instance
        $objectManager  = \Magento\Framework\App\ObjectManager::getInstance();
        $objDate = $objectManager->create('Magento\Framework\Stdlib\DateTime\DateTime');

        $currentDateTime  = $objDate->gmtDate('Y-m-d');
        $lastMonth = $objDate->gmtDate('m')-01;
        $lastMonthDateTime  = $objDate->gmtDate('Y-'.$lastMonth.'-d');
        
        $ordersCollectionFactory = $objectManager->create('Magento\Sales\Model\ResourceModel\Order\CollectionFactory');
        $collection = $ordersCollectionFactory->create()
         ->addAttributeToSelect('*');

        /*for avoid date filter issue i hardcoded seconds here*/
        $currentfullDateTime = $objDate->gmtDate('Y-m-d H:i').':00';
        $currentfullDateTime1 = $objDate->gmtDate('Y-m-d H:i').':59';

        /*cron running on 10 am so i am minus 10 hours from time so it will calulate from 12 am */
        $startDate1 = date("Y-m-d H:i:s", strtotime($currentfullDateTime .' -10 hour'));
        $endDate1 = date("Y-m-d H:i:s",strtotime($currentfullDateTime1.'-10 hour')); 

        /*here i am minus 1 month for get previous month date */
        $startDate = date("Y-m-d H:i:s", strtotime($startDate1 .' -1 month'));
        $endDate = date("Y-m-d H:i:s",strtotime($endDate1.'-1 minute')); 
        
        /* 
        $startDate = date("Y-m-d H:i:s", strtotime($lastMonthDateTime .' 00:00:00'));
        $endDate = date("Y-m-d H:i:s",strtotime($currentDateTime.' 00:00:00'));*/

        $collection = $ordersCollectionFactory->create()
            ->addAttributeToFilter('created_at', array('from'=>$startDate, 'to'=>$endDate));
        $csvArr = [];   
        if(count($collection) > 0){
	         foreach ($collection as $key => $orderData) {
	            $csvArr = [];
                $orderDate = $orderData->getCreatedAt();
                $orderFormtattedDate = $this->_timezoneInterface
                                                ->date(new \DateTime($orderDate))
                                                ->format('d/m/y h:i:s A');
                $csvArr[] = $orderFormtattedDate;
	            $orderIncrementId = $orderData->getIncrementId();
	            $csvArr[] =  '#'.$orderIncrementId;
	            $csvArr[] = $orderData->getCustomerEmail();
	            $formatedTotal = number_format($orderData->getBaseGrandTotal(), 2, '.', '');
	            $csvArr[] = '$'.$formatedTotal;  
	            
	            $orderLoad = $objectManager->create('Magento\Sales\Model\Order')->loadByIncrementId($orderIncrementId);
	                $payment = $orderLoad->getPayment();
	                $method = $payment->getMethodInstance();
	                $methodTitle = $method->getTitle();
	            $csvArr[] = $methodTitle;
                $csvArr[] = $orderData->getStatus();
	            $stream->writeCsv($csvArr);
	       
	         }
     	}

    try {

        $directory = $objectManager->get('\Magento\Framework\Filesystem\DirectoryList');
        $csvfilePath = $directory->getPath('var').'/'.$filePath;
        $csvContent = file_get_contents($csvfilePath);

       $adminEmail = $this->getSalesEmail();
       $adminName  = $this->getSalesName();
       $templateVars = [];
       if(count($collection) > 0){
	        $transport = $this->transportBuilder->setTemplateIdentifier('order_report_monthly_email_template')
	        ->setTemplateOptions( [ 'area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => 1 ] )
	        ->setTemplateVars( $templateVars )
	        ->setFrom( [ "name" => $adminName, "email" => $adminEmail ] )
	        ->addTo($adminEmail)
	        ->setReplyTo($adminEmail)
	        ->addAttachment($csvContent,'Order_Monthly_Report_'.$currentDateTime.'.csv', 'application/csv')
	        ->getTransport();
	        $transport->sendMessage();
	        $this->logger->info('mail sent');
    	}else{
    		$transport = $this->transportBuilder->setTemplateIdentifier('order_report_monthly_no_order_email_template')
	        ->setTemplateOptions( [ 'area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => 1 ] )
	        ->setTemplateVars( $templateVars )
	        ->setFrom( [ "name" => $adminName, "email" => $adminEmail ] )
	        ->addTo($adminEmail)
	        ->setReplyTo($adminEmail)
	        ->getTransport();
	        $transport->sendMessage();
	        $this->logger->info('mail sent');
    	}
        return $this;   
        } catch (Exception $e) {
            $this->logger->error($e);
        }

        $this->logger->info('Monthly Order Report cron ended..! '.$currentDateTime);

        return $this;
    }

      public function getSalesEmail()
    {
        return $this->_scopeConfig->getValue(
            'trans_email/ident_sales/email',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getSalesName()
    {
        return $this->_scopeConfig->getValue(
            'trans_email/ident_sales/name',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

}