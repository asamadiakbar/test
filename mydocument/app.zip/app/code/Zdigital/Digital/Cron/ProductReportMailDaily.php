<?php
namespace Zdigital\Digital\Cron;

use \Psr\Log\LoggerInterface;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Framework\FileSystem;
use Magento\Framework\Mail\Template\TransportBuilder;


class ProductReportMailDaily {

    protected $logger;
    private $fileFactory;
    private $directory;
    private $FileSystem;
    private $transportBuilder;
    protected $scopeConfig;
    protected $_timezoneInterface;

    public function __construct(
        Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        FileSystem $FileSystem,
        LoggerInterface $logger,
        FileFactory $fileFactory,
        TransportBuilder $transportBuilder,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezoneInterface

        ) {
            $this->FileSystem = $FileSystem;
            $this->fileFactory = $fileFactory;
            $this->logger = $logger;
            $this->transportBuilder = $transportBuilder;
            $this->_scopeConfig = $scopeConfig;
            $this->_timezoneInterface = $timezoneInterface;

         }

	/**
    * cleanup the logs tables.
    *
    * @return void
    */

    public function execute() {
       
        $this->logger->info('ProductReportMailDaily  cron started..!');

        /*create csv code */
            $directory = $this->FileSystem->getDirectoryWrite(DirectoryList::VAR_DIR);
            $filePath = 'cron_export/productDailyReport.csv';
            $directory->create('cron_export');
            $stream = $directory->openFile($filePath, 'w+');
            $stream->unlock();
            $columns = ['SKU','Name', 'Qty'];
 
            foreach ($columns as $column) {
                $header[] = $column;
            }
            $stream->writeCsv($header);

         /**********/   
        //Get Object Manager Instance
        $objectManager  = \Magento\Framework\App\ObjectManager::getInstance();
        $objDate = $objectManager->create('Magento\Framework\Stdlib\DateTime\DateTime');
        $currentDateTime = $objDate->gmtDate('Y-m-d');

        
        $ordersCollectionFactory = $objectManager->create('Magento\Sales\Model\ResourceModel\Order\CollectionFactory');
        $collection = $ordersCollectionFactory->create()
         ->addAttributeToSelect('*');
        
        $currentfullDateTime = $objDate->gmtDate('Y-m-d H:i').':00';
        $currentfullDateTime1 = $objDate->gmtDate('Y-m-d H:i').':59';

        /*for avoid date filter issue i minus 1 minute here*/
        $startDate = date("Y-m-d H:i:s", strtotime($currentfullDateTime .' -1 day'));
        $endDate = date("Y-m-d H:i:s",strtotime($currentfullDateTime1.'-1 minute'));

        /*$startDate = date("Y-m-d H:i:s", strtotime($currentDateTime .' 08:00:00 -1 day'));
        $endDate = date("Y-m-d H:i:s",strtotime($currentDateTime.' 07:59:59'));*/

        /*$startDate = date("Y-m-d H:i:s", strtotime('2020-04-01 00:00:00'));
         $endDate = date("Y-m-d H:i:s",strtotime('2020-04-15 00:00:00'));*/ 

        $collection = $ordersCollectionFactory->create()
            ->addAttributeToFilter('created_at', array('from'=>$startDate, 'to'=>$endDate));
        if(count($collection) > 0){
            $item =[];
             foreach ($collection as $key => $orderData) {
                $orderItems = $orderData->getAllItems();
                foreach ($orderData->getAllItems() as $_item) {
                    $productExist = false;
                    if(array_key_exists($_item->getProductId(), $item)){
                        $productExist = true;
                    }
                    $item[$_item->getProductId()]['sku'] = $_item->getSku();
                    $item[$_item->getProductId()]['name'] =  $_item->getName();
                    if($productExist == true){
                         $item[$_item->getProductId()]['qty'] = $item[$_item->getProductId()]['qty']+$_item->getQtyOrdered();
                    }else{
                         $item[$_item->getProductId()]['qty'] = $_item->getQtyOrdered();
                    }
                }        
             }
             foreach ($item as $item_data) {
                $csvArr = []; 
                $csvArr[] = $item_data['sku'];
                $csvArr[] = $item_data['name'];
                $csvArr[] = $item_data['qty'];
                $stream->writeCsv($csvArr);
             }   
        }
    try {

        $directory = $objectManager->get('\Magento\Framework\Filesystem\DirectoryList');
        $csvfilePath = $directory->getPath('var').'/'.$filePath;
        $csvContent = file_get_contents($csvfilePath);

        $adminEmail = $this->getSalesEmail();
        $adminName  = $this->getSalesName();
        $templateVars = [];

        if(count($collection) > 0){
            $transport = $this->transportBuilder->setTemplateIdentifier('product_report_daily_email_template')
            ->setTemplateOptions( [ 'area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => 1 ] )
            ->setTemplateVars( $templateVars )
            ->setFrom( [ "name" => $adminName, "email" => $adminEmail ] )
            ->addTo($adminEmail)
            ->setReplyTo($adminEmail)
            ->addAttachment($csvContent,'Daily_Sold_Product_Report_'.$currentDateTime.'.csv', 'application/csv')
            ->getTransport();
            $transport->sendMessage();
            $this->logger->info('mail sent');
        }else{
            $transport = $this->transportBuilder->setTemplateIdentifier('product_report_daily_no_order_email_template')
            ->setTemplateOptions( [ 'area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => 1 ] )
            ->setTemplateVars( $templateVars )
            ->setFrom( [ "name" => $adminName, "email" => $adminEmail ] )
            ->addTo($adminEmail)
            ->setReplyTo($adminEmail)
            ->getTransport();
            $transport->sendMessage();
            $this->logger->info('no order mail sent');
            

        }
        $this->logger->info('ProductReportMailDaily cron ended..! '.$currentfullDateTime);
        return $this;   
        } catch (Exception $e) {
            $this->logger->error($e);
        }

        
        return $this;
    }

      public function getSalesEmail()
    {
        return $this->_scopeConfig->getValue(
            'trans_email/ident_sales/email',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getSalesName()
    {
        return $this->_scopeConfig->getValue(
            'trans_email/ident_sales/name',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

}