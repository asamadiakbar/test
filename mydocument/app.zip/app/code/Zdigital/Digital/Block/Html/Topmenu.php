<?php

/**

 * Copyright © Magento, Inc. All rights reserved.

 * See COPYING.txt for license details.

 */

namespace Zdigital\Digital\Block\Html;



use Magento\Backend\Model\Menu;

use Magento\Framework\Data\Tree\Node;

use Magento\Framework\Data\Tree\Node\Collection;

use Magento\Framework\Data\Tree\NodeFactory;

use Magento\Framework\Data\TreeFactory;

use Magento\Framework\DataObject;

use Magento\Framework\DataObject\IdentityInterface;

use Magento\Framework\View\Element\Template;



class Topmenu extends \Magento\Theme\Block\Html\Topmenu

{

    protected function _addSubMenu($child, $childLevel, $childrenWrapClass, $limit)

    {

        $html = '';

        $id = str_replace('category-node-','',$child->getId());

        $_objectManager = \Magento\Framework\App\ObjectManager::getInstance();

        $helper_factory = $_objectManager->get('\Magento\Catalog\Helper\Output');

       

        $catagory = $_objectManager->create('Magento\Catalog\Model\Category')->load($id);

        if (!$child->hasChildren()) {

            return $html;

        }

        

        $colStops = [];

        if ($childLevel == 0 && $limit) {

            $colStops = $this->_columnBrake($child->getChildren(), $limit);

        }

        if ($childLevel == 0 && $child->getChildren()) {

            $html .= '<div class="submenu-outer"><div class="submenu-scroll">';

        }

        if ($childLevel != 2) {

       

        $html .= '<ul class="level' . $childLevel . ' ' . $childrenWrapClass . '">';

        $html .= $this->_getHtml($child, $childrenWrapClass, $limit, $colStops);

        $html .= '</ul>';

        if ($childLevel == 0 && $child->getChildren()) {

            $html .= '<div class="right-section-img"> <a class="img-menu" title="" href="' . $child->getUrl() . '">'. preg_replace('#\<p>[{\w},\s\d"]+\</p>#', "", $helper_factory->categoryAttribute(

            $catagory,

            $catagory->getMegamenuDescription(),

            'megamenu_description'

        )) .'</a><a class="menu-link" title="Show More Categories" href="' . $child->getUrl() . '"><span>Show More Categories</span></a></div></div></div>';

        }

         }

        return $html;

    }

    /**

     * Recursively generates top menu html from data that is specified in $menuTree

     *

     * @param Node $menuTree

     * @param string $childrenWrapClass

     * @param int $limit

     * @param array $colBrakes

     * @return string

     */

    protected function _getHtml(

        Node $menuTree,

        $childrenWrapClass,

        $limit,

        array $colBrakes = []

    ) {

        $html = '';



        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

        $_dcshelper = $objectManager->create('Zdigital\Digital\Helper\Data');

        $store = null;

        $disablecat = $_dcshelper->getConfig("digital_general/general/disable_giftcard_cat", $store);

        $singledisablecat = explode(',',$disablecat);



        $children = $menuTree->getChildren();

        $childLevel = $this->getChildLevel($menuTree->getLevel());

        $this->removeChildrenWithoutActiveParent($children, $childLevel);



        $counter = 1;

        $childrenCount = $children->count();



        $parentPositionClass = $menuTree->getPositionClass();

        $itemPositionClassPrefix = $parentPositionClass ? $parentPositionClass . '-' : 'nav-';



        /** @var Node $child */

        foreach ($children as $child) {

            $child->setLevel($childLevel);

            $child->setIsFirst($counter === 1);

            $child->setIsLast($counter === $childrenCount);

            $child->setPositionClass($itemPositionClassPrefix . $counter);



            $outermostClassCode = '';

            $outermostClass = $menuTree->getOutermostClass();

            

            if (!in_array($child->getName(), $singledisablecat)) {

                

            if ($childLevel === 0 && $outermostClass) {

                $outermostClassCode = ' class="' . $outermostClass . '" ';

                $this->setCurrentClass($child, $outermostClass);

            }



            if ($this->shouldAddNewColumn($colBrakes, $counter)) {

                $html .= '</ul></li><li class="column"><ul>';

            }

            $giftclass = '';

            if ($child->getName() == 'Gift Cards') {

                $giftclass = "id = 'giftcardmenu'";

            }

            



            $html .= '<li ' . $this->_getRenderedMenuItemAttributes($child) . $giftclass.'>';

            $html .= '<a href="' . $child->getUrl() . '" ' . $outermostClassCode . '><span>' . $this->escapeHtml(

                $child->getName()

            ) . '</span></a>' . $this->_addSubMenu(

                $child,

                $childLevel,

                $childrenWrapClass,

                $limit

            ) . '</li>';



           $parenturl = substr($child->getUrl(), 0, strrpos($child->getUrl(), '/') - 0);



            if ($childLevel == 2 && ($childrenCount > 7 && $counter > 5 )) {

                 $html .= '<li class="level2 nav-1-1-7 category-item ui-menu-item" role="presentation">';

                $html .= '<a href="' . $parenturl.'.html' . '"id="ui-id-31" class="ui-corner-all" tabindex="-1" role="menuitem"><span> Shop All</span></a></li>';

                break;

            }

            $counter++;

        }

        }



        if (is_array($colBrakes) && !empty($colBrakes) && $limit) {

            $html = '<li class="column"><ul>' . $html . '</ul></li>';

        }



        return $html;

    }



    /**

     * Retrieve child level based on parent level

     *

     * @param int $parentLevel

     *

     * @return int

     */

    private function getChildLevel($parentLevel): int

    {

        return $parentLevel === null ? 0 : $parentLevel + 1;

    }



    /**

     * Remove children from collection when the parent is not active

     *

     * @param Collection $children

     * @param int $childLevel

     * @return void

     */

    private function removeChildrenWithoutActiveParent(Collection $children, int $childLevel): void

    {

        /** @var Node $child */

        foreach ($children as $child) {

            if ($childLevel === 0 && $child->getData('is_parent_active') === false) {

                $children->delete($child);

            }

        }

    }

    /**

     * Check if new column should be added.

     *

     * @param array $colBrakes

     * @param int $counter

     * @return bool

     */

    private function shouldAddNewColumn(array $colBrakes, int $counter): bool

    {

        return count($colBrakes) && $colBrakes[$counter]['colbrake'];

    }



    /**

     * Set current class.

     *

     * @param Node $child

     * @param string $outermostClass

     */

    private function setCurrentClass(Node $child, string $outermostClass): void

    {

        $currentClass = $child->getClass();

        if (empty($currentClass)) {

            $child->setClass($outermostClass);

        } else {

            $child->setClass($currentClass . ' ' . $outermostClass);

        }

    }

	

}

