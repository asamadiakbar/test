<?php

namespace Zdigital\Digital\Block;

class PopularProducts extends \Magento\Framework\View\Element\Template

{    

  

     /**

     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory

     */

    protected $_productCollectionFactory;

  

    public function __construct(

        \Magento\Backend\Block\Template\Context $context,        

        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory

    )

    {    

        $this->_productCollectionFactory = $productCollectionFactory;

        parent::__construct($context);

    }

    

    public function getProductPricetoHtml(
            \Magento\Catalog\Model\Product $product,
            $priceType = null
        ) {
            $priceRender = $this->getLayout()->getBlock('product.price.render.default');
            $price = '';
            if ($priceRender) {
                $price = $priceRender->render(
                    \Magento\Catalog\Pricing\Price\FinalPrice::PRICE_CODE,
                    $product
                );
            }
        return $price;
    }
    

    public function getProductCollectionByCategories($id)

    {

        $collection = $this->_productCollectionFactory->create();

        $collection->addAttributeToSelect('*');

        $collection->addCategoriesFilter(['in' => $id]);



        return $collection;

    }

}