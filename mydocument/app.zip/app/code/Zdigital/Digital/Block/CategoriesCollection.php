<?php
namespace Zdigital\Digital\Block;
use Magento\Framework\Data\Collection;
use Magento\Framework\Registry;

class CategoriesCollection extends \Magento\Framework\View\Element\Template
{    
    protected $_categoryCollectionFactory;
    protected $_categoryHelper;    
    protected $_storeManager;     
    protected $categoryFactory;    
        private $registry;
 
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,        
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollectionFactory,
        \Magento\Catalog\Helper\Category $categoryHelper,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
        Registry $registry,
        array $data = []
    )
    {
        $this->_categoryCollectionFactory = $categoryCollectionFactory;
        $this->_categoryHelper = $categoryHelper;
        $this->_storeManager = $storeManager;        
        $this->categoryFactory = $categoryFactory; 
        $this->registry = $registry;     
        parent::__construct($context, $data);
    }
    /**
     * Get category collection
     *
     * @param bool $isActive
     * @param bool|int $level
     * @param bool|string $sortBy
     * @param bool|int $pageSize
     * @return \Magento\Catalog\Model\ResourceModel\Category\Collection or array
     */
    public function getCategoryCollection($isActive = true, $level = false, $sortBy = false, $pageSize = false)
    {
        $collection = $this->_categoryCollectionFactory->create();
        $collection->addAttributeToSelect('*'); 
        $collection->addAttributeToFilter('include_in_menu', 1);    
        
        // select only active categories
        if ($isActive) {
            $collection->addIsActiveFilter();
        }
                
        // select categories of certain level
        if ($level) {
            $collection->addLevelFilter($level);
        }
        
        // sort categories by some value
        if ($sortBy) {
            $collection->addOrderField($sortBy);
        }
        
        // select certain number of categories
        if ($pageSize) {
            $collection->setPageSize($pageSize); 
        }    
        
        return $collection;
    }
    
    /**
     * Retrieve current store categories
     *
     * @param bool|string $sorted
     * @param bool $asCollection
     * @param bool $toLoad
     * @return \Magento\Framework\Data\Tree\Node\Collection or
     * \Magento\Catalog\Model\ResourceModel\Category\Collection or array
     */
    public function getStoreCategories($sorted = false, $asCollection = false, $toLoad = true)
    {
        return $this->_categoryHelper->getStoreCategories($sorted = false, $asCollection = false, $toLoad = true);
    }
    public function getchildecategory($category){
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();


    //$catId =$category->getId();        
    //$subcategory = $objectManager->create('Magento\Catalog\Model\Category')->load($catId);
        $subcats = $category->getChildrenCategories();
            //$subcats = $subcategory->getChildrenCategories();
         $_dcshelper = $objectManager->create('Zdigital\Digital\Helper\Data');
        $store = null;
        $disablecat = $_dcshelper->getConfig("digital_general/general/disable_cat", $store);
        $singledisablecat = explode(',',$disablecat);
        $html='<ul class="sidebar_category_sub_menu cat-left-'.$category->getLevel().'">';
        foreach ($subcats as $_category) {   
        if (!in_array($_category->getEntityId(), $singledisablecat)) {
               
            $html .='<li><a title="'.$_category->getEntityId().'" href="'.$_category->getUrl().'">'.$_category->getName().'</a>';
                if($_category->hasChildren()){
                  $html .= '<span class="trigger"></span>';
                  $gethtml=  $this->getchildecategory($_category);
                  $html .=$gethtml;
                }
            $html .='</li>';
             }   
        }
        $html.='</ul>';
        return $html;
    }
    public function getCategoryToolbar(){
        $collection = $this->categoryFactory->create()->setStoreId(3)->getCollection();
        $collection->addAttributeToSelect('name')->addAttributeToSelect('include_in_menu');
        $collection->addAttributeToFilter('include_in_menu', 1)->addAttributeToFilter('level', 3); 
        $collection->addAttributeToFilter('parent_id',['eq'=>161]);
        $collection->addUrlRewriteToResult();
        $collection->addOrder('level', Collection::SORT_ORDER_ASC);
        $collection->addOrder('position', Collection::SORT_ORDER_ASC);
        $collection->addOrder('parent_id', Collection::SORT_ORDER_ASC);
        $collection->addOrder('entity_id', Collection::SORT_ORDER_ASC); 

         return $collection;
    }
    public function getCurrentCategory(){
            return $category = $this->registry->registry('current_category');    
    }
}
?>
