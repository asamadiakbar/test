<?php
namespace Digital\Categorys\Block;

class Category extends \Magento\Framework\View\Element\Template
{
// protected $_template = 'Dckap_Newlink::link.phtml';
protected $categoryCollection;
protected $storeManager;
protected $request;
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollection,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\App\RequestInterface $request       
    )
    {
        parent::__construct($context);
        $this->categoryCollection = $categoryCollection;	
        $this->storeManager = $storeManager;
        $this->registry = $registry;
        $this->request = $request;
        
    }

   public function getCategoryCollection()
   {
     $collection = $this->categoryCollection->create()
        ->addAttributeToSelect('*')
        ->addAttributeToFilter('is_verified', '1');
      return $collection;
  }
   public function imagePath()
   {
      $imageurl=$this->storeManager->getStore()->getBaseUrl(
                        \Magento\Framework\UrlInterface::URL_TYPE_WEB
                    );
      
      return $imageurl;
   }

   public function getcurrentCategory()
   {
       $current_category = $this->registry->registry('current_category');

       return $current_category;
   }
   public function getcurrentPage()
   {
        return $this->request->getFullActionName();
   }
}
?>