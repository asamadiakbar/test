<?php

namespace Digital\Testimonials\Controller;

use Magento\Framework\App\ActionInterface;

interface TestimonialsInterface extends ActionInterface
{
}
