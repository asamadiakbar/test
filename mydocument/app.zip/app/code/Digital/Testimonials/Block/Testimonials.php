<?php

namespace Digital\Testimonials\Block;

/**
 * Testimonials content block
 */
class Testimonials extends \Magento\Framework\View\Element\Template
{
    /**
     * Testimonials collection
     *
     * @var Digital\Testimonials\Model\ResourceModel\Testimonials\Collection
     */
    protected $_testimonialsCollection = null;
    
    /**
     * Testimonials factory
     *
     * @var \Digital\Testimonials\Model\TestimonialsFactory
     */
    protected $_testimonialsCollectionFactory;
    
    /** @var \Digital\Testimonials\Helper\Data */
    protected $_dataHelper;
    
    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Digital\Testimonials\Model\ResourceModel\Testimonials\CollectionFactory $testimonialsCollectionFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Digital\Testimonials\Model\ResourceModel\Testimonials\CollectionFactory $testimonialsCollectionFactory,
        \Digital\Testimonials\Helper\Data $dataHelper,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Serialize\Serializer\Json $serialize,
        array $data = []
    ) {
        $this->_testimonialsCollectionFactory = $testimonialsCollectionFactory;
        $this->_dataHelper = $dataHelper;
        $this->serialize = $serialize;
        $this->_scopeConfig = $scopeConfig;
        parent::__construct(
            $context,
            $data
        );
    }
    
    /**
     * Retrieve testimonials collection
     *
     * @return Digital\Testimonials\Model\ResourceModel\Testimonials\Collection
     */
    protected function _getCollection()
    {
        $collection = $this->_testimonialsCollectionFactory->create();
        return $collection;
    }
    
    /**
     * Retrieve prepared testimonials collection
     *
     * @return Digital\Testimonials\Model\ResourceModel\Testimonials\Collection
     */

    public function isEnabled()
    {
         return $this->_dataHelper->isEnabled();
    }

    
    public function getCollection()
    {
        if (is_null($this->_testimonialsCollection)) {
            $this->_testimonialsCollection = $this->_getCollection();
            $this->_testimonialsCollection->setCurPage($this->getCurrentPage());
            $this->_testimonialsCollection->setPageSize($this->_dataHelper->getTestimonialsPerPage());
            /*$this->_testimonialsCollection->setOrder('published_at','asc');*/
            $this->_testimonialsCollection->setOrder('rank','asc');
            $this->_testimonialsCollection->addFieldToFilter('status','1');


        }

        return $this->_testimonialsCollection;
    }
    
    /**
     * Fetch the current page for the testimonials list
     *
     * @return int
     */
    public function getCurrentPage()
    {
        return $this->getData('current_page') ? $this->getData('current_page') : 1;
    }

    public function getCmsPage()
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORES;
        $department =$this->_scopeConfig->getValue("digital_testimonials/digital_testimonials_view/testimonials_manage", $storeScope);

        if($department == '' || $department == null)
            return;

        $unserializedata = $this->serialize->unserialize($department);

        $cmspage = array();
        foreach($unserializedata as $key => $row)
        {
            $cmspage[] = $row['cmspage'];
        }

        return $cmspage;
    }
    
    /**
     * Return URL to item's view page
     *
     * @param Digital\Testimonials\Model\Testimonials $testimonialsItem
     * @return string
     */
    public function getItemUrl($testimonialsItem)
    {
        return $this->getUrl('*/*/view', array('id' => $testimonialsItem->getId()));
    }
    
    /**
     * Return URL for resized Testimonials Item image
     *
     * @param Digital\Testimonials\Model\Testimonials $item
     * @param integer $width
     * @return string|false
     */
    public function getImageUrl($item, $width)
    {
        return $this->_dataHelper->resize($item, $width);
    }
    
    /**
     * Get a pager
     *
     * @return string|null
     */
    public function getAllTestimonialCount(){
        $testimonialsCollection = $this->_getCollection();
        $testimonialsCollection->addFieldToSelect('*')
                                ->addFieldToFilter('status','1')
                                ->setOrder('rank','asc');
        return count($testimonialsCollection);
    }
/*
    public function getDefaultPageSize(){
        return $this->_testimonialsHelper->getPerPageRecords();
    }
    public function getPagerHtml()
    {
        $allCount = $this->getAllTestimonialCount();
        $defaultCount = $this->getDefaultPageSize();
        if($allCount > $defaultCount){
            return $this->getChildHtml('pager');
        }
        
    }*/
    public function getPager()
    {
        $pager = $this->getChildBlock('testimonials_list_pager');
        if ($pager instanceof \Magento\Framework\Object) {
            $testimonialsPerPage = $this->_dataHelper->getTestimonialsPerPage();

            $pager->setAvailableLimit([$testimonialsPerPage => $testimonialsPerPage]);
            $pager->setTotalNum($this->getCollection()->getSize());
            $pager->setCollection($this->getCollection());
            $pager->setShowPerPage(TRUE);
            $pager->setFrameLength(
                $this->_scopeConfig->getValue(
                    'design/pagination/pagination_frame',
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                )
            )->setJump(
                $this->_scopeConfig->getValue(
                    'design/pagination/pagination_frame_skip',
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                )
            );

            return $pager->toHtml();
        }

        return NULL;
    }
}
