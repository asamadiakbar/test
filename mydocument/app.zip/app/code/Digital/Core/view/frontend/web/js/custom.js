require(['jquery'], function ($) {
	$(document).ready(function() {


		/**/
		if(jQuery(window).width() < 1024){
		
		setTimeout(function() {
		jQuery(".menu-images").remove();	 				 	
	}, 5000);
	}
		/**/

		$(".hide-specs").click(function () {
$(".hidedata").hide("slow");
$(".view-all-specs").show("slow"); 
$(".hide-specs").hide("slow"); 
});
$(".view-all-specs").click(function () {
$(".hidedata").show("slow");
$(".view-all-specs").hide("slow");
$(".hide-specs").show("slow"); 
});
	
	 $('.moreless-button').click(function() {
      $('.moretext').slideToggle();
      if ($('.moreless-button').text() == "Read more") {
        $(this).text("Read less");
        $('.moreless-button').addClass("active");
      } else {
        $(this).text("Read more");
        $('.moreless-button').removeClass("active");
      }
    });
    	
	if($(window).width() > 1024){
	wow = new WOW({animateClass: 'animated',});
	wow.init();
	}

	setTimeout(function() {
		jQuery('.brand-menu-main').removeClass('ui-menu-item');		 				 	
	}, 5000);

	jQuery('.header-right .block.block-title').click(function(){
	    jQuery('body').toggleClass('search-open');
	 });

	jQuery('body').click(function(e){
		var container = $(".block.block-search");
		if (!container.is(e.target) && container.has(e.target).length === 0) 
	 		{
   			jQuery("body").removeClass("search-open");	
		}	   
	});

	jQuery('.navigation > ul > li.level0').has('ul').hover(
		 function(){
			jQuery('body').addClass('menu_active');
		 },
		 function(){
			jQuery('body').removeClass('menu_active');
	});
	
	if(jQuery("body").hasClass('catalog-product-view')){jQuery("body").addClass('default-imagewrap');}
	 /*Footer Quick Links*/
	if($(window).width()<1024){
		$('.widget-content h4').click(function(e) {
			e.preventDefault();  
			$this = $(this);
			if ($this.next().parent().hasClass('active')) {
			$(".fcont" ).slideUp(350);
			$(".fcont" ).parent().removeClass('active');
				$this.next().parent().removeClass('active');
				$this.next().slideUp(350);
			} else {
			$(".fcont" ).slideUp(350);
			$(".fcont" ).parent().removeClass('active');
				$this.next().parent().toggleClass('active');
				$this.next().slideToggle(350);
			}
		});  
	}
	/*Footer Quick Links*/

	$(window).scroll(function() {
		if ($(this).scrollTop() > 1){  
			$('.page-header').addClass("sticky");
		  }
		  else{
			$('.page-header').removeClass("sticky");
		  }
	});
	/**/
	/*if(jQuery(window).width() > 991)
	{
		if (jQuery(e.target).closest('.navigation').size() == 0 && jQuery('.navigation').is(":visible")) {
        	jQuery('.navigation ul > li').siblings('li').removeClass('touched selected');
		}
	}*/
	   if(jQuery(window).width() > 991)
		    {
		    	jQuery('.navigation ul > li').each(function(){
		           	jQuery(this).on('touchend click',function(){ 
			   			jQuery(this).siblings('li').removeClass('touched selected');			   			
		    			if(jQuery(this).hasClass('touched'))
		    			{
			       			jQuery(this).addClass('selected');
		    			}
			   			else
			   			{
			       			jQuery(this).addClass('touched');
			   			}
			   		});
		           
		       });
			}
	/*if (jQuery(window).width() >= 1024) {
		jQuery(".brandmenu ul").wrapAll( "<div class='submenu-outer'><div class='submenu-inner' /></div>");
	}*/
	if(jQuery(window).width() < 1023){
		
		    jQuery(".navigation > ul > li.level0.parent > a").after('<span class="level0-ico-corner toggle-handle"></span>');
			jQuery("ul.level0 > li.level1.parent > a").after('<span class="level1-ico-corner toggle-handle" ></span>');
			
			jQuery.each(jQuery(".navigation > ul > li > span.level0-ico-corner"), function(index, value) {
                jQuery(this).on('touchend', function(e) {
                    //if (jQuery(this).parent("li").children("div").length) {
                        jQuery(this).parent("li").siblings().find(".level0.submenu").slideUp(100, "swing");
                        jQuery(this).parent("li").siblings().find(".level1.submenu").slideUp(100, "swing");
                        jQuery(this).parent("li").siblings().find(".level1-ico-corner").removeClass('ui-state-active');
                        jQuery(this).parent("li").siblings().find(".level0-ico-corner").removeClass('ui-state-active');
                        jQuery(this).parent("li").find(".level0.submenu").slideToggle("fast");
                        jQuery(this).toggleClass("ui-state-active");
                        e.stopPropagation();
                        return false;
                    //}
                });
            });

            jQuery.each(jQuery(".navigation > ul > li > div > div > div > ul > li > span.level1-ico-corner"), function(index, value) {
                jQuery(this).on('touchend', function(e) {
                    //if (jQuery(this).parent("li").children("div").length) {
                        jQuery(this).parent("li").siblings().find(".level1.submenu").slideUp(100, "swing");
                        jQuery(this).parent("li").siblings().find(".level1-ico-corner").removeClass('ui-state-active');
                        jQuery(this).parent("li").find(".level1.submenu").slideToggle("fast");
                        jQuery(this).toggleClass("ui-state-active");
                        e.stopPropagation();
                        return false;
                    //}
                });
            });

		    jQuery(".navigation li a").on('click', function(e) {
	            if(jQuery(this).attr('href') != ''){
	                //e.preventDefault();
	                window.location.href = jQuery(this).attr('href');
	                e.stopImmediatePropagation();
	                return false;
	            }
	        });

            jQuery(document).click(function(event) {
		    if (!jQuery(event.target).hasClass('ui-state-active')) {
		    	jQuery('.navigation > ul > li > a').parent("li").siblings("li").find("span.level0-ico-corner").removeClass("ui-state-active");
		    	jQuery('.navigation > ul > li > a').parent("li").siblings("li").find("span.level1-ico-corner").removeClass("ui-state-active");
		    	jQuery('.navigation > ul > li > a').parent("li").siblings("li").find("span.level2-ico-corner").removeClass("ui-state-active");

		    }
		    });
	}
		
});
});