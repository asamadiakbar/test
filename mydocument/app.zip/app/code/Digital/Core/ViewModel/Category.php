<?php

namespace Digital\Core\ViewModel;

class Category  \Magento\Framework\View\Element\Block\ArgumentInterface
{
	protected $categoryCollection;
	protected $storeManager;
	public function __construct
	(
	 \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollection,
	 \Magento\Store\Model\StoreManagerInterface $storeManager
	)
	{
	   $this->categoryCollection = $categoryCollection;
	   $this->storeManager = $storeManager;
	}


	public function getcatgory()
	{
		$collection = $this->categoryCollection->create();
		$collection->addAttributeToSelect('*');
		$collection->addAttributeToFilter ('is_active',1);
		return $collection;
	}
   
   // public function getcategoryid($id)
   // {
   // 	 return $this->categoryCollection->create()->load($id);

   // }

   // public function getPlaceholderImage()
   // {
   // 	   $imageurl=$this->storeManager->getStore()->getBaseUrl(
   //                      \Magento\Framework\UrlInterface::URL_TYPE_MEDIA
   //                  );
   // 	  return $imageurl."catalog/product/placeholder/".$this->scopeConfig->getValue('catalog/placeholder/thumbnail_placeholder');
   // }



}
?>