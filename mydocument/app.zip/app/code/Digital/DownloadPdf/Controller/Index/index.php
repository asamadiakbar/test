<?php
namespace Digital\DownloadPdf\Controller\Index;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
class Index extends \Magento\Framework\App\Action\Action
{
    protected $resultPageFactory;
    protected $__directoryList; 
 
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Catalog\Model\ProductRepository $productRepository,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Filesystem $filesystem, 
        FileFactory $fileFactory,
        DirectoryList $directoryList
    )
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->_productRepository = $productRepository;
         $this->storeManager = $storeManager;
         $this->_filesystem = $filesystem;
        $this->fileFactory = $fileFactory;
        $this->_directoryList = $directoryList;
    }

    public function execute()
    {
        $productId = $this->getRequest()->getParam('id');
        $product = $this->_productRepository->getById($productId);
        $productname = $product->getName();
        $productsku = $product->getSku();
        $product_short_description = $product->getShortDescription();
        $product_image = $product->getImage();
     
        $mediapath= $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
    
            
        $baseurl=$this->storeManager->getStore()->getBaseUrl(
                        \Magento\Framework\UrlInterface::URL_TYPE_MEDIA
                    );
        $imageUrl = $mediapath.'catalog/product'.$product_image;

        
        $pdf = new \Zend_Pdf();
        $pdf->pages[] = $pdf->newPage(\Zend_Pdf_Page::SIZE_A4);
        $page = $pdf->pages[0]; // this will get reference to the first page.
        $style = new \Zend_Pdf_Style();
        $style->setLineColor(new \Zend_Pdf_Color_Rgb(0,0,0));
        $font = \Zend_Pdf_Font::fontWithName(\Zend_Pdf_Font::FONT_TIMES);
        $style->setFont($font,15);
        $page->setStyle($style);
        $width = $page->getWidth();
        $hight = $page->getHeight();
        $x = 0;
        $pageTopalign = 700; 
        $this->y = 0; 
        
        $style->setFont($font,30);
        $page->setStyle($style);
        $page->drawText(__("Magento PDF"), $x+40,$this->y+805, 'UTF-8');
        $page->drawLine($x,$this->y+790,$page->getWidth(), $this->y+790, \Zend_Pdf_Page::SHAPE_DRAW_STROKE);

        $style->setFont($font,15);
        $page->setStyle($style);
        $page->drawText(__("Image"), $x + 40, $this->y+760, 'UTF-8');

        $page->setStyle($style);
        $page->drawText(__("Name"), $x + 160, $this->y+760, 'UTF-8');

        $page->setStyle($style);
        $page->drawText(__("Sku"), $x + 300, $this->y+760, 'UTF-8');

        $page->setStyle($style);
        $page->drawText(__("Short Description"), $x + 400, $this->y+760, 'UTF-8');
        
        $page->setFont($font,2);
        
        $page->drawLine($x+15,$this->y+750,$page->getWidth()-15, $this->y+750, \Zend_Pdf_Page::SHAPE_DRAW_STROKE);
         
         if (is_file($imageUrl)) {
               $x = 0;
                $y = 0;
         $image = \Zend_Pdf_Image::imageWithPath($imageUrl); 
         $page->drawImage($image, $x+30, $y+680, $x+100, $y + 730);
        }
        $style->setFont($font,12);
        $page->setStyle($style);
        $page->drawText(__($productname), $x + 150, $this->y+730, 'UTF-8');

        $page->setStyle($style);
        $page->drawText(__($productsku), $x + 280, $this->y+730, 'UTF-8');

        $page->setStyle($style);
        $line = 730;
        $textChunk = wordwrap($product_short_description, 35, "\n");
           foreach(explode("\n", $textChunk) as $textLine){
              if ($textLine!=='') {
                 $page->drawText(strip_tags(ltrim($textLine)),390, $line, 'UTF-8');
                 $line -=14;
                 }
            }
       // $page->drawText(__($product_short_description), $x + 380, $this->y+730, 'UTF-8');
        
/*        $style->setFont($font,15);
        $page->setStyle($style);
        $page->drawText(__("Cutomer Details"), $x + 5, $this->y+50, 'UTF-8');
        $style->setFont($font,11);
        $page->setStyle($style);
        $page->drawText(__("Name : %1"), $x + 5, $this->y+33, 'UTF-8');
        $page->drawText(__("Email : %1","test@magedelight.com"), $x + 4, $this->y+15, 'UTF-8');
        $style->setFont($font,11);
        $page->setStyle($style);
        $page->drawText(__("PRODUCT NAME"), $x + 60, $this->y-10, 'UTF-8');
        $page->drawText(__("PRODUCT SKU"), $x + 200, $this->y-10, 'UTF-8');
        $page->drawText(__("PRODUCT IMAGE"), $x + 310, $this->y-10, 'UTF-8');
        $page->drawText(__("Product Description"), $x + 440, $this->y-10, 'UTF-8');
        $style->setFont($font,10);
        $page->setStyle($style);
        $add = 9;
        $page->drawText($productsku, $x + 210, $this->y-30, 'UTF-8');
        $page->drawText(10, $x + 330, $this->y-30, 'UTF-8');
        $page->drawText($product_short_description, $x + 470, $this->y-30, 'UTF-8');
        $pro = $productname;  
        $page->drawText($pro, $x + 65, $this->y-30, 'UTF-8');
        $page->drawRectangle(30, $this->y -62, $page->getWidth()-30, $this->y + 10, \Zend_Pdf_Page::SHAPE_DRAW_STROKE);
        $page->drawRectangle(30, $this->y -62, $page->getWidth()-30, $this->y - 100, \Zend_Pdf_Page::SHAPE_DRAW_STROKE);
        $style->setFont($font,15);
        $page->setStyle($style);
        $page->drawText(__("Total : %1", "$50.00"), $x + 435, $this->y-85, 'UTF-8');
        $style->setFont($font,10);
        $page->setStyle($style);
        $page->drawText(__("Test Footer example"), ($page->getWidth()/2)-50, $this->y-200);*/
        $fileName = 'magedelight.pdf';
        $this->fileFactory->create(
           $fileName,
           $pdf->render(),
           \Magento\Framework\App\Filesystem\DirectoryList::VAR_DIR, // this pdf will be saved in var directory with the name magedelight.pdf
           'application/pdf'
        );
       
    }



}