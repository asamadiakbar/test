<?php
namespace Digital\Homebanner\Controller\Index;
 
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\View\Result\PageFactory;
 
 
class Promoproductaddsecond extends \Magento\Framework\App\Action\Action
{    
    protected $resultPageFactory; 
    protected $resultJsonFactory;
	
	
	protected $formKey;   
	protected $cart;
	protected $product;
 
    public function __construct(
		Context $context,
		PageFactory $resultPageFactory,
		JsonFactory $resultJsonFactory,
		\Magento\Framework\Data\Form\FormKey $formKey,
		\Magento\Checkout\Model\Cart $cart,
		\Magento\Catalog\Model\Product $product
	)
    {
 		parent::__construct($context);
        $this->_resultPageFactory = $resultPageFactory;
        $this->_resultJsonFactory = $resultJsonFactory;
		$this->formKey = $formKey;
		$this->cart = $cart;
		$this->product = $product;
 
        
    }
 
    public function execute()
    {
		$productSku = $this->getRequest()->getParam('sku');
		$message = 'You have successfully added gift product to your shopping cart.';
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		
		$_product = $this->product->loadByAttribute('sku', $productSku);
		$productId = $_product->getId();
		
		$promo_product_sku = trim($objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface')->getValue('promoproduct_section/promoprod/promoproductsku'));
		$promoproductfinalsku = trim($objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface')->getValue('promoproduct_section/promoprod/promoproductfinalsku'));

		$both_gift = trim($objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface')->getValue('promoproduct_section/promoprod/both_gift'));
		/* var_dump($both_gift); exit(); */
		$checkout_cart = $objectManager->get('\Magento\Checkout\Model\Session')->getQuote();
		$result_cart = $checkout_cart->getAllVisibleItems();		
		
		$itemsSkus = array();
		foreach ($result_cart as $cartItem) {
    		array_push($itemsSkus, $cartItem->getProduct()->getSku());
		}
		
		if($productId!='')
		{
				if($promo_product_sku==$promoproductfinalsku)
				{				
					if($both_gift == 1)
					{
						if((in_array($promoproductfinalsku, $itemsSkus))==1)
						{
								foreach ($result_cart as $cartItem)
								{
									   if($cartItem->getProduct()->getSku()==$promoproductfinalsku && $cartItem->getQty()==1)
									   {
										   //// Gift Add with 1 Qty
											$params = array(
												'form_key' => $this->formKey->getFormKey(),
												'product' => $productId,
												'qty'   => 1
											);
											$this->cart->addProduct($_product, $params);
											$this->cart->save();

											$result = [
												'status' => 'success',
												'message' => $message,
											];
									   }
								}
						}
						else
						{
							//// Gift Add with 2 Qty
							$params = array(
										'form_key' => $this->formKey->getFormKey(),
										'product' => $productId,
										'qty'   => 2
									);
									$this->cart->addProduct($_product, $params);
									$this->cart->save();

									$result = [
										'status' => 'success',
										'message' => $message,
									];
						}
					}
					else
					{
						$params = array(
							'form_key' => $this->formKey->getFormKey(),
							'product' => $productId,
							'qty'   => 1
						);
						$this->cart->addProduct($_product, $params);
						$this->cart->save();

						$result = [
							'status' => 'success',
							'message' => $message,
						];
					}
					
					
				}
				else
				{
					if($both_gift == 1)
					{	
						if((in_array($promo_product_sku, $itemsSkus))==1)
						{
							if($cartItem->getProduct()->getSku()==$promo_product_sku && $cartItem->getQty()==1)
							{
										//// Second Gift Add
										$params = array(
												'form_key' => $this->formKey->getFormKey(),
												'product' => $productId,
												'qty'   => 1
											);
											$this->cart->addProduct($_product, $params);
											$this->cart->save();

											$result = [
												'status' => 'success',
												'message' => $message,
											];
							}
								
						}
						else
						{
								//// First Gift Add							
							$_product1 = $this->product->loadByAttribute('sku', $promo_product_sku);  
							$productId1 = $_product1->getId();							
							$params1 = array(
									'form_key' => $this->formKey->getFormKey(),
									'product' => $productId1,
									'qty'   => 1
								);
								$this->cart->addProduct($_product1, $params1);
								$this->cart->save();
						
							//// Second Gift Add
							$params = array(
									'form_key' => $this->formKey->getFormKey(),
									'product' => $productId,
									'qty'   => 1
								);
								$this->cart->addProduct($_product, $params);
								$this->cart->save();

								$result = [
									'status' => 'success',
									'message' => $message,
								];
							
							
						}
					}
					else
					{
					    if((in_array($promo_product_sku, $itemsSkus))==1)
						{
							
								$_product1 = $this->product->loadByAttribute('sku', $promo_product_sku);  
								$productId1 = $_product1->getId();
								foreach ($result_cart as $cartItem) {
						    		if($promo_product_sku == $cartItem->getProduct()->getSku())
						    		{
						    			$params1 = array(
											'form_key' => $this->formKey->getFormKey(),
											'product' => $productId1,
											'qty'   => 1
										);
										$this->cart->removeItem($cartItem->getItemId());
										$this->cart->save();
						    		}
						    		
								}
							
								
						}
						//// Second Gift Add
						$params = array(
								'form_key' => $this->formKey->getFormKey(),
								'product' => $productId,
								'qty'   => 1
							);
							$this->cart->addProduct($_product, $params);
							$this->cart->save();

							$result = [
								'status' => 'success',
								'message' => $message,
							];
					}
					
				}
		}
		else
		{
				$result = [
					'status' => 'error',
					'message' => 'error',
				];
		}
		
		
        $resultJson = $this->_resultJsonFactory->create();
        return $resultJson->setData($result);
    }
 
}