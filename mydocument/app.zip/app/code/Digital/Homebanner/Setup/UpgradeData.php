<?php
namespace Digital\Homebanner\Setup;

use Magento\Framework\Module\Setup\Migration;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Catalog\Setup\CategorySetupFactory;

class UpgradeData implements UpgradeDataInterface
{
    public function __construct(CategorySetupFactory $categorySetupFactory)
    {
        $this->categorySetupFactory = $categorySetupFactory;
    }
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
        if (version_compare($context->getVersion(), '8.0.0', '<')) {

            $categorySetup = $this->categorySetupFactory->create(['setup' => $setup]);

            $entityTypeId = $categorySetup->getEntityTypeId(\Magento\Catalog\Model\Category::ENTITY);

            $attributeSetId = $categorySetup->getDefaultAttributeSetId($entityTypeId);
    
            $categorySetup->removeAttribute(
            \Magento\Catalog\Model\Category::ENTITY, 'megamenu_thumbnail_status' );

            $categorySetup->addAttribute(
            \Magento\Catalog\Model\Category::ENTITY, 'megamenu_thumbnail_status', [
                'type' => 'int',
                'label' => 'Megamenu Thumbnail Status',
                /** [Solution] Changed from 'boolean' to 'select' */
                'input' => 'select',  
                /** [Solution] Use source model Boolean */
                'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean', 
                'default' => '0',
                'required' => false,
                'visible' => true,
                'system' => false,
                'position' => 9,
                'sort_order' => 9,
                //'user_defined' => true,
                //'searchable' => true,
                'filterable' => true,
                'comparable' => true,
                'is_used_in_grid' => true,
                'is_visible_in_grid' => true,
                'is_filterable_in_grid' => true,
                'is_searchable_in_grid' => true,
                //'unique' => 0,
            ]
            ); 
            $categorySetup->removeAttribute(
            \Magento\Catalog\Model\Category::ENTITY, 'megamenu_thumbnail' );

            $categorySetup->addAttribute(
            \Magento\Catalog\Model\Category::ENTITY, 'megamenu_thumbnail', [
                'type' => 'varchar',
                'label' => 'Megamenu Thumbnail',
                'input' => 'image',
                'backend' => 'Magento\Catalog\Model\Category\Attribute\Backend\Image',
                'required' => false,
                'sort_order' => 5,
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                'group' => 'General Information',
            ]
            );       
        }
        $installer->endSetup();
    }
}