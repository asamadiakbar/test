var config = {

	paths: { 

		'digital/homebanner': 'Digital_Homebanner/js/owl.carousel.min',	

		'digital/flexslider': 'Digital_Homebanner/js/jquery.flexslider',
		},

	shim: {		 

		'digital/homebanner': {

			deps: ['jquery']

		},

		'digital/flexslider': {

			deps: ['jquery']

		}			 	 

	}

};

