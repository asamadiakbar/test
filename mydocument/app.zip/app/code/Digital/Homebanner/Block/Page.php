<?php
namespace Digital\Homebanner\Block;

class Page extends \Magento\Cms\Model\Config\Source\Page
{
    /**
     * To option array
     *
     * @return array
     */
    public function toOptionArray()
    {
        if (!$this->options) {
            $emptyOption[] = [
                'value' => false,
                'label' => 'No Selected'
            ];
            $this->options = $this->collectionFactory->create()->toOptionIdArray();

            $this->options = array_merge($emptyOption, $this->options);
        }
        return $this->options;
    }
}