var config = {
    config: {
        mixins: {
            'Amasty_CheckoutCore/js/view/checkout-fields': {
                'Amasty_Checkout/js/view/checkout-fields-mixin': true
            }
        }
    }
};
