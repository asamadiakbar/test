<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('max_execution_time', 0);
ini_set('memory_limit', '-1');
set_time_limit(0);
use Magento\Framework\App\Bootstrap;
require __DIR__ . '/../app/bootstrap.php';
// include('app/bootstrap.php');
$bootstrap = Bootstrap::create(BP, $_SERVER);
$objectManager = $bootstrap->getObjectManager();
$url = \Magento\Framework\App\ObjectManager::getInstance();
$storeManager = $url->get('\Magento\Store\Model\StoreManagerInterface');
$state = $objectManager->get('\Magento\Framework\App\State');
$state->setAreaCode(\Magento\Framework\App\Area::AREA_GLOBAL);
$product_collections = $url->get('\Magento\Catalog\Model\ResourceModel\Product\CollectionFactory');
$collection = $product_collections->create()->addAttributeToSelect('*')->addAttributeToFilter('type_id', 'simple')->load();
$sourceFac=$objectManager->get('\Magento\InventoryCatalogAdminUi\Model\GetSourceItemsDataBySku');
$searchCriteriaBuilder=$objectManager->get('\Magento\Framework\Api\SearchCriteriaBuilder');
$sources=array('brisbane','melbourne','perth','sydney');
$fp = fopen('simple_product.csv', 'wb');
fputcsv($fp, array('Simple Product','Sources'));// for column heading 
$skus=array();

foreach ($collection as $_parent) {
	$source = $sourceFac->execute($_parent->getSku());
	fputcsv($fp, array($_parent->getSku(),getSource($source,$sources)));
}
	
function getSource($source,$sources)
{
	$_0arr=array();
	foreach($source as $value){
		echo $value['source_code']."<br>";
		$_0arr[]=$value['source_code'];
	}
	if(array_intersect($_0arr,$sources)){
		$status='yes';
	}
	else{
		$status='no';
	}
	return $status;
}
echo "File Downloaded";
fclose($fp);


?>