<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('max_execution_time', 0);
ini_set('memory_limit', '-1');
set_time_limit(0);
use \Magento\Framework\App\Bootstrap;
require __DIR__ . '/../app/bootstrap.php';
$bootstrap = Bootstrap::create(BP, $_SERVER);
$objectManager = $bootstrap->getObjectManager();
$url = \Magento\Framework\App\ObjectManager::getInstance();
$storeManager = $url->get('\Magento\Store\Model\StoreManagerInterface');

$state = $objectManager->get('\Magento\Framework\App\State');
$state->setAreaCode(\Magento\Framework\App\Area::AREA_GLOBAL);

$product_collections = $url->get('\Magento\Catalog\Model\ResourceModel\Product\CollectionFactory');
$collection = $product_collections->create()->addAttributeToSelect('*')->addAttributeToFilter('type_id',  array('eq' => 'grouped'))->addWebsiteFilter(1)->load();
foreach ($collection as $grouped) {
				
	$parent_cat = $grouped->getCategoryIds();
	$product = $objectManager->create('\Magento\Catalog\Model\Product')->setStoreId(1)->load($grouped->getId());
    $children = $product->getTypeInstance()->getAssociatedProducts($product);
 
 	foreach ($children as $child) {
        $category = $child->getCategoryIds(); 

 		if(!$category){
 		$products = $objectManager->create('Magento\Catalog\Model\Product')->load($child->getId());
 		$products->setCategoryIds($parent_cat);
 	    $products->save();
 	   }
 	}

 	
}


?>