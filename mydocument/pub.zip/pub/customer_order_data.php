<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('max_execution_time', 0);
ini_set('memory_limit', '-1');
set_time_limit(0);
use \Magento\Framework\App\Bootstrap;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require __DIR__ . '/../app/bootstrap.php';
$bootstrap = Bootstrap::create(BP, $_SERVER);
$objectManager = $bootstrap->getObjectManager();
$state = $objectManager->get('\Magento\Framework\App\State');
$state->setAreaCode(\Magento\Framework\App\Area::AREA_GLOBAL);
$fp = fopen('customer_order_data.xlsx', 'wb');
fputcsv($fp, array('Customer Email','Order Id','Sku','Qty'));
$customerData = $objectManager->create('Magento\Customer\Model\Customer')->getCollection();
$orderItems = $objectManager->create('Magento\Sales\Model\Order');
foreach($customerData as $data)
{

    $customerEmail = $data->getEmail();
    $orderData = $orderItems->getCollection()->addAttributeToFilter('customer_email', $customerEmail);
    foreach ($orderData as $value)
    {
       $orderId[] = $value->getEntityId(); 
    }
    
}
echo "success";
    $orderItem = $orderItems->getCollection()->addAttributeToSelect('*');
    $orderItem->getSelect()->join(array('order_item' => 'sales_order_item'),'main_table.entity_id = order_item.order_id');
    $orderItem->addFieldToFilter('entity_id',array('eq',$orderId));
    foreach ($orderItem->getData() as $items)
    {
      echo "<pre>";
      print_r($orderItem->getData());
      exit();
        if($items['product_type'] != 'configurable')
        {
          fputcsv($fp, array($items['customer_email'],$items['order_id'],$items['sku'],$items['qty_ordered']));
        }
    }
       
fclose($fp);

$mail = new PHPMailer(true); 

$mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'test.23digital@gmail.com';
    $mail->Password = 'hbpfnojgywbqerro';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;
 
    $mail->setFrom('test7.23digital@gmail.com', 'Admin');
    $mail->addAddress('test7.23digital@gmail.com', 'Recipient1');
    $mail->addAddress('test7.23digital@gmail.com');
    $mail->addReplyTo('test7.23digital@gmail.com', 'noreply');
    $mail->addCC('test7.23digital@gmail.com');
    $mail->addBCC('test7.23digital@gmail.com');
 
    //Attachments
    $mail->addAttachment('customer_order_data.csv');
 
    //Content
    $mail->isHTML(true); 
    $mail->Subject = 'Mail Subject Here!';
    $mail->Body    = 'Mail body content goes here';
 
    $mail->send();
    echo 'Message has been sent';

echo "\n";
$n = 5;
$m = $n;

    for($i=1;$i<=$n;$i++)  
   {  
   	echo $i+1;
       for($j=1;$j<=$m-1;$j++)  
       {  
           echo " ";  
       }  
       for($k=1;$k<=2*$i-1;$k++)  
       {  
         printf("*");  
       }  
       $m--;  
     
      echo "\n";  
    }  

?>