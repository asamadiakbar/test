<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('max_execution_time', 0);
ini_set('memory_limit', '-1');
set_time_limit(0);
use \Magento\Framework\App\Bootstrap;
require __DIR__ . '/../app/bootstrap.php';
$bootstrap = Bootstrap::create(BP, $_SERVER);
$objectManager = $bootstrap->getObjectManager();
$url = \Magento\Framework\App\ObjectManager::getInstance();
$storeManager = $url->get('\Magento\Store\Model\StoreManagerInterface');

$state = $objectManager->get('\Magento\Framework\App\State');
$state->setAreaCode(\Magento\Framework\App\Area::AREA_GLOBAL);

$order_collections = $url->get('\Magento\Sales\Model\ResourceModel\Order\CollectionFactory');
$collection = $order_collections->create()->addAttributeToSelect('*')->addAttributeToFilter('entity_id',21);

$orderColl = [];
foreach ($collection->getItems() as $orderCollection){
    
     //$customerFirstname = $orderCollection->get
     $customerEmail = $orderCollection->getData();
     echo "<pre>";
      print_r($customerEmail);
      // $orderColl[] = array(
      // 	              'id' => ,$orderId);

}
//print_r($orderColl);
exit();
?>