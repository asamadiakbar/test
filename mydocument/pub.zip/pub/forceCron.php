 <?php
error_reporting(E_ERROR | E_WARNING);
ini_set('display_errors', 1);
ini_set('max_execution_time','18000');
ini_set('memory_limit', '-1');
  
set_time_limit(0);
ini_set('memory_limit','2048M');
require __DIR__ . '/../app/bootstrap.php';
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Framework\Filesystem;


class ForceCron
    extends \Magento\Framework\App\Http
    implements \Magento\Framework\AppInterface
{
    
    public function launch()
    { 
       
        $this->_state->setAreaCode(\Magento\Framework\App\Area::AREA_ADMINHTML);
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $myClass = $this->_objectManager->create('Digital\OrderData\Cron\OrderData');
        $myClass->execute();        
      
       echo "end cron";    
       /*$model = $this->_objectManager->create('Digital\Zohoproduct\Model\Zohoproduct')->getCollection();
       echo "<pre>";
       print_r($model->getData());*/
        return $this->_response;
    }

}
$bootstrap = \Magento\Framework\App\Bootstrap::create(BP, $_SERVER);

$app = $bootstrap->createApplication('ForceCron');
$bootstrap->run($app);