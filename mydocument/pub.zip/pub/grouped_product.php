<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('max_execution_time', 0);
ini_set('memory_limit', '-1');
set_time_limit(0);
use Magento\Framework\App\Bootstrap;
require __DIR__ . '/../app/bootstrap.php';
// include('app/bootstrap.php');
$bootstrap = Bootstrap::create(BP, $_SERVER);
$objectManager = $bootstrap->getObjectManager();
$url = \Magento\Framework\App\ObjectManager::getInstance();
$storeManager = $url->get('\Magento\Store\Model\StoreManagerInterface');
$state = $objectManager->get('\Magento\Framework\App\State');
$state->setAreaCode(\Magento\Framework\App\Area::AREA_GLOBAL);
$product_collections = $url->get('\Magento\Catalog\Model\ResourceModel\Product\CollectionFactory');
$collection = $product_collections->create()->addAttributeToSelect('*')->addAttributeToFilter('type_id', 'grouped')->load();
$fp = fopen('grouped_product_report.csv', 'wb');
fputcsv($fp, array('Grouped Product','Associtaed Products','Qty'));// for column heading 
$orderCollection = $objectManager->get('\Magento\Sales\Model\ResourceModel\Order\Collection');
echo "<pre>";
$get=$orderCollection->addAttributeToSelect('*');
$get->getSelect()->join(array('order_item' => 'sales_order_item'),'main_table.entity_id = order_item.order_id');
$get->addFieldToFilter('order_item.product_type',['eq' => 'grouped']);

foreach ($collection as $_parent) {
	echo $_parent->getSku();
	// $source = $sourceFac->execute($_parent->getSku());
	// $data=getSource($source,$sources);
	$parent_pro = $objectManager->create('Magento\Catalog\Model\Product')->load($_parent->getId()); 

	$_children = $parent_pro->getTypeInstance(true)->getAssociatedProducts($parent_pro);

	
	foreach ($_children as $child) {
		
	 	$get->addFieldToFilter('order_item.sku',['eq' => $child->getSku()]);
		print_r($get->getData());
		exit();
		 if(!empty($get->getData())){
			fputcsv($fp, array($_parent->getSku(),$get->getData()[0]['sku'],$get->getData()[0]['qty_ordered']));

		 }
	// print_r($get);
    //    if ($child->getId() != $parent_pro->getId()) {
    //     // echo "Id :-".$child->getID();
	// 	// echo "<br>";
	// 	echo "Name :-".$child->getSku();
	// 	// echo "<br>";


    //   }
}
}
// exit;

echo "File Downloaded";
fclose($fp);


?>