<?php

namespace Digital\Customer\Model\Customer;

class DataProvider 
{
protected $customers;
protected $customerFactory;

protected $loadedData;

public function __construct(
    \Magento\Customer\Model\ResourceModel\Customer\CollectionFactory $customerFactory,
      \Magento\Customer\Model\Customer $customers
) {
    $this->collection = $customers;
    $this->collectionFactory = $customerFactory;  
}

public function afterGetData(\Magento\Customer\Model\Customer\DataProviderWithDefaultAddresses $subject, $result)
{
    if ($result)
    {
        $customer_id = key($result);
        $customerData =  $result[$customer_id]['customer'];

        if (is_null($this->loadedData)) 
        {
            $this->loadedData = [];

            $collection = $this->collectionFactory->create();

            $items = $collection->getItems();

            foreach ($items as $item) 
            {
                $result[$customer_id]["customdata"]["customdata"][] = $item->getData();
            }
        }
    }

    return $result;
}

}
?>