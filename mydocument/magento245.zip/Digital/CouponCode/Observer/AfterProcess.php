<?php 

namespace Digital\CouponCode\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\SalesRule\Api\CouponRepositoryInterface;
use Magento\SalesRule\Api\RuleRepositoryInterface;

class AfterProcess implements ObserverInterface
{
    /**
     * @var ObjectManagerInterface
     */
    protected $_objectManager;
    private $searchCriteriaBuilder;
     private $couponRepository;

    /**
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     */
    public function __construct(
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\SalesRule\Model\Rule $saleRule,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        CouponRepositoryInterface $couponRepository,
        RuleRepositoryInterface $ruleRepository
    )
    {        
        $this->_objectManager = $objectManager;
        $this->saleRule = $saleRule;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->couponRepository = $couponRepository;
        $this->ruleRepository = $ruleRepository;
    }

    /**
     * customer register event handler
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        // get enetered coupen code        
        $controller = $observer->getControllerAction();        
        $couponCode = $controller->getRequest()->getParam('coupon_code');
         
        $searchCriteria = $this->searchCriteriaBuilder->addFilter('code', $couponCode)->create();  
 

                     
        $couponList = $this->couponRepository->getList($searchCriteria);
        if ($couponList->getTotalCount())
        {  
            $couponData = $couponList->getItems();
            foreach ($couponData as $coupon)
            {
                // $code = $coupon->getCode();    
                // $DiscountAmount = $code['discount_amount'];                
                // $result = $observer->getEvent()->getResult();                
                // $result->setAmount($DiscountAmount);               
                // $result->setBaseAmount($DiscountAmount);

                $ruleId = $coupon->getRuleId();
                 $salesRule = $this->ruleRepository->getById($ruleId);
                 $test = json_encode($salesRule);
                $rule = json_encode($this->saleRule->load($ruleId));
   // return $rule->getDiscountAmount();   
                $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/templog.log');
                     $logger = new \Zend_Log();
                     $logger->addWriter($writer);
                     $logger->info(print_r($test,true));  
            }
          }           
        // $objectManager =   \Magento\Framework\App\ObjectManager::getInstance();        
        // $connection = $objectManager->get('Magento\Framework\App\ResourceConnection')->getConnection('\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION'); 
        // // get list of coupon codes from that custom table        
        // $all_custom_codes = $connection->fetchAll("SELECT * FROM custom_promotion_rules");

        // foreach($all_custom_codes as $code) {            
        //     $db_coupen_code = $code['code'];
             
        //     // matching if user has entered any custom code 
        //     if($couponCode == $db_coupen_code) {
        //         // if yes trying to apply custom discount                
        //         $DiscountAmount = $code['discount_amount'];                
        //         $result = $observer->getEvent()->getResult();                
        //         $result->setAmount($DiscountAmount);               
        //         $result->setBaseAmount($DiscountAmount); 
        //     }
        // }

    }
}




// $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/templog.log');
//                      $logger = new \Zend_Log();
//                      $logger->addWriter($writer);
//                      $logger->info(print_r($couponId,true)); 