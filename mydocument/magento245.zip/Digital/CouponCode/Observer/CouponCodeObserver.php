<?php
namespace Digital\CouponCode\Observer;
 use Magento\Framework\Event\ObserverInterface;
 use Magento\Framework\App\Request\DataPersistorInterface;
 use Zend\Log\Filter\Timestamp;
 use Magento\Store\Model\StoreManagerInterface;
class CouponCodeObserver implements ObserverInterface
{
     const XML_PATH_EMAIL_RECIPIENT_NAME = 'trans_email/ident_support/name';
     const XML_PATH_EMAIL_RECIPIENT_EMAIL = 'trans_email/ident_support/email';

    protected $ruleFactory;
    protected $massgenerator;
    protected $logger;
  protected $inlineTranslation;
  protected $transportBuilder;
  protected $scopeConfig;
  protected $order;
  protected $storeManager;
  private $orderRepository;
  private $orderCollectionFactory;

    public function __construct(
        \Magento\SalesRule\Model\RuleFactory $ruleFactory,
        \Magento\SalesRule\Model\Coupon\Massgenerator $massgenerator,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Sales\Api\Data\OrderInterface $order,
        \Magento\Sales\Model\OrderRepository $orderRepository,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        StoreManagerInterface $storeManager,
        array $data = [] 
    ) {
        $this->ruleFactory= $ruleFactory;
        $this->massgenerator = $massgenerator;
        $this->logger = $logger;
        $this->_inlineTranslation = $inlineTranslation;
        $this->_transportBuilder = $transportBuilder;
        $this->_scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->_order = $order;
        $this->orderRepository = $orderRepository;
        $this->_orderCollectionFactory = $orderCollectionFactory;
       
    }

public function execute(\Magento\Framework\Event\Observer $observer)
    {
 
        $order = $observer->getEvent()->getOrder();
         //$order = $this->orderRepository->get($order_ids);              
         //$customeremail = 'string';
        $CustomerEmail = $order->getCustomerEmail();
        // $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/templog.log');
        //             $logger = new \Zend\Log\Logger();
        //             $logger->addWriter($writer);

        //             $logger->info($CustomerEmail);
         $collection = $this->_orderCollectionFactory->create()
                 ->addFieldToFilter('customer_email', $CustomerEmail);
    
        if($collection->count() > 1)
        {
            $transport = $observer->getTransport();
            
            
            $couponCode = $this->createOneCoupon($CustomerEmail);
            if($couponCode)
            {
                  $transport['free-coupon'] = $couponCode;
            }
        }
                     
                  
     }   
 
     protected function createOneCoupon($CustomerEmail)
    {

          $ruleModel = $this->ruleFactory->create(); 
           $ruleModel->load(1);
                $data = array(
                        'rule_id' => 1,
                        'qty' => 1,
                        'length' => '12',
                        'format' => 'alphanum',
                        'prefix' => '',
                        'suffix' => '',
                        'dash'=>0
                        );

                $generator = $this->massgenerator;

                if (!$generator->validateData($data)) {
                   return false;
                } else {
                    $generator->setData($data);
                    $generator->generatePool();
                    $generated = $generator->getGeneratedCount();
                    $codes = $generator->getGeneratedCodes();
                   
                    $sentToEmail = $this->_scopeConfig ->getValue('trans_email/ident_general/email',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                    $sentToName = $this->_scopeConfig ->getValue('trans_email/ident_general/name',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                    $sender = ['name' => $sentToName, 'email' => $sentToEmail];
                    $templateOptions = ['area' => \Magento\Framework\App\Area::AREA_FRONTEND,'store' => $this->storeManager->getStore()->getId()];
                    $ccd = implode('', $codes);
                    

                   $transport = $this->_transportBuilder
                        ->setTemplateIdentifier('coupon_code_email_template')
                        ->setTemplateOptions($templateOptions)
                        ->setTemplateVars([
                           'subject' => 'test',
                           'code'  => $ccd,
                         ])
                        ->setFrom($sender)
                        ->addTo($CustomerEmail)
                        ->getTransport();
                   $transport->sendMessage();
                   
                    //return $codes[0];

                }
        
    }

   
}




