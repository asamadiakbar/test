<?php

namespace Digital\Testimonials\Controller\Index;

use Digital\Testimonials\Controller\TestimonialsInterface;

class View extends \Digital\Testimonials\Controller\AbstractController\View implements TestimonialsInterface
{

}
