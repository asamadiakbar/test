<?php

namespace Digital\Testimonials\Controller\AbstractController;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\ResponseInterface;

interface TestimonialsLoaderInterface
{
    /**
     * @param RequestInterface $request
     * @param ResponseInterface $response
     * @return \Digital\Testimonials\Model\Testimonials
     */
    public function load(RequestInterface $request, ResponseInterface $response);
}
