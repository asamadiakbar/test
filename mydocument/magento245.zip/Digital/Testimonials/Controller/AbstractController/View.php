<?php

namespace Digital\Testimonials\Controller\AbstractController;

use Magento\Framework\App\Action;
use Magento\Framework\View\Result\PageFactory;

abstract class View extends Action\Action
{
    /**
     * @var \Digital\Testimonials\Controller\AbstractController\TestimonialsLoaderInterface
     */
    protected $testimonialsLoader;
	
	/**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param Action\Context $context
     * @param OrderLoaderInterface $orderLoader
	 * @param PageFactory $resultPageFactory
     */
    public function __construct(Action\Context $context, TestimonialsLoaderInterface $testimonialsLoader, PageFactory $resultPageFactory)
    {
        $this->testimonialsLoader = $testimonialsLoader;
		$this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    /**
     * Testimonials view page
     *
     * @return void
     */
    public function execute()
    {
        if (!$this->testimonialsLoader->load($this->_request, $this->_response)) {
            return;
        }

        /** @var \Magento\Framework\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
		return $resultPage;
    }
}
