<?php
namespace Digital\Testimonials\Block\Adminhtml\Testimonials\Edit\Tab;

use Magento\Cms\Model\Wysiwyg\Config;

/**
 * Cms page edit form main tab
 */
class Main extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
         Config $wysiwygConfig,
        \Magento\Framework\Serialize\Serializer\Json $serialize,
        \Magento\Store\Model\System\Store $systemStore,
        \Digital\Testimonials\Model\Status $status,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->_wysiwygConfig = $wysiwygConfig;
        $this->_status = $status;
        $this->serialize = $serialize;
        $this->_scopeConfig = $scopeConfig;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     */
     public function getCmsPage()
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORES;
        $department =$this->_scopeConfig->getValue("digital_testimonials/digital_testimonials_view/testimonials_manage", $storeScope);

        if($department == '' || $department == null)
            return;

        $unserializedata = $this->serialize->unserialize($department);

        $departmentarray = array();
        foreach($unserializedata as $key => $row)
        {
            $departmentarray[] = $row['cmspage'];
        }

        return $departmentarray;

        
    }
      
       
       public function getCmsPageValue()
        {
            $data_array=array();
            /*foreach($this->getCmsPage() as $k=>$v){
               $data_array[]=array('value'=>$v,'label'=>$v);        
            }*/
            $data_array[]=array('value'=>'About Us','label'=>'About Us');
            $data_array[]=array('value'=>'Workshop','label'=>'Workshop');
            return($data_array);

        }



    protected function _prepareForm()
    {
        /* @var $model \Magento\Cms\Model\Page */
        $model = $this->_coreRegistry->registry('testimonials');

        /*
         * Checking if user have permissions to save information
         */
        if ($this->_isAllowedAction('Digital_Testimonials::save')) {
            $isElementDisabled = false;
        } else {
            $isElementDisabled = true;
        }

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('testimonials_main_');

        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Testimonials Information')]);

        if ($model->getId()) {
            $fieldset->addField('testimonials_id', 'hidden', ['name' => 'testimonials_id']);
        }


   

        $fieldset->addField(
            'title',
            'text',
            [
                'name' => 'title',
                'label' => __('Testimonials Title'),
                'title' => __('Testimonials Title'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );

       $fieldset->addField(
            'name',
            'text',
            [
                'name' => 'name',
                'label' => __('Name'),
                'title' => __('Name'),
                'required' => true,
                'disabled' => $isElementDisabled
            ]
        );

       $fieldset->addField(

            'content',

            'editor',

            [

                'name' => 'content',

                'label' => __('Description'),

                'title' => __('Description'), 

                'wysiwyg' => true,
                'required' => true,

                'config'    => $this->_wysiwygConfig->getConfig() 

            ]

        );

       $fieldset->addField(
            'image',
            'image',
            [
                'name' => 'image',
                'label' => __('Thumbnail Icon'),
                'title' => __('Thumbnail Icon'),
                'note' => '( Note : Please upload image 70 x 70 (width x height) size with jpg, jpeg, png format)',
                'disabled' => $isElementDisabled
            ]
        );
       
       $fieldset->addField(
            'cmspage', 
            'multiselect',
            [
                'label' => __('Cms Page'),
                'title' => __('Cms Page'),
                'required' =>true,
                'name' => 'cmspage[]',
                'values'=> $this->getCmsPageValue()
            ]

       );

       $fieldset->addField(

            'rank',

            'text',

            [

                'name' => 'rank',
                 'label' => __('Rank'),
                 'title' => __('Rank'),
                'required' => true,
                'disabled' => $isElementDisabled

            ]

        );

                                    

                        

        $fieldset->addField(

            'status',

            'select',

            [

                'label' => __('Status'),

                'title' => __('Status'),

                'name' => 'status',
                 'required' => true,
                'options' => \Digital\Testimonials\Model\Status::getOptionArray(),

                'disabled' => $isElementDisabled

            ]

        );
        
        /*$dateFormat = $this->_localeDate->getDateFormat(\IntlDateFormatter::SHORT);
        $fieldset->addField('published_at', 'date', [
            'name'     => 'published_at',
            'date_format' => $dateFormat,
            'image'    => $this->getViewFileUrl('images/grid-cal.gif'),
            'value' => $model->getPublishedAt(),
            'label'    => __('Publishing Date'),
            'title'    => __('Publishing Date'),
            'required' => true
        ]);*/
        
        $this->_eventManager->dispatch('adminhtml_testimonials_edit_tab_main_prepare_form', ['form' => $form]);

        $form->setValues($model->getData());
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('Testimonials Information');
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return __('Testimonials Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}
