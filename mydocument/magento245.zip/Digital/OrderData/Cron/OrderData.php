<?php
namespace Digital\OrderData\Cron;
 
use Magento\Framework\App\Action\Action;
use Zend\Log\Filter\Timestamp;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Filesystem;
use Magento\Framework\App\Filesystem\DirectoryList as CreateDirectory;

class OrderData 
{
  protected $storeManager;
  protected $helper;     
  
  public function __construct(
        \Magento\Customer\Model\Customer $customer,
        \Magento\Sales\Model\Order $order,
        \Digital\OrderData\Helper\Data $helperData,
        \Psr\Log\LoggerInterface $logger,
        StoreManagerInterface $storeManager,
        Filesystem $file
        )
    {
       
        $this->_customer = $customer;
        $this->_order = $order;
        $this->helper = $helperData;
        $this->_logger = $logger;
        $this->storeManager = $storeManager;
        $this->newDirectory = $file->getDirectoryWrite(CreateDirectory::VAR_DIR);
   }
    public function execute()
    {
       date_default_timezone_set('Australia/Melbourne');
       $date = date('d-m-Y h:i:s');

       $filepath = 'order-report-'.$date.'.xlsx';
       $this->newDirectory->create('Order_Report'); 
       $stream = $this->newDirectory->openFile('/Order_Report/'.$filepath,'w+');
       $columns = ['Customer Email','Order Id','Sku','Qty'];
       $customerData = $this->_customer->getCollection();
       $orderItems = $this->_order;
       $stream->writeCsv($columns);
       foreach($customerData as $data)
       {
            $customerEmail = $data->getEmail();
            $orderData = $orderItems->getCollection()->addAttributeToFilter('customer_email', $customerEmail);
            foreach ($orderData as $value)
            {
               $orderId[] = $value->getEntityId(); 
            }

        }
        echo "success";
        $orderItem = $orderItems->getCollection()->addAttributeToSelect('*');
        $orderItem->getSelect()->join(array('order_item' => 'sales_order_item'),'main_table.entity_id = order_item.order_id');
        $orderItem->addFieldToFilter('entity_id',array('eq',$orderId));
        foreach ($orderItem->getData() as $items)
        {
            if($items['product_type'] != 'configurable')
            {
                $data = array($items['customer_email'],$items['order_id'],$items['sku'],$items['qty_ordered']);
                $stream->writeCsv($data);
            }
        }

        $this->helper->sendToEmail($filepath);

    }
}