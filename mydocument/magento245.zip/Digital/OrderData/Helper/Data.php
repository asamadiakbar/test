<?php
namespace Digital\OrderData\Helper;
 
use Magento\Framework\App\Action\Action;
use Zend\Log\Filter\Timestamp;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Filesystem\DirectoryList;

class Data 
{
  protected $_inlineTranslation;
  protected $_transportBuilder;
  protected $_scopeConfig;
  protected $storeManager;     
  protected $directory;
  
  public function __construct(
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        StoreManagerInterface $storeManager,
        DirectoryList $directory,
        )
    {
        $this->_inlineTranslation = $inlineTranslation;
        $this->_scopeConfig = $scopeConfig;
        $this->_logger = $logger;
        $this->_transportBuilder = $transportBuilder;
        $this->storeManager = $storeManager;
        $this->directory = $directory;
   }
          
    public function sendToEmail($filepath)
    {    
        try {

            $adminEmail = $this->_scopeConfig ->getValue('trans_email/ident_general/email',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $adminName = $this->_scopeConfig ->getValue('trans_email/ident_general/name',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $sender = ['name' => $adminName, 'email' => $adminEmail ]; 
            /* send mail to admin */
            $templateOptions = ['area' => \Magento\Framework\App\Area::AREA_FRONTEND,'store' => $this->storeManager->getStore()->getId()];
            $templateVars = [
                    'attachfile'  => 'View Attach File'
            ];
            
            $attachmentFile =$this->directory->getPath('var').'/Order_Report/'.$filepath;
            $transport = $this->_transportBuilder
                ->setTemplateIdentifier('order_email_template')
                ->setTemplateOptions($templateOptions)
                ->setTemplateVars($templateVars)
                ->setFrom($sender)
                ->addTo($adminEmail)
                ->addAttachment(file_get_contents($attachmentFile),$filepath,'application/xlsx')
                ->getTransport();
            $transport->sendMessage();
            $this->_inlineTranslation->resume();
        } catch (\Exception $e) {
            $this->_logger->info($e->getMessage());
       }      
    }
}