<?php
namespace Digital\SalesReport\Cron;
 
use Magento\Framework\App\Action\Action;
use Zend\Log\Filter\Timestamp;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;

class SalesReport 
{
  protected $_inlineTranslation;
  protected $_transportBuilder;
  protected $_scopeConfig;
  protected $storeManager;
  protected $zestradhelper;     
  
  public function __construct(
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Customer\Model\Customer $customer,
        \Digital\SalesReport\Helper\Email $zestradhelper,
        \Magento\Sales\Model\OrderFactory $order,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        StoreManagerInterface $storeManager
        )
    {
        $this->_inlineTranslation = $inlineTranslation;
        $this->_scopeConfig = $scopeConfig;
        $this->_zestradhelper = $zestradhelper;
        $this->_customer = $customer;
        $this->_order = $order;
        $this->_logger = $logger;
        $this->_transportBuilder = $transportBuilder;
        $this->storeManager = $storeManager;
   }
    public function execute() {

         $module_status = $this->_scopeConfig->getValue(
            "salesreport/general/active",
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        if($module_status == False){
            return false;    
        }

        $objectManager  = \Magento\Framework\App\ObjectManager::getInstance();
        $objDate = $objectManager->create('Magento\Framework\Stdlib\DateTime\DateTime');
        /*$currentDateTime  = $objDate->gmtDate('Y-m-d');
            $lastMonth = $objDate->gmtDate('m')-01;
        $lastMonthDateTime  = $objDate->gmtDate('Y-'.$lastMonth.'-d');
        */
        $currentfullDateTime = $objDate->gmtDate('Y-m-d H:i').':00';
        $currentfullDateTime1 = $objDate->gmtDate('Y-m-d H:i').':59';

        $startDate = date("Y-m-d H:i:s", strtotime($currentfullDateTime .' -1 day'));
        $endDate = date("Y-m-d H:i:s",strtotime($currentfullDateTime1.'-1 minute'));
        

        $startDate1 = date("Y-m-d H:i:s", strtotime($currentfullDateTime .' -1 month'));
        $endDate1 = date("Y-m-d H:i:s",strtotime($currentfullDateTime1.'-1 minute')); 
        
        $startDate2 = date("Y-m-d H:i:s", strtotime($currentfullDateTime .' -2 month'));
        $endDate2 = date("Y-m-d H:i:s",strtotime($currentfullDateTime1.'-1 month')); 

        $status=array('processing','pending','complete');

        $orderCollectionyesterday=$this->_order->create()->getCollection()->addAttributeToSelect('*')
        ->addAttributeToFilter('status', ['in'=> $status])
        ->addAttributeToFilter('created_at',array('from' => $startDate,'to' => $endDate));

        $orderCollectioncurrentmonth=$this->_order->create()->getCollection()->addAttributeToSelect('*')
        ->addAttributeToFilter('status', ['in'=> $status])
        ->addAttributeToFilter('created_at',array('from' => $startDate1,'to' => $endDate1));

        $orderCollectionlastmonth=$this->_order->create()->getCollection()->addAttributeToSelect('*')
        ->addAttributeToFilter('status', ['in'=> $status])
        ->addAttributeToFilter('created_at',array('from' => $startDate2,'to' => $startDate2));
        
        $report_array=[];
        $report_array['ordercount'] = $orderCollectionyesterday->getSize();
        if($orderCollectionyesterday->getSize() > 0) {
            foreach($orderCollectionyesterday as $data){
                if(!empty($report_array['gross_sale']) || !empty($report_array['total_tax']) || !empty($report_array['discount_amount'])){
                    $report_array['gross_sale']=$report_array['gross_sale']+$data->getData('base_grand_total');
                    $report_array['total_tax']=$report_array['total_tax']+$data->getData('tax_amount');
                    $report_array['discount_amount']=$report_array['discount_amount']+$data->getData('discount_amount');
                    $report_array['net_sale']=$report_array['gross_sale']-$report_array['total_tax']+$report_array['discount_amount'];
                }else{
                    $report_array['gross_sale']=$data->getData('base_grand_total');
                    $report_array['total_tax']=$data->getData('tax_amount');
                    $report_array['discount_amount']=$data->getData('discount_amount');
                    $report_array['net_sale']=$report_array['gross_sale']-$report_array['total_tax']+$report_array['discount_amount'];
                }
            }
        } else {
            $report_array['gross_sale']='0';
            $report_array['total_tax']='0';
            $report_array['discount_amount']='0';
            $report_array['net_sale'] = '0'; 
        }
        if($report_array['gross_sale'] != null && $report_array['gross_sale'] != "" && $report_array['gross_sale'] != '0') {
            $report_array['average'] = $report_array['gross_sale'];
        } else {
            $report_array['average'] = "0";
        }
        $report_array1=[];
        $report_array1['ordercount'] = $orderCollectioncurrentmonth->getSize();
        if($orderCollectioncurrentmonth->getSize() > 0) {
            foreach($orderCollectioncurrentmonth as $data){
                if(!empty($report_array1['gross_sale']) || !empty($report_array1['total_tax']) || !empty($report_array1['discount_amount'])){
                    $report_array1['gross_sale']=$report_array1['gross_sale']+$data->getData('base_grand_total');
                    $report_array1['total_tax']=$report_array1['total_tax']+$data->getData('tax_amount');
                    $report_array1['discount_amount']=$report_array1['discount_amount']+$data->getData('discount_amount');
                    $report_array1['net_sale']=$report_array1['gross_sale']-$report_array1['total_tax']+$report_array1['discount_amount'];
                } else {
                    $report_array1['gross_sale']=$data->getData('base_grand_total');
                    $report_array1['total_tax']=$data->getData('tax_amount');
                    $report_array1['discount_amount']=$data->getData('discount_amount');
                    $report_array1['net_sale']=$report_array1['gross_sale']-$report_array1['total_tax']+$report_array1['discount_amount'];
                }
            }
        } else {
            $report_array1['gross_sale']='0';
            $report_array1['total_tax']='0';
            $report_array1['discount_amount']='0';
            $report_array1['net_sale'] = '0';  
        }

        if($report_array1['gross_sale'] != null && $report_array1['gross_sale'] != "" && $report_array1['gross_sale'] != '0') {
            $report_array1['average'] = $report_array1['gross_sale'] / 30;
        } else {
            $report_array1['average'] = "0";
        }

        $report_array2=[];
        $report_array2['ordercount'] = $orderCollectionlastmonth->getSize();
        if($orderCollectionlastmonth->getSize() > 0) {
            foreach($orderCollectionlastmonth as $data){
                if(!empty($report_array2['gross_sale']) || !empty($report_array2['total_tax']) || !empty($report_array2['discount_amount'])){
                    $report_array2['gross_sale']=$report_array2['gross_sale']+$data->getData('base_grand_total');
                    $report_array2['total_tax']=$report_array2['total_tax']+$data->getData('tax_amount');
                    $report_array2['discount_amount']=$report_array2['discount_amount']+$data->getData('discount_amount');
                    $report_array2['net_sale']=$report_array2['gross_sale']-$report_array2['total_tax']+$report_array2['discount_amount'];
                } else {
                    $report_array2['gross_sale']=$data->getData('base_grand_total');
                    $report_array2['total_tax']=$data->getData('tax_amount');
                    $report_array2['discount_amount']=$data->getData('discount_amount');
                    $report_array2['net_sale']=$report_array2['gross_sale']-$report_array2['total_tax']+$report_array2['discount_amount'];
                }
            }
        } else {
            $report_array2['gross_sale']='0';
            $report_array2['total_tax']='0';
            $report_array2['discount_amount']='0';
            $report_array2['net_sale'] = '0';   
        }
        if($report_array2['gross_sale'] != null && $report_array2['gross_sale'] != "" && $report_array2['gross_sale'] != '0') {
            $report_array2['average'] = $report_array2['gross_sale'] / 30;
        } else {
            $report_array2['average'] = "0";
        }
         $templatevar = array('dailyReport'=>$report_array,'currentmonth'=>$report_array1,'lastMonth'=>$report_array2);
         $this->_zestradhelper->sendEmail($templatevar);


    }
       
}