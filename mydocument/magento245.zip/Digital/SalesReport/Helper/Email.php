<?php
namespace Digital\SalesReport\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\Escaper;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Framework\App\Config\ScopeConfigInterface;

class Email extends \Magento\Framework\App\Helper\AbstractHelper
{
    protected $inlineTranslation;
    protected $escaper;
    protected $transportBuilder;
    protected $logger;

    public function __construct(
        Context $context,
        StateInterface $inlineTranslation,
        Escaper $escaper,
        TransportBuilder $transportBuilder,
        DirectoryList $dir,
        ScopeConfigInterface $scopeConfig
    ) {
        parent::__construct($context);
        $this->inlineTranslation = $inlineTranslation;
        $this->escaper = $escaper;
        $this->transportBuilder = $transportBuilder;
        $this->logger = $context->getLogger();
        $this->dir = $dir;
        $this->scopeConfig = $scopeConfig;

    }

    public function sendEmail($templatevar)
    {
        $senderEmail = $this->scopeConfig->getValue(
            "trans_email/ident_general/email",
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        $senderName = $this->scopeConfig->getValue(
            "trans_email/ident_support/name",
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        $receiverEmail = $this->scopeConfig->getValue(
            "salesreport/general/receiver_email",
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        $receiverName = $this->scopeConfig->getValue(
            "salesreport/general/receiver_name",
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        $template = $this->scopeConfig->getValue(
            "salesreport/general/template",
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );

        try {

            $sender = [
                'name' => $this->escaper->escapeHtml($senderName),
                'email' => $this->escaper->escapeHtml($senderEmail),
            ];
            $receiver = [
                'name' => $this->escaper->escapeHtml($receiverName),
                'email' => $this->escaper->escapeHtml($receiverEmail),
            ];

            if(empty($receiver['email'])){
                $receiver['email']=$senderEmail;
                $receiver['name']=$senderName;
            }  
            
            $transport = $this->transportBuilder
                ->setTemplateIdentifier($template)
                ->setTemplateOptions(
                    [
                        'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                        'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                    ]
                )
                ->setTemplateVars(['orderreport'  => $templatevar])
                ->setFrom($sender)
                ->addTo($receiver['email'],$receiver['name'])
                ->getTransport();
            $transport->sendMessage();
            $this->inlineTranslation->resume();
        } catch (\Exception $e) {
            $this->logger->info($e->getMessage());
        }
    }
}