<?php
namespace Digital\SalesReport\Controller\Adminhtml\SalesReport;

class Index extends \Magento\Backend\App\Action
{
    protected $resultPageFactory;  
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Controller\Result\JsonFactory $jsonResultFactory,
        \Digital\SalesReport\Cron\SalesReport $cron
    )
    {
        parent::__construct($context);
        $this->jsonResultFactory = $jsonResultFactory;
        $this->cron = $cron;
    }

    public function execute()
    {
        $resultJson = $this->jsonResultFactory->create();  
        $this->getRequest()->getParams();
        try
        {
            $this->cron->execute();
            $jsonData = ['html' => "Generate Report and Send Email",'responce_code' => '1'];
             $resultJson->setData($jsonData);
            return $resultJson;
        }
        catch(\Exception $e)
        {
            $this->messageManager->addException($e, __('Something went wrong.'));
            $jsonData = ['html' => 'something went wrong send email report.','responce_code' => '0'];
            $resultJson->setData($jsonData);
           return $resultJson;
        }
    }


}