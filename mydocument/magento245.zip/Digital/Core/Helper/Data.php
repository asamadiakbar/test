<?php
namespace Digital\Core\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;

class Data extends AbstractHelper
{
    protected $scopeConfig;
    protected $httpHeader;
    protected $storeManager;

    const DESKTOP = 'faqtab/general/desktop_banner';
   
    public function __construct( 
        \Magento\Framework\App\Helper\Context $context, 
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
    )
    {
        parent::__construct($context); 
        $this->_scopeConfig = $scopeConfig;
    }
     
    public function getProductId()
    {
        $productIds = $this->scopeConfig->getValue(
        'section_general/general/productids',
        \Magento\Store\Model\ScopeInterface::SCOPE_STORE, );

        $id = explode(',', $productIds);
        return $id;
    } 
    
}