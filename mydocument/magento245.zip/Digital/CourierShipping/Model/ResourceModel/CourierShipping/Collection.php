<?php
namespace Digital\CourierShipping\Model\ResourceModel\CourierShipping;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Digital\CourierShipping\Model\CourierShipping', 'Digital\CourierShipping\Model\ResourceModel\CourierShipping');
    }
}
