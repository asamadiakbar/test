<?php
namespace Digital\CourierShipping\Controller\Adminhtml\Index;
 
 use Magento\Framework\Controller\ResultFactory; 


class Save extends \Magento\Backend\App\Action
{
  public $shippingFactory;
  
  public function __construct(
    \Magento\Backend\App\Action\Context $context,
    \Digital\CourierShipping\Model\CourierShippingFactory $shippingFactory
  )
  {
    parent::__construct($context);
    $this->shippingFactory = $shippingFactory;
  }

  public function execute()
  {
   $data = $this->getRequest()->getPostValue();
   if ($this->getRequest()->getPostValue()) {  
        try {
            $model = $this->shippingFactory->create();
            $data = $this->getRequest()->getPostValue();
            
            $inputFilter = new \Zend_Filter_Input([],[],$data);
            $data = $inputFilter->getUnescaped();
            $id = $this->getRequest()->getParam('couriershipping_id');
            if ($id) {
                    $model->load($id);
                    if ($id != $model->getId()) {
                        throw new \Magento\Framework\Exception\LocalizedException(__('The wrong item is specified.'));
                    }
                }
    
            $model->setZoneTitle($data['zone_title']);
            $model->setTransitTime($data['transit_time']);
            $model->setPostcode($data['postcode']);
            $model->setShippingRate($data['shipping_rate']);
            $model->setThresholdAmount($data['threshold_amount']);
            //$model->setData($data);
            $session = $this->_objectManager->get('Magento\Backend\Model\Session');
            $session->setPageData($model->getData());
            $model->save();
            $this->messageManager->addSuccess(__('You saved this item.'));
            $session->setPageData(false);
           
            if ($this->getRequest()->getParam('save_and_continue')) {
                    $this->_redirect('couriershipping/index/edit', ['couriershipping_id' => $model->getId()]);
                    return;
                }
                $this->_redirect('couriershipping/index/index');
                return;
        }catch (\Exception $e) {
           
            $this->messageManager->addException($e,__("Something Went Wrong Save Data."));
            $this->_redirect('couriershipping/index/index');
                return;
        }


    }
 }
}
