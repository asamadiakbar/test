<?php
namespace Digital\CourierShipping\Controller\Adminhtml\Index;

use Magento\Framework\Controller\ResultFactory;

class Edit extends \Magento\Backend\App\Action
{
    public function __construct(
      \Magento\Backend\App\Action\Context $context,
      \Digital\CourierShipping\Model\CourierShippingFactory $shippingFactory
    )
    {
      parent::__construct($context);
      $this->shippingFactory = $shippingFactory;
    }
    public function execute()
    {
      $model = $this->shippingFactory->create();  
      $id = $this->getRequest()->getParam('couriershipping_id');
      $model->load($id);  
      
      $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
      $resultPage->setActiveMenu('Digital_CourierShipping::submenu');
      $resultPage->getConfig()->getTitle()
            ->prepend($model->getCouriershippingId() ? $model->getZoneTitle() : __('New Record'));
      return $resultPage;
    }
}