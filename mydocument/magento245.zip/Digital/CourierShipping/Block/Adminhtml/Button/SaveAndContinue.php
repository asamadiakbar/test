<?php
namespace Digital\CourierShipping\Block\Adminhtml\Button;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

class SaveAndContinue implements ButtonProviderInterface
{
    public function getButtonData()
    {
        return [
                'label' => __('Save and Continue'),
                'class' => 'save',
                'on_click' => '',
                'sort_order' => 50,
                'data_attribute' => [
                    'mage-init' => [
                        'Magento_Ui/js/form/button-adapter' => [
                            'actions' => [
                                [
                                    'targetName' => 'couriershipping_form.couriershipping_form',
                                    'actionName' => 'save',
                                    'params' => [
                                        true,
                                        [
                                            'save_and_continue' => 2,
                                        ],
                                    ],
                                ],
                            ],
                        ],
                    ],

                ],
            ];
    }
}