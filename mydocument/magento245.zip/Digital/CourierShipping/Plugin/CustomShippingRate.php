<?php
namespace Digital\CourierShipping\Plugin;
use Magento\Checkout\Model\Cart;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\View\Element\Template;
use Digital\CourierShipping\Model\ResourceModel\CourierShipping\CollectionFactory;

class CustomShippingRate extends Template {

    protected $cart;
    public function __construct(Context $context, Cart $cart, CollectionFactory $courierShipping, array $data = [])
    {
        $this->cart = $cart;
        $this->courierShipping = $courierShipping;
        parent::__construct($context, $data);
    }

    public function aroundCollectCarrierRates(
        \Magento\Shipping\Model\Shipping $subject,
        \Closure $proceed,
        $carrierCode,
        $request
    ) {

        $postcode = $this->cart->getQuote()->getShippingAddress()->getPostcode();
        $subTotal = $this->cart->getQuote()->getSubtotal();
        $collection = $this->courierShipping->create()->addFieldToFilter('postcode',array("finset"=>$postcode));
        $data = false;
        foreach($collection as $courierData)
        {
             if($courierData['threshold_amount'] <= $subTotal)
             {
                $data = true;
             }    
               
        }
        if($carrierCode == 'freeshipping' && $data == false)
        {
           return false;
        }
        
                     
        $result = $proceed($carrierCode, $request);    
        return $result;
        
    }
}
