<?php
namespace Digital\AuspostSatchel\Controller\Adminhtml\Index;
 
 use Magento\Framework\Controller\ResultFactory; 


class Save extends \Magento\Backend\App\Action
{
  public $shippingFactory;
  
  public function __construct(
    \Magento\Backend\App\Action\Context $context,
    \Digital\AuspostSatchel\Model\AuspostSatchelFactory $shippingFactory
  )
  {
    parent::__construct($context);
    $this->shippingFactory = $shippingFactory;
  }

  public function execute()
  {
   $data = $this->getRequest()->getPostValue();

   if ($this->getRequest()->getPostValue()) {  
        try {
            $model = $this->shippingFactory->create();
            $data = $this->getRequest()->getPostValue();
            // print_r($data['name']);
            // exit();
            $inputFilter = new \Zend_Filter_Input([],[],$data);
            $data = $inputFilter->getUnescaped();
            $id = $this->getRequest()->getParam('auspost_id');
            if ($id) {
                    $model->load($id);
                    if ($id != $model->getId()) {
                        throw new \Magento\Framework\Exception\LocalizedException(__('The wrong item is specified.'));
                    }
                }
                
            $model->setName($data['name']);
            $model->setFromWeight($data['from_weight']);
            $model->setToWeight($data['to_weight']);
            $model->setLength($data['length']);
            $model->setWidth($data['width']);
            $model->setHeight($data['height']);
            $model->setShippingRate($data['shipping_rate']);
            // print_r($data['to_weight']);
            // exit();
            //$model->setData($data);
            $session = $this->_objectManager->get('Magento\Backend\Model\Session');
            $session->setPageData($model->getData());
            $model->save();
            $this->messageManager->addSuccess(__('You saved this item.'));
            $session->setPageData(false);
           
            if ($this->getRequest()->getParam('save_and_continue')) {
                    $this->_redirect('auspostsatchel/index/edit', ['auspost_id' => $model->getId()]);
                    return;
                }
                $this->_redirect('auspostsatchel/index/index');
                return;
        }catch (\Exception $e) {
           
            $this->messageManager->addException($e,__("Something Went Wrong Save Data."));
            $this->_redirect('couriershipping/index/index');
                return;
        }


    }
 }
}
