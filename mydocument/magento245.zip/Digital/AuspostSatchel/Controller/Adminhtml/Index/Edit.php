<?php
namespace Digital\AuspostSatchel\Controller\Adminhtml\Index;

use Magento\Framework\Controller\ResultFactory;

class Edit extends \Magento\Backend\App\Action
{
    public function __construct(
      \Magento\Backend\App\Action\Context $context,
      \Digital\AuspostSatchel\Model\AuspostSatchelFactory $shippingFactory
    )
    {
      parent::__construct($context);
      $this->shippingFactory = $shippingFactory;
    }
    public function execute()
    {
      $model = $this->shippingFactory->create();  
      $id = $this->getRequest()->getParam('auspost_id');
      $model->load($id);  
      
      $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
      $resultPage->setActiveMenu('Digital_AuspostSatchel::submenu');
      $resultPage->getConfig()->getTitle()
            ->prepend($model->getAuspostId() ? $model->getName() : __('New Record'));
      return $resultPage;
    }
}