<?php
namespace Digital\AuspostSatchel\Model;

class AuspostSatchel extends \Magento\Framework\Model\AbstractModel
{
    
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->_init('Digital\AuspostSatchel\Model\ResourceModel\AuspostSatchel');
    }
}
