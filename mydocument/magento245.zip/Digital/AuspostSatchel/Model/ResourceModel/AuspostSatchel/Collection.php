<?php
namespace Digital\AuspostSatchel\Model\ResourceModel\AuspostSatchel;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Digital\AuspostSatchel\Model\AuspostSatchel', 'Digital\AuspostSatchel\Model\ResourceModel\AuspostSatchel');
    }
}
