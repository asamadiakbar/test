<?php
namespace Digital\AuspostSatchel\Model\ResourceModel;

class AuspostSatchel extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Model Initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('auspost_satchel', 'auspost_id');
    }
}
