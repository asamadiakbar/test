<?php
namespace Digital\AuspostSatchel\Model\AuspostSatchel;

use Magento\Quote\Model\Quote\Address\RateRequest;
use Magento\Shipping\Model\Rate\Result;

class AuspostShipping extends \Magento\Shipping\Model\Carrier\AbstractCarrier implements
    \Magento\Shipping\Model\Carrier\CarrierInterface
{
    /**
     * @var string
     */
    protected $_code = 'auspostshipping';

    /**
     * @var \Magento\Shipping\Model\Rate\ResultFactory
     */
    protected $_rateResultFactory;

    /**
     * @var \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory
     */
    protected $_rateMethodFactory;
    protected $_auspostShipping;
    /**
     * Shipping constructor.
     *
     * @param \Magento\Framework\App\Config\ScopeConfigInterface          $scopeConfig
     * @param \Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory  $rateErrorFactory
     * @param \Psr\Log\LoggerInterface                                    $logger
     * @param \Magento\Shipping\Model\Rate\ResultFactory                  $rateResultFactory
     * @param \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory $rateMethodFactory
     * @param array                                                       $data
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory $rateErrorFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Shipping\Model\Rate\ResultFactory $rateResultFactory,
        \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory $rateMethodFactory,
        \Magento\Checkout\Model\Cart $cart,
        \Magento\Catalog\Model\ProductRepository $productRepository,
        \Digital\AuspostSatchel\Model\ResourceModel\AuspostSatchel\CollectionFactory $auspostShipping,
        array $data = []
    ) {
        $this->_rateResultFactory = $rateResultFactory;
        $this->_rateMethodFactory = $rateMethodFactory;
        $this->cart = $cart;
        $this->productRepository = $productRepository;
        $this->_auspostShipping = $auspostShipping;
        parent::__construct($scopeConfig, $rateErrorFactory, $logger, $data);
    }

    /**
     * get allowed methods
     * @return array
     */
    public function getAllowedMethods()
    {
        return [$this->_code => $this->getConfigData('name')];
    }

    /**
     * @return float
     */
    private function getShippingPrice()
    {
        $configPrice = $this->getConfigData('price');

        $shippingPrice = $this->getFinalPriceWithHandlingFee($configPrice);

        return $shippingPrice;
    }

    /**
     * @param RateRequest $request
     * @return bool|Result
     */
    public function collectRates(RateRequest $request)
    {
        if (!$this->getConfigFlag('active')) 
        {
            return false;
        }
        $qty = "";
        $items = $this->cart->getQuote()->getAllItems();
        $collection = $this->_auspostShipping->create();
        foreach ($items as $item) {
            $id = $item->getproductId();
            $productData = $this->productRepository->getById($id);
           
            $weight = $productData->getWeight();
             if($productData->getTypeId() == 'simple')
             {    
                $tig_length[] = $productData->getTigLength();
                $tig_width[] = $productData->getTigWidth();
                $tig_height[] = $productData->getTigHeight();
             }  
                if ($productData->getVisibility() == '4') {
                    $qty = $item->getQty();
                    
                }
                $totalWeight[] = $weight*$qty;                                
        } 
               
        $sumWeight = array_sum($totalWeight); 
        $sumHeight = array_sum($tig_height);
        $tig_length_max = max($tig_length);
        $tig_width_max = max($tig_width);
        
        foreach ($collection as $shippingData){
            $fromWeight = $shippingData->getFromWeight();
            $toWeight = $shippingData->getToWeight();
            $length = $shippingData->getLength();
            $width = $shippingData->getWidth();
            $height = $shippingData->getHeight();

            if ($sumWeight >= $fromWeight && $sumWeight <= $toWeight){  
                if($tig_length_max <= $length && $tig_width_max <= $width && $sumHeight <= $height){ 
                  $result = $this->_rateResultFactory->create();
                  $method = $this->_rateMethodFactory->create();
   
                  $method->setCarrier($this->_code);
                  $method->setCarrierTitle($this->getConfigData('title'));
                  $method->setMethod($shippingData['auspost_id']);
                  $method->setMethodTitle($shippingData->getName());
                  //$amount = $this->getShippingPrice();
                  $method->setPrice($shippingData->getShippingRate());
                  $method->setCost($shippingData->getShippingRate());
                  $result->append($method);

                  return $result;
                }
                else{
                    return false;
                } 
            }
        }
         
    }
}