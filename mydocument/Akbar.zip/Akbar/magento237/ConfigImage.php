<?php 
error_reporting(1);
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('max_execution_time', 0);
use \Magento\Framework\App\Bootstrap;
require __DIR__ . '/app/bootstrap.php';
$bootstrap = Bootstrap::create(BP, $_SERVER);
$objectManager = $bootstrap->getObjectManager();
$instance = \Magento\Framework\App\ObjectManager::getInstance();
$storeManager = $objectManager->get('\Magento\Store\Model\StoreManagerInterface');
$state = $objectManager->get('\Magento\Framework\App\State');
$state->setAreaCode('frontend');
$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
$productCollection = $objectManager->create('Magento\Catalog\Model\ResourceModel\Product\Collection');
$collection = $productCollection->addAttributeToSelect('*')->addAttributeToFilter('status','1')->addAttributeToFilter('type_id','configurable');
 $imageProcessor = $objectManager->create('Magento\Catalog\Model\Product\Gallery\Processor');
 $productGallery = $objectManager->create('Magento\Catalog\Model\ResourceModel\Product\Gallery');
foreach ($collection as $config)
{  
	  
	    $configProduct = $objectManager->create('Magento\Catalog\Model\Product')->load($config->getEntityId());
	    $_children = $configProduct->getTypeInstance()->getUsedProducts($configProduct);
 	  
      $images = $configProduct->getMediaGalleryImages();
      if ($images) {
         
          foreach ($images as $value) {
            $valid = $value->getValueId();
            $valfile = $value->getFile();
           if (isset($valid) && isset($valfile)) 
           {
               
               $productGallery->deleteGallery($value->getValueId());
               $imageProcessor->removeImage($configProduct, $value->getFile());

           }
        
        }
      }
   

       foreach ($_children as $child)
       {
           $childimg = $child->getData('image');

                       
          if ($child->getImage() != '' && $child->getImage() != 'no_selection') 
          {
             $_childrenImageGallery = 'catalog/product'.$childimg;
             $configProduct->addImageToMediaGallery($_childrenImageGallery, array('image'), false, false);   
             $configProduct->save();
          }
           
       }
       exit();

 }


?>