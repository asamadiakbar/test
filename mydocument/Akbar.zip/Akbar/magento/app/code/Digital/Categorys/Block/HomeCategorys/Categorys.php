<?php
namespace Digital\Categorys\Block\HomeCategorys;
class Categorys extends \Magento\Framework\View\Element\Template
{
// protected $_template = 'Dckap_Newlink::link.phtml';
protected $resultPageFactory; 
protected $categoryCollection;
protected $storeManager;
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollection,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Registry $registry       
    )
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->categoryCollection = $categoryCollection;	
        $this->storeManager = $storeManager;
        $this->registry = $registry;
        
    }

   // public function getBanner()
   // {
   // 	  $data=$this->categoryCollection->create();
   // 	  $collection=$data->getCollection();
   //    $collection->addFieldToFilter('status',1);
   
	  //  return $collection;

   // }

   public function getCategoryCollection()
   {
     $collection = $this->categoryCollection->create()
        ->addAttributeToSelect('*')
        //->addAttributeToFilter('attribute_code', '1')
        ->addAttributeToFilter('is_verified','1');

     return $collection;
  }
   public function imagePath()
   {
      $imageurl=$this->storeManager->getStore()->getBaseUrl(
                        \Magento\Framework\UrlInterface::URL_TYPE_WEB
                    );
      
      return $imageurl;
   }

   public function getParentCategory()
   {
      $collection = $this->categoryCollection->create()
           ->addAttributeToSelect('*')
           ->addAttributeToFilter('is_active','1');
      return $collection;    
   }

   public function current()
   {
       $current_category = $this->registry->registry('current_category');

       return $current_category;
   }
}
?>