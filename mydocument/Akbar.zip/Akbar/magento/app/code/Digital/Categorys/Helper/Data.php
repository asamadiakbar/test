<?php

namespace Digital\Categorys\Helper;
use Magento\Framework\App\Helper\AbstractHelper;
class Data extends AbstractHelper
{
	protected $categoryCollection;
	protected $scopeConfig;
	protected $storeManager;
	public function __construct
	(
	\Magento\Framework\App\Helper\Context $context,
	 \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollection,
	 \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
	 \Magento\Store\Model\StoreManagerInterface $storeManager
	)
	{
	   parent::__construct($context);
	   $this->categoryCollection = $categoryCollection;
	   $this->scopeConfig = $scopeConfig;
	   $this->storeManager = $storeManager;
	   
	}


	public function getcatgory()
	{
		$collection = $this->categoryCollection->create();
		$collection->addAttributeToSelect('*');
		// $collection = $this->categoryCollection->create();
		$collection->addAttributeToFilter ('is_active',1);
		return $collection;
		
		
	}
   
   public function getcategoryid($id)
   {
   	 return $this->categoryCollection->create()->load($id);

   }

   public function getPlaceholderImage()
   {
   	   $imageurl=$this->storeManager->getStore()->getBaseUrl(
                        \Magento\Framework\UrlInterface::URL_TYPE_MEDIA
                    );
   	  return $imageurl."catalog/product/placeholder/".$this->scopeConfig->getValue('catalog/placeholder/thumbnail_placeholder');
   }



}
?>