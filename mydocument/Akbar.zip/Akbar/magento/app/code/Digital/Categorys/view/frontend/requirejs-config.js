var config = {
    paths: {
        owlcarousel: "Digital_Categorys/js/owl.carousel.min"
        
    },
    shim: {
        owlcarousel: {
            deps: ['jquery']
        }
    }
};