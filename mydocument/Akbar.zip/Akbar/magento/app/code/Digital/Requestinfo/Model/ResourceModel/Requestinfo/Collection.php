<?php

namespace Digital\Requestinfo\Model\ResourceModel\Requestinfo;
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'id';
	protected $_eventPrefix = 'requestinfo_collection';
	protected $_eventObject = 'requestinfo_collection';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init('Digital\Requestinfo\Model\Requestinfo', 'Digital\Requestinfo\Model\ResourceModel\Requestinfo');
	}

}

?>