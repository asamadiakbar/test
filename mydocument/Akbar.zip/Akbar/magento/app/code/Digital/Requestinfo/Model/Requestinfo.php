<?php

namespace Digital\Requestinfo\Model;
class Requestinfo extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
	const CACHE_TAG = 'customer_request_info';

	protected $_cacheTag = 'customer_request_info';

	protected $_eventPrefix = 'customer_request_info';

	protected function _construct()
	{
		$this->_init('Digital\Requestinfo\Model\ResourceModel\Requestinfo');
	}

	public function getIdentities()
	{
		return [self::CACHE_TAG . '_' . $this->getId()];
	}

	public function getDefaultValues()
	{
		$values = [];

		return $values;
	}
}
?>