<?php
namespace Digital\Requestinfo\Controller\Account;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;
use Magento\Framework\App\Request\DataPersistorInterface;

class Form extends Action
{
  private $dataPersistor;
    /**
     * @return \Magento\Framework\Controller\Result\Redirect|\Magento\Framework\View\Result\Page
     */

    protected $context;
    private $fileUploaderFactory;
    private $fileSystem;


    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;

    /**
     * @var \Magento\Framework\Translate\Inline\StateInterface
     */
    protected $inlineTranslation;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */


    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     */
  protected $resultRedirectFactory;
  protected $requestinfoFactory;
  public function __construct(
    \Magento\Framework\App\Action\Context $context,
    \Magento\Framework\Controller\Result\RedirectFactory $resultRedirectFactory,
    \Digital\Requestinfo\Model\RequestinfoFactory $requestinfoFactory,
    Filesystem $fileSystem,
    \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
    \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
    \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
  )
  {
     $this->resultRedirectFactory = $resultRedirectFactory;
    $this->requestinfoFactory = $requestinfoFactory;
    $this->fileUploaderFactory = $fileUploaderFactory;
        $this->fileSystem          = $fileSystem;
        $this->_transportBuilder = $transportBuilder;
        $this->inlineTranslation = $inlineTranslation;
        $this->scopeConfig = $scopeConfig;
    return parent::__construct($context);
  }

  public function execute()
  {

      $data = $this->getRequest()->getPostValue();
      if($data)
      {
          $model = $this->requestinfoFactory->create();
          try
          {
          $model->setName($data['name']);
          $model->setEmail($data['email']);
          $model->setNumber($data['phone_number']);
          $model->save();


        //   $customerName=$data['name'];
        //   $message='Thankyou';

        //   $userSubject= 'Test Email';     
        //   $fromEmail= $data['email'];
        //   $fromName = $customerName;

        //   $templateVars = [
        //             'store' => 1,
        //             'customer_name' => $customerName,
        //             'subject' => $userSubject,
        //             'message'   => $message
        //         ];
        //   $from = ['email' => $fromEmail, 'name' => $fromName];
        //   $this->inlineTranslation->suspend();
          
        //   $to = 'test7.23digital@gmail.com';
        //   $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

        //   $templateOptions = [
        //   'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
        //   'store' => 1
        //   ];

        //   $transport = $this->_transportBuilder->setTemplateIdentifier(5, $storeScope)
        //         ->setTemplateOptions($templateOptions)
        //         ->setTemplateVars($templateVars)
        //         ->setFrom($from)
        //         ->addTo($to)               
        //         ->getTransport();
        //   $transport->sendMessage();
        // $this->inlineTranslation->resume();
      

      



          $this->messageManager->addSuccessMessage(__("Data Saved Successfully."));
          $resultPage = $this->resultRedirectFactory->create();
          $resultPage->setPath('request/account/index');
          return $resultPage;
         }
        catch (Exception $e) 
        {
             $this->messageManager->addErrorMessage($e, __("We can\'t submit your request, Please try again."));
             return $resultPage->setPath('request/account/index');  
        }
      }

  }
}