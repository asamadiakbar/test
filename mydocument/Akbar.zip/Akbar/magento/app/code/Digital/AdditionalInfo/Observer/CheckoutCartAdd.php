<?php

namespace Digital\AdditionalInfo\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\View\LayoutInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Serialize\SerializerInterface;
use Digital\AdditionalInfo\Helper\Data;

class CheckoutCartAdd implements ObserverInterface
{
    protected $layout;
    protected $storeManager;
    protected $request;
    private $serializer;
    protected $helperdata;

    public function __construct(
        StoreManagerInterface $storeManager,
        LayoutInterface       $layout,
        RequestInterface      $request,
        SerializerInterface   $serializer,
        Data $helperdata
    )
    {
        $this->layout = $layout;
        $this->storeManager = $storeManager;
        $this->request = $request;
        $this->serializer = $serializer;
        $this->helperdata = $helperdata;
    }

    public function execute(EventObserver $observer)
    {
         $item = $observer->getQuoteItem();
               
         $color = $this->helperdata->getAdditionalColor();
         $size = $this->helperdata->getAdditionalSize();
         //$dynamic = $this->helperdata->getAdditionalDynamic();
        // $arr = json_decode($dynamic, true);
         // $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/templog.log');
         //            $logger = new \Zend\Log\Logger();
         //            $logger->addWriter($writer);

         //            $logger->info('test');
         $additionalprice = $this->helperdata->getAdditionalPrice();
         $additionalOptions = array();
         if ($additionalOption = $item->getOptionByCode('additional_options')) 
         {
              $additionalOptions = $this->serializer->unserialize($additionalOption->getValue());
          }
        
         $additionalColorOptions[] = [
            'label' => 'Color',
            'value' => $color
         ];
         $additionalColorOptions[] = [
            'label' => 'Size',
            'value' => $size
         ];
      
               
         
         if($item->getProductType() == 'simple')
         {    
         
           if (count($additionalColorOptions) > 0)
            {
                $item->addOption(array(
                'product_id' => $item->getProductId(),
                'code' => 'additional_options',
                'value' => $this->serializer->serialize($additionalColorOptions)
                 ));
                $simpleprice = $item->getPrice();
                $price = $simpleprice + $additionalprice;
                $item->setCustomPrice($price);
                $item->setOriginalCustomPrice($price);
                $item->getProduct()->setIsSuperMode(true);
            }
         }  
        
    }



}