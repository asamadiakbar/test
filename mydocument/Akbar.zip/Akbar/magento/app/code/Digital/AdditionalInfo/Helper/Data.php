<?php
/**
 * Created By : Rohan Hapani
 */
namespace Digital\AdditionalInfo\Helper;

use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\Helper\AbstractHelper;
//use Magento\Framework\Api\ExtensibleDataObjectConverter;

class Data extends AbstractHelper
{
    const XML_CONFIG_PATH_COLOR = 'additional/general/color';
    const XML_CONFIG_PATH_SIZE = 'additional/general/size';
    const XML_CONFIG_PATH_PRICE = 'additional/general/price';
    //const XML_CONFIG_PATH_DYNAMIC = 'additional/general/dynamic_field';

     // public function __construct(
     //  ExtensibleDataObjectConverter $dataObjectConverter
     //  )    
     //  {
     //      $this->dataObjectConverter = $dataObjectConverter;
     //   }
     public function getAdditionalColor()
     {
        $configValue = $this->scopeConfig->getValue(self::XML_CONFIG_PATH_COLOR,ScopeInterface::SCOPE_STORE); // For Store
        /**
         * For Website
         * 
         * $configValue = $this->scopeConfig->getValue(self::XML_CONFIG_PATH,ScopeInterface::SCOPE_WEBSITE);
         */
         return $configValue;
     }

     public function getAdditionalSize()
     {
        $configValue = $this->scopeConfig->getValue(self::XML_CONFIG_PATH_SIZE,ScopeInterface::SCOPE_STORE); // For Store
        /**
         * For Website
         * 
         * $configValue = $this->scopeConfig->getValue(self::XML_CONFIG_PATH,ScopeInterface::SCOPE_WEBSITE);
         */
         return $configValue;
     } 

     public function getAdditionalPrice()
     {
        $configValue = $this->scopeConfig->getValue(self::XML_CONFIG_PATH_PRICE,ScopeInterface::SCOPE_STORE); // For Store
        /**
         * For Website
         * 
         * $configValue = $this->scopeConfig->getValue(self::XML_CONFIG_PATH,ScopeInterface::SCOPE_WEBSITE);
         */
         return $configValue;
     }

     // public function getAdditionalDynamic()
     // {
     //    $configValue = $this->scopeConfig->getValue(self::XML_CONFIG_PATH_DYNAMIC,ScopeInterface::SCOPE_STORE); // For Store
     //    *
     //     * For Website
     //     * 
     //     * $configValue = $this->scopeConfig->getValue(self::XML_CONFIG_PATH,ScopeInterface::SCOPE_WEBSITE);
         
     //    $data = $this->dataObjectConverter->toFlatArray($configValue, [], \Magento\Sales\Api\Data\OrderInterface::class);
     //     return $data;
     // }
}