<?php
namespace Digital\Banner\Block\HomeBanner;
use Magento\Store\Model\StoreManagerInterface;
class Homebanner extends \Magento\Framework\View\Element\Template
{
// protected $_template = 'Dckap_Newlink::link.phtml';
protected $resultPageFactory; 
protected $bannerpostFactory;
protected $storeManager;
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Digital\Banner\Model\BannerpostFactory $bannerpostFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager
        
    )
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->bannerpostFactory = $bannerpostFactory;	
        $this->storeManager = $storeManager;
        
    }

   public function getBanner()
   {
   	  $data=$this->bannerpostFactory->create();
   	  $collection=$data->getCollection();
      $collection->addFieldToFilter('status',1);
   
	   return $collection;

   }
   public function imagePath()
   {
      $imageurl=$this->storeManager->getStore()->getBaseUrl(
                        \Magento\Framework\UrlInterface::URL_TYPE_MEDIA
                    );
      return $imageurl;
   }
}
?>