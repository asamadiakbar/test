<?php
namespace Digital\Banner\Controller\Adminhtml\Index;
 
 use Magento\Framework\Controller\ResultFactory; 


class Form extends \Magento\Backend\App\Action
{
  protected $resultPageFactory; 
  protected $bannerpostFactory;
  
  public function __construct(
    \Magento\Backend\App\Action\Context $context,
    \Magento\Framework\View\Result\PageFactory $resultPageFactory,
    \Digital\Banner\Model\BannerpostFactory $bannerpostFactory
  )
  {
    parent::__construct($context);
    $this->resultPageFactory = $resultPageFactory;
    $this->bannerpostFactory = $bannerpostFactory;
  }

  public function execute()
  {


   $data = $this->getRequest()->getPostValue();


     

   
  // echo "<pre>";
   // print_r($data['image']);
   // print_r($data['tablet_image']);
   // print_r($data['mobile_image']);
   // exit();
   if ($data) {   

     $model = $this->bannerpostFactory->create();
     /*$collection=$model->getCollection();
     $test[]='';
     foreach ($collection as  $value) {
       $test=$value->getImage();
       // print_r($test);
       // exit();
     }*/
     
     $id = $this->getRequest()->getParam('post_id');
     if ($id) {
      $model->load($id);

    }
     try 
    {

    // $test=$model->getImage('image');
    // exit();
    if (isset($data['image'][0]['name']) && isset($data['image'][0]['tmp_name']))
    {
      $data['image'] = $data['image'][0]['name'];

      /*$this->imageUploader->moveFileFromTmp($data['image']);*/
    }
    elseif (isset($data['image'][0]['name']) && !isset($data['image'][0]['tmp_name']))
    {
      $data['image'] = $data['image'][0]['name'];

    } 
    else 
    {
      $data['image'] = '';

    }
     

    if (isset($data['tablet_image'][0]['name']) && isset($data['tablet_image'][0]['tmp_name']))
    {
      $data['tablet_image'] = $data['tablet_image'][0]['name'];
      /*$this->imageUploader->moveFileFromTmp($data['image']);*/
    }
    elseif (isset($data['tablet_image'][0]['name']) && !isset($data['tablet_image'][0]['tmp_name']))
    {
      $data['tablet_image'] = $data['tablet_image'][0]['name'];
    } 
    else 
    {
      $data['tablet_image'] = '';

    }
    if (isset($data['mobile_image'][0]['name']) && isset($data['mobile_image'][0]['tmp_name']))
    {
      $data['mobile_image'] = $data['mobile_image'][0]['name'];
      /*$this->imageUploader->moveFileFromTmp($data['image']);*/
    }
    elseif (isset($data['mobile_image'][0]['name']) && !isset($data['mobile_image'][0]['tmp_name']))
    {
      $data['mobile_image'] = $data['mobile_image'][0]['name'];
    } 
    else 
    {
      $data['mobile_image'] = '';

    }


    
       $imagestore = "catalog/tmp/category/".$data['image'];
       $tablet_image = "catalog/tmp/category/".$data['tablet_image'];
       $mobile_image = "catalog/tmp/category/".$data['mobile_image'];
    

     $image =$data['image'];
     if(strpos($image,"catalog/tmp/category/")!== false){
         $data['image'];
      }
      else{
 
            $data['image'] = $imagestore;
      }
     $tablet_banner = $data['tablet_image'];
     if(strpos($tablet_banner, "catalog/tmp/category/" )!== false)
     {
         $data['tablet_image'];
     }
     else
     {
         $data['tablet_image'] = $tablet_image;
     }
     
     $mobile_banner = $data['mobile_image'];
     if(strpos($mobile_banner,"catalog/tmp/category/")!== false)
     {
       $data['mobile_image'];
     }
     else
     {
         $data['mobile_image'] = $mobile_image;
     }

    $data = array_filter($data, function($value) { return $value !== ''; });
    $model->setData($data);



   

     /* $model=$this->bannerpostFactory->create();
      $model->addData([

       "name" => $data['name'],

       "status" => $data['status'],

       "image" => $imagestore,

     ]);*/
              // $model->setData($data);
              // $model->setImage($imagestore);
      $model->save();
      $this->messageManager->addSuccess(__('You saved this item.'));
      $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
      $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
      if ($this->getRequest()->getParam('back')) 
      {
      return $resultRedirect->setPath('*/*/edit', ['post_id' => $model->getPostId(), '_current' => true]);
      }
     return $resultRedirect->setPath('banner/index/index');
  }
  // catch (\Magento\Framework\Exception\LocalizedException $e) 
  // {
  //     $this->messageManager->addError($e->getMessage());
  // } 
  // catch (\RuntimeException $e) {
  //   $this->messageManager->addError($e->getMessage());
  // } 
  catch (\Exception $e)
   {
    $this->messageManager->addException($e,__("Something Went Wrong Save Data."));
    return $resultRedirect->setPath('banner/index/index');
  }


}
}
}
