<?php
namespace Digital\Banner\Block\Adminhtml;
use Magento\Backend\Block\Widget\Context;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;
class Back implements ButtonProviderInterface
 {
    protected $urlBuilder;
 
    public function __construct(Context $context) 
    {
         $this->urlBuilder = $context->getUrlBuilder();
    }
    
    public function getBackUrl()
    {
         return $this->urlBuilder->getUrl('banner/index/index');
    }
    public function getButtonData()
    {
         return [
             'label' => __('Back'),
             'on_click' => sprintf("location.href = '%s';", $this->getBackUrl()),
             'class' => 'back',
             'sort_order' => 10
         ];
    }
 
    
}
?>