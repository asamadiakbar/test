<?php

namespace Digital\Banner\Model;
class Bannerpost extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
	const CACHE_TAG = 'digital_banner_post';

	protected $_cacheTag = 'digital_banner_post';

	protected $_eventPrefix = 'digital_banner_post';

	protected function _construct()
	{
		$this->_init('Digital\Banner\Model\ResourceModel\Bannerpost');
	}

	public function getIdentities()
	{
		return [self::CACHE_TAG . '_' . $this->getId()];
	}

	public function getDefaultValues()
	{
		$values = [];

		return $values;
	}
}
?>