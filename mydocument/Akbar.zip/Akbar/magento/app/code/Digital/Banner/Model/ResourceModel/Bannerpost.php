<?php 

   namespace Digital\Banner\Model\ResourceModel;
   class Bannerpost extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
   {
	
	public function __construct(
		\Magento\Framework\Model\ResourceModel\Db\Context $context
	)
	{
		parent::__construct($context);
	}
	
	protected function _construct()
	{
		$this->_init('digital_banner_post', 'post_id');
	}
	
}

?>