<?php
namespace Digital\Banner\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{
	public function upgrade( SchemaSetupInterface $installer, ModuleContextInterface $context ) {
		        $installer->startSetup();
        if (version_compare($context->getVersion(), '2.2.0', '<')) {
            // $setup->getConnection()->changeColumn(
            //     $setup->getTable('digital_banner_post'),
            //     'featured_image',
            //     'image',
            //     [
            //         'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            //         'length' => 255,
            //         'comment' => 'Full name of customer'
            //     ]
            // );
            $installer->getConnection()->addColumn(
                $installer->getTable( 'digital_banner_post' ),
                'url',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'nullable' => true,
                    'length' => '255',
                    'comment' => 'url',
                    'after' => 'status'
                ]
            );
            $installer->getConnection()->addColumn(
                $installer->getTable( 'digital_banner_post' ),
                'sortorder',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'nullable' => true,
                    'length' => '255',
                    'comment' => 'sortorder',
                    'after' => 'status'
                ]
            );
            $installer->getConnection()->addColumn(
                $installer->getTable( 'digital_banner_post' ),
                'tablet_image',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'nullable' => true,
                    'length' => '255',
                    'comment' => 'tablet_image',
                    'after' => 'status'
                ]
            );
            $installer->getConnection()->addColumn(
                $installer->getTable( 'digital_banner_post' ),
                'mobile_image',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'nullable' => true,
                    'length' => '255',
                    'comment' => 'mobile_image',
                    'after' => 'status'
                ]
            );
        }
        $installer->endSetup();
    }
}