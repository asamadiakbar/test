<?php

namespace Digital\Banner\Model\ResourceModel\Bannerpost;
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'post_id';
	protected $_eventPrefix = 'digital_banner_post_collection';
	protected $_eventObject = 'bannerpost_collection';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init('Digital\Banner\Model\Bannerpost', 'Digital\Banner\Model\ResourceModel\Bannerpost');
	}

}

?>