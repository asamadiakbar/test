<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 *
 * Created By : Rohan Hapani
 */
namespace Digital\Banner\Model;
use Digital\Banner\Model\ResourceModel\Bannerpost\CollectionFactory;
use Magento\Store\Model\StoreManagerInterface;
class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * @var array
     */
    protected $loadedData;
    // @codingStandardsIgnoreStart
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        StoreManagerInterface $storeManager,
        CollectionFactory $blogCollectionFactory,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $blogCollectionFactory->create();
        $this->storeManager = $storeManager;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }
    // @codingStandardsIgnoreEnd
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        $imageUrl = $this->storeManager->getStore()->getBaseUrl(
                        \Magento\Framework\UrlInterface::URL_TYPE_MEDIA
                    );
        foreach ($items as $blog) {
             $itemData = $blog->getData();
             
             $this->loadedData[$blog->getPostId()] = $blog->getData();
             if (isset($itemData['image'])) {
                $image = [];
                $image['image'][0]['name'] = $itemData['image'];
                $image['image'][0]['url'] = $imageUrl.$itemData['image'];
                $image['image'][0]['type'] = 'image';
                $itemData['image'] = $image;
                $fullData = $this->loadedData;
                $this->loadedData[$blog->getPostId()] = array_merge($fullData[$blog->getPostId()], $image);
            }

           //$this->loadedData[$blog->getPostId()] =$itemData;
            if (isset($itemData['tablet_image'])) {
                $tablet_image = [];
                $tablet_image['tablet_image'][0]['name'] = $itemData['tablet_image'];
                $tablet_image['tablet_image'][0]['url'] = $imageUrl.$itemData['tablet_image'];
                $tablet_image['tablet_image'][0]['type'] = 'image';
                $itemData['tablet_image'] = $tablet_image;
                $fullData = $this->loadedData;
                $this->loadedData[$blog->getPostId()] = array_merge($fullData[$blog->getPostId()], $tablet_image);
             //    print_r($tablet_image);
             // exit();
            }
            
             if (isset($itemData['mobile_image'])) {
                $mobile_image = [];
                $mobile_image['mobile_image'][0]['name'] = $itemData['mobile_image'];
                $mobile_image['mobile_image'][0]['url'] = $imageUrl.$itemData['mobile_image'];
                $mobile_image['mobile_image'][0]['type'] = 'image';
                $itemData['mobile_image'] = $mobile_image;
                $fullData = $this->loadedData;
                $this->loadedData[$blog->getPostId()] = array_merge($fullData[$blog->getPostId()], $mobile_image);
            }

        }

        return $this->loadedData;
    }
}