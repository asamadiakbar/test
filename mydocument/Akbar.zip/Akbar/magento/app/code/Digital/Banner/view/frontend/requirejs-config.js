var config = {
    paths: {
        owlcarousel: "Digital_Banner/js/owl.carousel.min"
    },
    shim: {
        owlcarousel: {
            deps: ['jquery']
        }
    }
};