<?php
namespace Digital\Core\Controller\Adminhtml\Create;
 
 use Magento\Framework\Controller\ResultFactory; 


class Form extends \Magento\Backend\App\Action
{
  protected $resultPageFactory; 
  protected $coremoduleFactory;
  
  public function __construct(
    \Magento\Backend\App\Action\Context $context,
    \Magento\Framework\View\Result\PageFactory $resultPageFactory,
    \Digital\Core\Model\CoremoduleFactory $coremoduleFactory
  )
  {
    parent::__construct($context);
    $this->resultPageFactory = $resultPageFactory;
    $this->coremoduleFactory = $coremoduleFactory;
  }

  public function execute()
  {

      $data = $this->getRequest()->getPostValue();

      if($data)
      {
          $model = $this->coremoduleFactory->create();

          try {
            
         
          $collection=$model->getCollection();
          if($collection->count() == 0)
          {
            $model->setValue($data['value']);
            $model->save();
          }
          else
          {   

              //$id = $this->getRequest()->getParam('id');
              $col = $this->coremoduleFactory->create();
              $model = $col->getCollection();
              foreach ($model as  $value) 
              {
                 $id = $value->getId();
                 $model = $col->load($id);
                 $model->setValue($data['value']);
                 $model->save();
              
              }          
             
             
          }    
          
          $this->messageManager->addSuccess(__('You saved this item.'));
          $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
          $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
      
          return $resultRedirect->setPath('coremodule/create/index');

          }
          catch (Exception $e) 
          {
             $this->messageManager->addException($e,__("Something Went Wrong Save Data."));
             return $resultRedirect->setPath('coremodule/create/index');  
          }


      }


   
  }
}
