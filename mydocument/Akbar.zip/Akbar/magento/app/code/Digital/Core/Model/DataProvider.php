<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 *
 * Created By : Rohan Hapani
 */
namespace Digital\Core\Model;
use Digital\Core\Model\ResourceModel\Coremodule\CollectionFactory;

class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * @var array
     */
    protected $loadedData;
    // @codingStandardsIgnoreStart
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $coreCollectionFactory,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $coreCollectionFactory->create();
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }
    // @codingStandardsIgnoreEnd
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        
             
        foreach ($items as $blog) {
             $itemData = $blog->getData();
            
             print_r($itemData);
             exit();
             
             $this->loadedData[$blog->getId()] = $blog->getData();
             

        }

        return $this->loadedData;
    }
}