<?php

namespace Digital\Core\Model\ResourceModel\Coremodule;
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'id';
	protected $_eventPrefix = 'core_module_collection';
	protected $_eventObject = 'coremodule_collection';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init('Digital\Core\Model\Coremodule', 'Digital\Core\Model\ResourceModel\Coremodule');
	}

}

?>