<?php


namespace Digital\Customer\Setup;

use Magento\Customer\Model\Customer;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Customer\Setup\CustomerSetupFactory;

class UpgradeData implements UpgradeDataInterface
{

    private $customerSetupFactory;

    /**
     * Constructor
     *
     * @param \Magento\Customer\Setup\CustomerSetupFactory $customerSetupFactory
     */
    public function __construct(
        CustomerSetupFactory $customerSetupFactory
    ) {
        $this->customerSetupFactory = $customerSetupFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function upgrade(
        ModuleDataSetupInterface $setup,
        ModuleContextInterface $context
    ) {

        $customerSetup = $this->customerSetupFactory->create(['setup' => $setup]);

         if (version_compare($context->getVersion(), '4.1.2') < 0) {

            $customerSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY, 'category_id', [
                'type' => 'varchar',
                'label' => 'Category Id',
                'input' => 'text',
                'source' => '',
                'required' => true,
                'visible' => false,
                'position' => 333,
                'system' => false,
                'backend' => ''
            ]);

            $attribute = $customerSetup->getEavConfig()->getAttribute('customer', 'category_id')
            ->addData(['used_in_forms' => [
                    'adminhtml_customer',
                    'adminhtml_checkout',
                    'customer_account_create',
                    'customer_account_edit'
                ]
            ]);
            $attribute->save();
        }

         if (version_compare($context->getVersion(), '4.1.2') < 0) {

            $customerSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY, 'category_discount', [
                'type' => 'varchar',
                'label' => 'Category Discount',
                'input' => 'text',
                'source' => '',
                'required' => true,
                'visible' => false,
                'position' => 333,
                'system' => false,
                'backend' => ''
            ]);

            $attribute = $customerSetup->getEavConfig()->getAttribute('customer', 'category_discount')
            ->addData(['used_in_forms' => [
                    'adminhtml_customer',
                    'adminhtml_checkout',
                    'customer_account_create',
                    'customer_account_edit'
                ]
            ]);
            $attribute->save();
        }

    }
}