<?php
 
namespace Digital\Customer\Plugin;
 
 
class Product extends \Magento\Framework\View\Element\Template
 
{

	protected $customerSession;
  protected $productCollectionFactory;

      public function __construct(
         \Magento\Backend\Block\Template\Context $context,
            \Magento\Framework\App\Request\Http $request,
            \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
            \Magento\Customer\Model\SessionFactory $customerSession,
            \Magento\Framework\Registry $registry,
            \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
            array $data = []
        ) 
      {
        $this->request = $request;
        $this->customerRepository = $customerRepository;
        $this->_customerSession = $customerSession;
        $this->registry = $registry;
        $this->productCollectionFactory = $productCollectionFactory;
        parent::__construct($context);
      }
 
    public function afterGetPrice(\Magento\Catalog\Model\Product $subject, $result)
    {
    	 $customer = $this->_customerSession->create();

         if($customer->isLoggedIn())
        {
           $id = $customer->getCustomer()->getId();
           $cat_id = $customer->getCustomer()->getCategoryId();
           
           $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
           $customerObj = $objectManager->create('\Magento\Customer\Api\CustomerRepositoryInterface')
            ->getById($id);                     
          
             if (empty($customerObj->getCustomAttribute('discount'))) 
             {
                 $cust_discount = 0;
              }
             else
             {
                 $cust_discount = $customerObj->getCustomAttribute('discount')->getValue();
              }
             $percentInDecimal = $cust_discount / 100;
             $percent = $percentInDecimal * $result;
             $customer_discount = $result - $percent;
           
             //$current_category = $this->registry->registry('current_category')->getId();

             $category_id = $customerObj->getCustomAttribute('category_id')->getValue();

             if (empty($customerObj->getCustomAttribute('category_discount'))) 
             {
                $category_discount = 0;
             }
             else
             {
                $category_discount = $customerObj->getCustomAttribute('category_discount')->getValue();
              }
               
              $collection = $this->productCollectionFactory->create();
              $collection->addCategoriesFilter(['in' => $category_id]);
              foreach ($collection as  $productCollection) 
              {
                          
                 if ($category_id == $productCollection->getCategoryId()) 
                 {  
                    
                   $discount = $category_discount / 100;
                   $check = $discount * $result;
                   $minus = $result - $check;
                   $product_discount = $minus -  $percent;
                  
                   return $product_discount;                 
                 }
                 
            }
           
           return $customer_discount; 
         }
         else
         {
          return $result; 
         }	
 
    }

 
}