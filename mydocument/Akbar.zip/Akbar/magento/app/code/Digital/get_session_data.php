<?php

 Namespace Digital\Customer\Block;

 class Customer
 {

  protected $_customerSession;

    public function __construct(Template\Context $context,
            \Magento\Framework\App\Request\Http $request,
            \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
            \Magento\Customer\Model\SessionFactory $customerSession
        ) 
    {
        $this->request = $request;
        $this->customerRepository = $customerRepository;
        $this->_customerSession = $customerSession;
        parent::__construct($context);
    }

    public function getCustomerId(){
        $customer = $this->_customerSession->create();
        var_dump($customer->getCustomer()->getId());
    }


}

?>



 public function getDisplayValue()
    {
        // if ($this->displayValue !== null) {
        //     return $this->displayValue;
        // } else {
        //     return $this->getAmount()->getValue();
        // }
        //  $customer = $this->_customerSession->create();
        // if(!$customer->isLoggedIn())
        // {
        //     return $this->getAmount()->getValue();
        // }
    }

   