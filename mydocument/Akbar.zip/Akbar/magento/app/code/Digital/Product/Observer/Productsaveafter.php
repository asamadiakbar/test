<?php

namespace Digital\Product\Observer;

use Magento\Framework\Event\ObserverInterface;

class Productsaveafter implements ObserverInterface
{    

    
    public function execute(\Magento\Framework\Event\Observer $observer)
    {

        $product = $observer->getEvent()->getProduct();
        $id = $product->getId(); 
        $stockItem = $product->getExtensionAttributes()->getStockItem();
        $qty = $stockItem->getQty();
        
        if($qty > 0){
            
            $stockItem->setIsInStock('1');
            $stockItem->save();
        }



        // $product = $observer->getProduct();
        // $name = $product->getName();
        // $sku = $product->getSku();
        // $productcode = $name." ".$sku;
        // $product->setData('product_code', $productcode);
        // $product->getResource()->saveAttribute($product, 'product_code');
        // $product = $observer->getEvent()->getProduct();
		
    }       
}

