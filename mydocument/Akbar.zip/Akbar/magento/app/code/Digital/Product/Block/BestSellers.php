<?php
namespace Digital\Product\Block;
class BestSellers extends \Magento\Framework\View\Element\Template
{
// protected $_template = 'Dckap_Newlink::link.phtml';
protected $resultPageFactory; 
protected $productCollectionFactory;
protected $storeManager;
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager        
    )
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->productCollectionFactory = $productCollectionFactory;    
        $this->storeManager = $storeManager;
        
    }

   
    public function getBestSellers()
   {
     $collection = $this->productCollectionFactory->create()
        ->addAttributeToSelect('*') 
        //->addAttributeToFilter('attribute_code', '1')
         ->addAttributeToFilter('best_sellers','1');
    
     return $collection;
  }


   public function imagePath()
   {
      $imageurl=$this->storeManager->getStore()->getBaseUrl(
                        \Magento\Framework\UrlInterface::URL_TYPE_MEDIA
                    );
      
      return $imageurl;
   }

}
?>