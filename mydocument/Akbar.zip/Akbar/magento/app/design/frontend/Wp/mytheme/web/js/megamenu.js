require(['jquery', 'owlCarousel'], function($) {
$(document).ready(function(){

   $('li.level0.parent').each(function(){
   	   $(this).hover(function(){
   	  	$(this).addClass('active-menu');
   	  	$('li.level0.parent.active-menu ul').css({'display':'block','display':'inline-flex'});
   	  	 // $('.catname-image-wrapper').css('display','none');
   	  },
   	   function()
   	   {
   	   	 $(this).removeClass('active-menu');
   	   	 $('ul.level0').css('display','none');
   	   }	
   	  );

   });
   });
});

// 	   $('li.level_1.parent').each(function(){
// 	   	 $(this).hover(function(){
// 	      $(this).addClass('active-menu');
// 	      $('li.level_1.parent.active-menu .submenu_wrapper1').css('display','block');
// 	     },
// 	   	 function()
// 	   	 {
// 	   	 	$(this).removeClass('active-menu');
// 	   	 	 $('.submenu_wrapper1').css('display','none');
// 	   	 } 

// 	   	  );



// 	   });
// 	   $('li.level_2.parent').each(function(){
// 	   	 $(this).hover(function(){
// 	      $(this).addClass('active-menu');
// 	      $('li.level_2.parent.active-menu .submenu_wrapper2').css('display','block');
// 	     },
// 	   	 function()
// 	   	 {
// 	   	 	$(this).removeClass('active-menu');
// 	   	 	$('.submenu_wrapper2').css('display','none');
// 	   	 	// $('.submenu_wrapper1').css('display','none');
// 	   	 	// $('.submenu_wrapper3').css('display','none');
// 	   	 } 

// 	   	 );



// 	   });
// 	   $('li.level_3.parent').each(function(){
// 	   	 $(this).hover(function(){
// 	      $(this).addClass('active-menu');
// 	      $('.submenu_wrapper3').css('display','block');
// 	     },
// 	   	 function()
// 	   	 {
// 	   	 	$(this).removeClass('active-menu');
// 	   	 	$('li.level_3.parent.active-menu .submenu_wrapper3').css('display','none');
// 	   	 } 

// 	   	 );



// 	   });

// $('.image-top-menu').owlCarousel({
//             loop: true,
//             margin:10,
//             nav: false,
//             dots:false,
//             autoplay: true,
//             autoplayHoverPause: true,
//              responsive: {
//                 0: {
//                   items: 1
//                 },
//                 600: {
//                   items: 3
//                 },
//                 1000: {
//                   items: 6
//                 }
//             }
//         });
// });
//});




